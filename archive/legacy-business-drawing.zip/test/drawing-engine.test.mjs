import assert from "node:assert/strict";
import test from "node:test";
import { loadTool } from "./test-harness.mjs";

const plain = (value) => JSON.parse(JSON.stringify(value));

test("도면 엔진은 선형 치수를 생성하고 값·기하·히트 판정을 계산한다", () => {
  const { Tool } = loadTool();
  const engine = Tool.core.drawingEngine.create({
    initialState: {
      settings: { color: "#1a56d6", textSize: 20, unit: "cm" },
    },
  });
  const linear = engine.types.get("linear");
  const dimension = engine.model.createLinear({ x: 100, y: 200 }, { x: 400, y: 200 });

  assert.deepEqual(plain(dimension), {
    type: "linear",
    a: { x: 100, y: 200 },
    b: { x: 400, y: 200 },
    off: 34,
    col: "#1a56d6",
    th: 20,
    unit: "cm",
  });
  assert.equal(engine.model.measure(dimension), 300);
  assert.equal(engine.model.label(dimension), "300cm");
  engine.state.unitsPerPixel = 0.5;
  assert.equal(engine.model.label(dimension), "150cm");
  dimension.txt = "120";
  assert.equal(engine.model.label(dimension), "120cm");
  dimension.txt = "Ø30 H7";
  assert.equal(engine.model.label(dimension), "Ø30 H7");

  const geometry = linear.geometry(dimension);
  assert.deepEqual(plain(geometry.q1), { x: 100, y: 234 });
  assert.deepEqual(plain(geometry.q2), { x: 400, y: 234 });
  engine.model.add(dimension);
  assert.equal(engine.model.hitTest({ x: 250, y: 234 }, 3), dimension);
  assert.equal(engine.model.hitTest({ x: 800, y: 900 }, 3), null);
});

test("도면 엔진은 분할·삭제·되돌리기와 선택 치수 스타일을 관리한다", () => {
  const { Tool } = loadTool();
  const changes = [];
  const engine = Tool.core.drawingEngine.create({
    initialState: {
      settings: { color: "#e01b24", textSize: 16, unit: "mm" },
    },
    onDimensionsChange(dimensions, reason) {
      changes.push({ dimensions: plain(dimensions), reason });
    },
  });
  const dimension = engine.model.createLinear({ x: 0, y: 0 }, { x: 300, y: 0 });
  engine.model.add(dimension);

  const parts = engine.model.splitAt({ x: 150, y: 0 });
  assert.equal(parts.length, 2);
  assert.deepEqual(plain(parts.map((part) => [part.a.x, part.b.x])), [[0, 150], [150, 300]]);
  assert.deepEqual(plain(engine.state.dimensions.map((part) => engine.model.measure(part))), [150, 150]);

  const selected = engine.state.selected;
  assert.equal(engine.model.updateSelected({ color: "#111111", textSize: 24, unit: "m" }), true);
  assert.equal(selected.col, "#111111");
  assert.equal(selected.th, 24);
  assert.equal(selected.unit, "m");
  assert.equal(engine.style.color, "#e01b24");
  assert.equal(engine.style.textSize, 16);
  assert.equal(engine.style.unit, "mm");
  assert.equal(engine.styleOf(selected).color, "#111111");
  assert.equal(engine.styleOf(selected).textSize, 24);
  assert.equal(engine.model.label(selected), "150m");

  assert.equal(engine.model.remove(selected), true);
  assert.equal(engine.state.dimensions.length, 1);
  assert.equal(engine.model.undo(), true);
  assert.equal(engine.state.dimensions.length, 2);
  assert.deepEqual(changes.map((change) => change.reason), ["add", "split", "style", "remove", "undo"]);
});

test("도면 내보내기 모듈은 PNG와 DXF exporter를 등록한다", () => {
  const { Tool } = loadTool();
  const engine = Tool.core.drawingEngine.create();

  assert.deepEqual(Array.from(engine.exporters.names()), []);
  Tool.core.drawingExporters.register(engine);
  assert.deepEqual(Array.from(engine.exporters.names()), ["png", "dxf"]);
  assert.equal(engine.exporters.get("png").label, "PNG 저장");
  assert.equal(engine.exporters.get("dxf").label, "DXF 저장");
  assert.equal(engine.exporters.get("dxf").primary, true);
  assert.equal(typeof engine.exporters.get("png").run, "function");
  assert.equal(typeof engine.exporters.get("dxf").run, "function");
});
