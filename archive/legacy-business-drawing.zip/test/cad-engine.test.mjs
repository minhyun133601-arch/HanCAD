import assert from "node:assert/strict";
import test from "node:test";
import { loadTool } from "./test-harness.mjs";

const plain = (value) => JSON.parse(JSON.stringify(value));
const close = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-7, `${actual} differs from ${expected}`);
const create = (options) => loadTool().Tool.core.cadEngine.create(options);

test("CAD parses complete absolute, relative and polar coordinates in a y-down world", () => {
  const { parsePoint } = loadTool().Tool.core.cadEngine;
  assert.deepEqual(plain(parsePoint("10.5, -20")), { x: 10.5, y: 20 });
  assert.deepEqual(plain(parsePoint("@10,20", { x: 30, y: 40 })), { x: 40, y: 20 });
  const up = parsePoint("@50<90", { x: 100, y: 100 });
  close(up.x, 100); close(up.y, 50);
  assert.deepEqual(plain(parsePoint("1e2,2e1")), { x: 100, y: -20 });
  ["", "10", "10,", ",20", "10,20garbage", "@NaN,2", "Infinity,0", "@-5<90", "@5<", "1e999,0"].forEach((input) => assert.equal(parsePoint(input), null, input));
  assert.equal(parsePoint("@5,10", { x: NaN, y: 0 }), null);
});

test("CAD normalizes persisted entities, settings and layers without retaining invalid geometry", () => {
  const { normalizeState } = loadTool().Tool.core.cadEngine;
  const state = normalizeState({
    entities: [
      { id: "kept", type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 }, layer: "PIPE" },
      { id: "kept", type: "circle", center: { x: 15, y: 5 }, radius: 2 },
      { type: "circle", center: { x: 0, y: 0 }, radius: -1 },
      { type: "line", a: { x: null, y: 1 }, b: { x: 5, y: 5 } },
      { type: "rect", a: { x: 1, y: 2 }, b: { x: 11, y: 12 } },
      { type: "unknown" },
    ],
    layers: [{ name: "PIPE", color: "#ff0000", locked: true }, { name: "PIPE", visible: false }],
    selectedIds: ["kept", "missing", "kept"],
    settings: { gridSize: -20, lineWidth: NaN, color: "url(bad)", ortho: true, objectSnap: false, unit: "bad", layer: "missing" },
  });
  assert.equal(state.entities.length, 3);
  assert.equal(state.entities[0].id, "kept");
  assert.equal(new Set(state.entities.map((entity) => entity.id)).size, 3);
  assert.deepEqual(plain(state.entities[2].points), [{ x: 1, y: 2 }, { x: 11, y: 2 }, { x: 11, y: 12 }, { x: 1, y: 12 }]);
  assert.deepEqual(plain(state.layers.find((layer) => layer.name === "PIPE")), { name: "PIPE", color: "#ff0000", locked: true, visible: true });
  assert.deepEqual(plain(state.selectedIds), ["kept"]);
  assert.equal(state.settings.gridSize, 10);
  assert.equal(state.settings.lineWidth, 1.5);
  assert.equal(state.settings.color, "#e2e8f0");
  assert.equal(state.settings.layer, "0");
  assert.equal(state.settings.ortho, true);
  assert.equal(state.settings.objectSnap, false);
  assert.deepEqual(plain(normalizeState(JSON.parse(JSON.stringify(state)))), plain(state));
});

test("CAD makes group edits atomic, preserves stable IDs and supports undo/redo after clearing", () => {
  const changes = [];
  const engine = create({ onChange: (snapshot, reason) => changes.push({ snapshot, reason }) });
  const pair = engine.add([
    { type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 } },
    { type: "circle", center: { x: 20, y: 20 }, radius: 5 },
  ]);
  assert.equal(pair.length, 2);
  assert.equal(changes.length, 1);
  assert.equal(engine.canUndo, true);
  assert.equal(engine.undo(), true);
  assert.equal(engine.state.entities.length, 0);
  assert.equal(engine.redo(), true);
  assert.deepEqual(plain(engine.state.entities.map((entity) => entity.id)), plain(pair.map((entity) => entity.id)));
  const saved = engine.snapshot();
  saved.entities[0].a.x = 999;
  assert.equal(engine.state.entities[0].a.x, 0);
  assert.equal(engine.clear(), 2);
  assert.equal(engine.undo(), true);
  assert.equal(engine.state.entities.length, 2);
  assert.equal(engine.add([{ type: "line", a: { x: 0, y: 0 }, b: { x: 1, y: 0 } }, { type: "circle", radius: 1 }]).length, 0);
  assert.equal(engine.state.entities.length, 2);
  engine.remove(pair[0].id);
  assert.equal(engine.canRedo, false);
});

test("CAD bounds, stroke hit tests and window/crossing selection respect real geometry", () => {
  const engine = create();
  const rect = engine.add({ type: "rect", a: { x: 0, y: 0 }, b: { x: 20, y: 10 } });
  const circle = engine.add({ type: "circle", center: { x: 40, y: 10 }, radius: 5 });
  const line = engine.add({ type: "line", a: { x: 60, y: 0 }, b: { x: 80, y: 20 } });
  assert.deepEqual(plain(engine.bounds()), { minX: 0, minY: 0, maxX: 80, maxY: 20, width: 80, height: 20 });
  assert.equal(engine.hitTest({ x: 10, y: 0.5 }, 1).id, rect.id);
  assert.equal(engine.hitTest({ x: 10, y: 5 }, 1), null);
  assert.equal(engine.hitTest({ x: 40, y: 10 }, 1), null);
  assert.equal(engine.hitTest({ x: 45, y: 10 }, 1).id, circle.id);
  assert.deepEqual(plain(engine.boxSelect({ x: -1, y: -1 }, { x: 21, y: 11 })), [rect.id]);
  assert.deepEqual(plain(engine.boxSelect({ x: 19, y: 4 }, { x: 21, y: 6 }, true)), [rect.id]);
  assert.deepEqual(plain(engine.boxSelect({ x: 2, y: 2 }, { x: 18, y: 8 }, true)), []);
  assert.deepEqual(plain(engine.boxSelect({ x: 61, y: 15 }, { x: 65, y: 19 }, true)), []);
  assert.deepEqual(plain(engine.boxSelect({ x: 69, y: 9 }, { x: 71, y: 11 }, true)), [line.id]);
});

test("CAD snaps endpoints, midpoints, centers and line/circle intersections", () => {
  const engine = create();
  engine.add({ type: "line", a: { x: 0, y: 0 }, b: { x: 20, y: 0 } });
  engine.add({ type: "line", a: { x: 7, y: -10 }, b: { x: 7, y: 10 } });
  const circle = engine.add({ type: "circle", center: { x: 40, y: 0 }, radius: 5 });
  engine.add({ type: "line", a: { x: 30, y: 3 }, b: { x: 50, y: 3 } });
  assert.equal(engine.snap({ x: 0.2, y: 0.3 }, 1).type, "endpoint");
  assert.equal(engine.snap({ x: 10.2, y: 0.3 }, 1).type, "midpoint");
  const center = engine.snap({ x: 40.2, y: 0.3 }, 1);
  assert.equal(center.type, "center");
  assert.equal(center.entityId, circle.id);
  const intersection = engine.snap({ x: 7.1, y: 0.2 }, 1);
  assert.equal(intersection.type, "intersection");
  assert.deepEqual(plain(intersection.point), { x: 7, y: 0 });
  const circleIntersection = engine.snap({ x: 44.1, y: 3.1 }, 1);
  assert.equal(circleIntersection.type, "intersection");
  assert.deepEqual(plain(circleIntersection.point), { x: 44, y: 3 });
  assert.equal(engine.snap({ x: 999, y: 999 }, 1), null);
});

test("CAD move/copy/rotate/scale/mirror preserve geometry and histories", () => {
  const engine = create();
  const line = engine.add({ type: "line", a: { x: 10, y: 0 }, b: { x: 20, y: 0 } });
  const moved = engine.transform([line.id], { type: "move", delta: { x: 5, y: 10 } })[0];
  assert.equal(moved.id, line.id);
  assert.deepEqual(plain(moved.a), { x: 15, y: 10 });
  const copied = engine.transform([line.id], { type: "copy", delta: { x: 0, y: 20 } })[0];
  assert.notEqual(copied.id, line.id);
  assert.equal(engine.state.entities.length, 2);
  engine.transform([line.id], { type: "rotate", base: { x: 0, y: 0 }, angle: 90 });
  const rotated = engine.state.entities.find((entity) => entity.id === line.id);
  close(rotated.a.x, 10); close(rotated.a.y, -15);
  engine.transform([line.id], { type: "scale", base: { x: 0, y: 0 }, factor: 2 });
  const scaled = engine.state.entities.find((entity) => entity.id === line.id);
  close(scaled.a.x, 20); close(scaled.a.y, -30);
  engine.transform([line.id], { type: "mirror", axisA: { x: 0, y: 0 }, axisB: { x: 0, y: 1 } });
  const mirrored = engine.state.entities.find((entity) => entity.id === line.id);
  close(mirrored.a.x, -20); close(mirrored.a.y, -30);
  assert.equal(engine.undo(), true);
  close(engine.state.entities.find((entity) => entity.id === line.id).a.x, 20);
  const rect = engine.add({ type: "rect", a: { x: 0, y: 0 }, b: { x: 10, y: 20 } });
  const rectangleRotated = engine.transform([rect.id], { type: "rotate", angle: 90 })[0];
  close(rectangleRotated.points[2].x, 20); close(rectangleRotated.points[2].y, -10);
});

test("CAD offsets lines, circles, rectangles and joined polylines towards chosen side", () => {
  const engine = create();
  const line = engine.add({ type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 } });
  assert.deepEqual(plain(engine.offset(line.id, 5, { x: 2, y: -1 }).a), { x: 0, y: -5 });
  const circle = engine.add({ type: "circle", center: { x: 30, y: 0 }, radius: 10 });
  assert.equal(engine.offset(circle.id, 3, { x: 30, y: 0 }).radius, 7);
  assert.equal(engine.offset(circle.id, 20, { x: 30, y: 0 }), null);
  const rectangle = engine.add({ type: "rect", a: { x: 0, y: 20 }, b: { x: 20, y: 40 } });
  const inset = engine.offset(rectangle.id, 2, { x: 10, y: 30 });
  assert.deepEqual(plain(inset.points), [{ x: 2, y: 22 }, { x: 18, y: 22 }, { x: 18, y: 38 }, { x: 2, y: 38 }]);
  assert.equal(engine.offset(rectangle.id, 15, { x: 10, y: 30 }), null);
  const polyline = engine.add({ type: "polyline", points: [{ x: 0, y: 60 }, { x: 20, y: 60 }, { x: 20, y: 80 }] });
  const shifted = engine.offset(polyline.id, 2, { x: 10, y: 61 });
  assert.deepEqual(plain(shifted.points), [{ x: 0, y: 62 }, { x: 18, y: 62 }, { x: 18, y: 80 }]);
});

test("CAD trimming removes clicked interval between crossing entities and restores atomically", () => {
  const engine = create();
  const main = engine.add({ type: "line", a: { x: 0, y: 0 }, b: { x: 100, y: 0 } });
  engine.add([
    { type: "line", a: { x: 20, y: -10 }, b: { x: 20, y: 10 } },
    { type: "line", a: { x: 80, y: -10 }, b: { x: 80, y: 10 } },
  ]);
  assert.equal(engine.trim(main.id, { x: 50, y: 1 }), true);
  const horizontal = engine.state.entities.filter((entity) => entity.a.y === 0 && entity.b.y === 0);
  assert.deepEqual(plain(horizontal.map((entity) => [entity.a.x, entity.b.x])), [[0, 20], [80, 100]]);
  assert.equal(horizontal[0].id, main.id);
  assert.notEqual(horizontal[1].id, main.id);
  engine.undo();
  assert.equal(engine.state.entities.length, 3);
  assert.equal(engine.state.entities.find((entity) => entity.id === main.id).b.x, 100);
  assert.equal(engine.trim(main.id, { x: 5, y: 0 }), true);
  assert.equal(engine.state.entities.find((entity) => entity.id === main.id).a.x, 20);
  engine.undo();
  engine.remove(engine.state.entities.filter((entity) => entity.id !== main.id).map((entity) => entity.id));
  engine.add({ type: "circle", center: { x: 50, y: 0 }, radius: 10 });
  assert.equal(engine.trim(main.id, { x: 50, y: 0 }), true);
  assert.deepEqual(plain(engine.state.entities.filter((entity) => entity.type === "line").map((entity) => [entity.a.x, entity.b.x])), [[0, 40], [60, 100]]);
});

test("CAD hidden and locked layers cannot be selected or edited but visible locked geometry still snaps", () => {
  const engine = create();
  engine.setLayer("PIPE", { color: "#00ff00" });
  engine.setSettings({ layer: "PIPE", ortho: true, unit: "cm" });
  const line = engine.add({ type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 } });
  assert.equal(line.layer, "PIPE");
  engine.select([line.id]);
  engine.setLayer("PIPE", { locked: true });
  assert.equal(engine.state.selectedIds.length, 0);
  assert.equal(engine.hitTest({ x: 0, y: 0 }, 2), null);
  assert.equal(engine.snap({ x: 0, y: 0 }, 2).entityId, line.id);
  assert.equal(engine.remove([line.id]), 0);
  assert.equal(engine.transform([line.id], { type: "move", delta: { x: 5, y: 0 } }).length, 0);
  engine.setLayer("PIPE", { visible: false });
  assert.equal(engine.snap({ x: 0, y: 0 }, 2), null);
  assert.equal(engine.bounds(), null);
  assert.equal(engine.add({ type: "circle", center: { x: 0, y: 0 }, radius: 3 }), null);
  const restored = create({ initialState: JSON.parse(JSON.stringify(engine.snapshot())) });
  assert.deepEqual(plain(restored.snapshot()), plain(engine.snapshot()));
});

test("CAD arc geometry rotates and mirrors its sweep and dimensions preserve signed offsets", () => {
  const engine = create();
  const arc = engine.add({ type: "arc", center: { x: 0, y: 0 }, radius: 10, startAngle: 0, endAngle: Math.PI / 2, clockwise: true });
  assert.equal(engine.hitTest({ x: Math.sqrt(50), y: Math.sqrt(50) }, 0.1).id, arc.id);
  assert.equal(engine.hitTest({ x: -10, y: 0 }, 0.1), null);
  assert.deepEqual(plain(engine.bounds([arc.id])), { minX: 6.123233995736766e-16, minY: 0, maxX: 10, maxY: 10, width: 10, height: 10 });
  const mirrored = engine.transform([arc.id], { type: "mirror", axisA: { x: 0, y: 0 }, axisB: { x: 0, y: 1 } })[0];
  assert.equal(mirrored.clockwise, false);
  assert.equal(engine.hitTest({ x: -Math.sqrt(50), y: Math.sqrt(50) }, 0.1).id, arc.id);
  const dimension = engine.add({ type: "dimension", a: { x: 0, y: 20 }, b: { x: 10, y: 20 }, offset: 5 });
  const mirroredDimension = engine.transform([dimension.id], { type: "mirror", axisA: { x: 0, y: 0 }, axisB: { x: 0, y: 1 } })[0];
  assert.equal(mirroredDimension.offset, -5);
  const scaled = engine.transform([dimension.id], { type: "scale", factor: 2 })[0];
  assert.equal(scaled.offset, -10);
  assert.equal(scaled.textSize, 32);
});

test("CAD full circular arcs keep their sweep through rotation and reflection", () => {
  const engine = create();
  const full = engine.add({ type: "arc", center: { x: 50, y: 50 }, radius: 10, startAngle: 0, endAngle: Math.PI * 2, clockwise: true });
  assert.deepEqual(plain(engine.bounds()), { minX: 40, minY: 40, maxX: 60, maxY: 60, width: 20, height: 20 });
  assert.equal(engine.hitTest({ x: 40, y: 50 }, 0.1).id, full.id);
  const rotated = engine.transform([full.id], { type: "rotate", base: { x: 50, y: 50 }, angle: 45 })[0];
  close(Math.abs(rotated.endAngle - rotated.startAngle), Math.PI * 2);
  assert.equal(engine.hitTest({ x: 50, y: 60 }, 0.1).id, full.id);
  const reflected = engine.transform([full.id], { type: "mirror", axisA: { x: 50, y: 0 }, axisB: { x: 50, y: 100 } })[0];
  close(Math.abs(reflected.endAngle - reflected.startAngle), Math.PI * 2);
  assert.equal(reflected.clockwise, false);
  assert.equal(engine.hitTest({ x: 60, y: 50 }, 0.1).id, full.id);
});

test("CAD dimension bounds and hits include long custom labels and multiline text", () => {
  const engine = create();
  const dimension = engine.add({ type: "dimension", a: { x: 0, y: 0 }, b: { x: 10, y: 0 }, offset: 20, textSize: 16, text: "LONG CUSTOM DIMENSION LABEL" });
  const extent = engine.bounds([dimension.id]);
  assert.ok(extent.minX < -50);
  assert.ok(extent.maxX > 50);
  assert.ok(extent.maxY > 30);
  assert.equal(engine.hitTest({ x: 5, y: 31.2 }, 0.1).id, dimension.id);
  const text = engine.add({ type: "text", point: { x: 100, y: 100 }, text: "가나다\nABC", textSize: 20 });
  const textExtent = engine.bounds([text.id]);
  assert.ok(textExtent.maxX >= 160);
  assert.ok(textExtent.maxY >= 129);
  assert.equal(engine.hitTest({ x: 110, y: 120 }, 0.1).id, text.id);
});

test("CAD autogenerated IDs do not consume supplied IDs later in the same batch or snapshot", () => {
  const engine = create();
  const added = engine.add([
    { type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 } },
    { id: "cad-1", type: "line", a: { x: 0, y: 10 }, b: { x: 10, y: 10 } },
  ]);
  assert.equal(added[1].id, "cad-1");
  assert.notEqual(added[0].id, "cad-1");
  const { normalizeState } = loadTool().Tool.core.cadEngine;
  const hydrated = normalizeState({ entities: [
    { type: "line", a: { x: 0, y: 0 }, b: { x: 10, y: 0 } },
    { id: "cad-1", type: "line", a: { x: 0, y: 10 }, b: { x: 10, y: 10 } },
  ] });
  assert.equal(hydrated.entities[1].id, "cad-1");
  assert.notEqual(hydrated.entities[0].id, "cad-1");
});

test("CAD applies selected properties and drawing defaults in one undo step while preserving locked objects", () => {
  const changes = [];
  const engine = create({ onChange: (_, reason) => changes.push(reason) });
  engine.setLayer("LOCKED");
  const [line, text, locked] = engine.add([
    { type: "line", a: { x: 0, y: 0 }, b: { x: 20, y: 0 }, color: "#aa0000", lineWidth: 1 },
    { type: "text", point: { x: 0, y: 30 }, text: "Label", textSize: 12, color: "#0000aa", lineWidth: 2 },
    { type: "circle", layer: "LOCKED", center: { x: 50, y: 50 }, radius: 5, color: "#00aa00", lineWidth: 3 },
  ]);
  engine.setLayer("LOCKED", { locked: true });
  engine.select([line.id, text.id]);
  const before = plain(engine.snapshot());
  const countBefore = changes.length;
  engine.applyProperties({ color: "#1199dd", lineWidth: 2.75, textSize: 24 }, [line.id, text.id, locked.id]);
  const after = plain(engine.snapshot());
  assert.equal(changes.length, countBefore + 1);
  assert.equal(changes.at(-1), "properties");
  assert.equal(engine.state.settings.color, "#1199dd");
  assert.equal(engine.state.settings.lineWidth, 2.75);
  assert.equal(engine.state.settings.textSize, 24);
  const changedLine = engine.state.entities.find((entity) => entity.id === line.id);
  const changedText = engine.state.entities.find((entity) => entity.id === text.id);
  assert.equal(changedLine.color, "#1199dd");
  assert.equal(changedLine.lineWidth, 2.75);
  assert.equal(changedText.color, "#1199dd");
  assert.equal(changedText.lineWidth, 2.75);
  assert.equal(changedText.textSize, 24);
  assert.deepEqual(plain(engine.state.entities.find((entity) => entity.id === locked.id)), plain(locked));
  assert.equal(engine.undo(), true);
  assert.deepEqual(plain(engine.snapshot()), before);
  assert.equal(engine.redo(), true);
  assert.deepEqual(plain(engine.snapshot()), after);
  engine.applyProperties({ color: "#ff00ff" });
  assert.equal(engine.state.entities.find((entity) => entity.id === line.id).color, "#ff00ff");
  assert.equal(engine.state.entities.find((entity) => entity.id === text.id).color, "#ff00ff");
  assert.equal(engine.state.entities.find((entity) => entity.id === locked.id).color, "#00aa00");
});
