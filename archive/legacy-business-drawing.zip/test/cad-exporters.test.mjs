import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";

function loadExporters(overrides = {}) {
  const downloads = [];
  const Tool = { core: { drawingExporters: {
    baseName: (name) => String(name).replace(/\.[^.]+$/, "").replace(/[\\/:*?"<>|]+/g, "_"),
    downloadBlob: (blob, filename) => downloads.push({ blob, filename }),
  } } };
  const context = vm.createContext({ window: { HeechangTool: Tool }, Blob, ...overrides });
  vm.runInContext(fs.readFileSync(new URL("../src/features/drawing/cad-exporters.js", import.meta.url), "utf8"), context);
  return { exporters: Tool.core.cadExporters, downloads };
}

function dxfRecords(value) {
  const lines = value.trimEnd().split(/\r?\n/);
  const records = [];
  let record;
  for (let index = 0; index < lines.length; index += 2) {
    const code = Number(lines[index]), value = lines[index + 1];
    if (code === 0) { record = { type: value, groups: new Map() }; records.push(record); }
    else if (record) record.groups.set(code, value);
  }
  return records;
}

const drawing = {
  name: "간이 도면 <A>", version: 1, settings: { unit: "mm" },
  layers: [{ name: "구조", color: "#e2e8f0", visible: true }, { name: "숨김", color: "#ef4444", visible: false, locked: true }],
  entities: [
    { id: "line", type: "line", layer: "구조", a: { x: 10, y: 20 }, b: { x: 40, y: 30 } },
    { id: "rect", type: "rect", layer: "구조", points: [{ x: 0, y: 0 }, { x: 20, y: 10 }, { x: 15, y: 20 }, { x: -5, y: 10 }] },
    { id: "polyline", type: "polyline", layer: "구조", points: [{ x: 5, y: 5 }, { x: 10, y: 10 }] },
    { id: "circle", type: "circle", layer: "구조", center: { x: 50, y: 40 }, radius: 8 },
    { id: "arc", type: "arc", layer: "구조", center: { x: 50, y: 40 }, radius: 12, startAngle: 0, endAngle: Math.PI / 2, clockwise: true },
    { id: "text", type: "text", layer: "구조", point: { x: 0, y: 70 }, text: '도면 <A> & "B"\n상세', textSize: 8, rotation: Math.PI / 2 },
    { id: "dimension", type: "dimension", layer: "구조", a: { x: 0, y: 0 }, b: { x: 30, y: 40 }, offset: 20 },
    { id: "hidden", type: "line", layer: "숨김", a: { x: 1000, y: 1000 }, b: { x: 1100, y: 1100 } },
  ],
};

test("CAD DXF preserves native shapes, world measurements and upward CAD coordinates", () => {
  const { exporters } = loadExporters();
  const dxf = exporters.toDxf(drawing), records = dxfRecords(dxf);
  assert.match(dxf, /\$INSUNITS\r\n70\r\n4\r\n/);
  const line = records.find((record) => record.type === "LINE");
  assert.equal(line.groups.get(10), "10");
  assert.equal(line.groups.get(20), "-20");
  assert.equal(line.groups.get(11), "40");
  assert.equal(line.groups.get(21), "-30");
  const rectangle = records.find((record) => record.type === "POLYLINE");
  assert.equal(rectangle.groups.get(70), "1");
  const vertex = records.find((record) => record.type === "VERTEX" && record.groups.get(10) === "20");
  assert.equal(vertex.groups.get(20), "-10");
  const circle = records.find((record) => record.type === "CIRCLE");
  assert.equal(circle.groups.get(40), "8");
  assert.equal(circle.groups.get(20), "-40");
  const arc = records.find((record) => record.type === "ARC");
  assert.equal(arc.groups.get(50), "270");
  assert.equal(arc.groups.get(51), "0");
  const text = records.find((record) => record.type === "TEXT");
  assert.equal(text.groups.get(50), "270");
  assert.equal(text.groups.get(1), '도면 <A> & "B" 상세');
  assert.ok(records.some((record) => record.type === "TEXT" && record.groups.get(1) === "50mm"));
  assert.ok(dxf.endsWith("0\r\nEOF\r\n"));
});

test("CAD DXF retains hidden and locked layers and normalizes unsafe layer characters", () => {
  const { exporters } = loadExporters();
  const records = dxfRecords(exporters.toDxf({ ...drawing, entities: [...drawing.entities, { type: "line", layer: "A/B:1", a: { x: 0, y: 0 }, b: { x: 2, y: 2 } }] }));
  const hidden = records.find((record) => record.type === "LAYER" && record.groups.get(2) === "숨김");
  assert.equal(hidden.groups.get(62), "-7");
  assert.equal(hidden.groups.get(70), "4");
  assert.ok(records.some((record) => record.type === "LINE" && record.groups.get(8) === "숨김"));
  assert.ok(records.some((record) => record.type === "LAYER" && record.groups.get(2) === "A_B_1"));
  assert.ok(records.some((record) => record.type === "LINE" && record.groups.get(8) === "A_B_1"));
});

test("CAD DXF preserves colors and keeps sanitized layer names distinct", () => {
  const { exporters } = loadExporters();
  const snapshot = { layers: [{ name: "A/B", color: "#e2e8f0" }, { name: "A_B", color: "#123456" }], entities: [
    { type: "line", layer: "A/B", color: "#e2e8f0", a: { x: 0, y: 0 }, b: { x: 1, y: 1 } },
    { type: "line", layer: "A_B", a: { x: 2, y: 2 }, b: { x: 3, y: 3 } },
  ] };
  const records = dxfRecords(exporters.toDxf(snapshot));
  const layers = records.filter((record) => record.type === "LAYER");
  assert.equal(new Set(layers.map((record) => record.groups.get(2))).size, layers.length);
  const lines = records.filter((record) => record.type === "LINE");
  assert.notEqual(lines[0].groups.get(8), lines[1].groups.get(8));
  assert.equal(lines[0].groups.get(420), String(parseInt("e2e8f0", 16)));
});

test("CAD SVG uses visible layers, XML escaping, readable colors and all primitive types", () => {
  const { exporters } = loadExporters();
  const svg = exporters.toSvg(drawing);
  assert.match(svg, /<svg xmlns="http:\/\/www.w3.org\/2000\/svg"/);
  assert.match(svg, /<rect[^>]+fill="#ffffff"/);
  assert.match(svg, /<title>간이 도면 &lt;A&gt;<\/title>/);
  assert.match(svg, /도면 &lt;A&gt; &amp; &quot;B&quot;/);
  assert.match(svg, /<tspan x="0" dy="10">상세<\/tspan>/);
  assert.match(svg, /50mm/);
  assert.match(svg, /<circle /);
  assert.match(svg, /<polyline /);
  assert.match(svg, /<polygon points="0,0 20,10 15,20 -5,10"/);
  assert.match(svg, /<path d="M 62,40 A 12 12 0 0 1 50,52"/);
  assert.doesNotMatch(svg, /data-layer="숨김"/);
  assert.doesNotMatch(svg, /stroke="#e2e8f0"/);
  assert.doesNotMatch(svg, /1100/);
  assert.doesNotMatch(svg, /NaN|Infinity/);
});

test("CAD handles counterclockwise and full arcs and diagonal rectangle fallback", () => {
  const { exporters } = loadExporters();
  const snapshot = { entities: [
    { type: "arc", center: { x: 0, y: 0 }, radius: 10, startAngle: 0, endAngle: -Math.PI / 2 },
    { type: "arc", center: { x: 0, y: 0 }, radius: 5, startAngle: 0, endAngle: Math.PI * 2 },
    { type: "rect", a: { x: 2, y: 3 }, b: { x: 4, y: 5 } },
  ] };
  const records = dxfRecords(exporters.toDxf(snapshot));
  const arc = records.find((record) => record.type === "ARC");
  assert.equal(arc.groups.get(50), "0");
  assert.equal(arc.groups.get(51), "90");
  assert.equal(records.filter((record) => record.type === "CIRCLE").length, 1);
  const svg = exporters.toSvg(snapshot);
  assert.match(svg, /A 10 10 0 0 0 0,-10/);
  assert.match(svg, /<circle cx="0" cy="0" r="5"/);
  assert.match(svg, /points="2,3 4,3 4,5 2,5"/);
  const unitless = exporters.toSvg({ settings: { unit: "" }, entities: [{ type: "dimension", a: { x: 0, y: 0 }, b: { x: 3, y: 4 }, offset: 10 }] });
  assert.match(unitless, /<tspan x="0" dy="0">5<\/tspan>/);
  assert.doesNotMatch(unitless, /5mm/);
});

test("CAD JSON downloads are portable snapshots and vector downloads have correct file types", async () => {
  const { exporters, downloads } = loadExporters();
  await exporters.download(drawing, "json");
  await exporters.download(drawing, "svg");
  await exporters.download(drawing, "dxf");
  const reopened = JSON.parse(await downloads[0].blob.text());
  assert.equal(reopened.format, "heechang-cad");
  assert.equal(reopened.version, 1);
  assert.deepEqual(reopened.entities, drawing.entities);
  assert.deepEqual(reopened.layers, drawing.layers);
  assert.match(downloads[0].filename, /\.json$/);
  assert.equal(downloads[1].blob.type, "image/svg+xml;charset=utf-8");
  assert.equal(downloads[2].blob.type, "application/dxf;charset=utf-8");
  await assert.rejects(exporters.download(drawing, "unsupported"), /지원하지 않는/);
});

test("CAD PNG excludes hidden layers and bounds image size while drawing every primitive", async () => {
  const calls = [];
  const context = new Proxy({}, { set(target, key, value) { target[key] = value; return true; }, get(target, key) { return key in target ? target[key] : (...args) => calls.push([key, ...args]); } });
  const canvas = { getContext: () => context, toBlob: (callback) => callback(new Blob(["png"], { type: "image/png" })) };
  const { exporters, downloads } = loadExporters({ document: { createElement: () => canvas } });
  await exporters.download(drawing, "png");
  assert.equal(downloads[0].blob.type, "image/png");
  assert.ok(canvas.width >= 128 && canvas.width <= 2464);
  assert.ok(canvas.height >= 128 && canvas.height <= 2464);
  assert.ok(calls.some(([method]) => method === "fillText"));
  assert.ok(calls.some(([method]) => method === "arc"));
  assert.ok(calls.some(([method]) => method === "closePath"));
  assert.ok(!calls.some(([method, x, y]) => method === "moveTo" && x === 1000 && y === 1000));
  calls.length = 0;
  exporters.drawEntity(context, { type: "line", a: { x: 1, y: 2 }, b: { x: 3, y: 4 }, lineWidth: 2 }, { scale: 4 });
  assert.equal(context.lineWidth, 0.5);
  assert.ok(calls.some(([method, x, y]) => method === "moveTo" && x === 1 && y === 2));
});
