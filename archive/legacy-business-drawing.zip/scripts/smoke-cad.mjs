import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import projectConfig from "../project.config.mjs";

const STORAGE_KEY = "heechang-integrated-inspection-log:v2";
const delay = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function firstExisting(candidates) {
  for (const candidate of candidates) {
    try { await fs.access(candidate); return candidate; } catch {}
  }
  throw new Error("Microsoft Edge was not found.");
}

async function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
  });
}

async function pageTarget(port) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const pages = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
      const page = pages.find((item) => item.type === "page" && item.webSocketDebuggerUrl);
      if (page) return page;
    } catch {}
    await delay(100);
  }
  throw new Error("Headless Edge did not expose a page target.");
}

class CdpClient {
  constructor(url) {
    this.socket = new WebSocket(url);
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Map();
  }

  async open() {
    await new Promise((resolve, reject) => {
      this.socket.addEventListener("open", resolve, { once: true });
      this.socket.addEventListener("error", reject, { once: true });
    });
    this.socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const pending = this.pending.get(message.id);
        if (!pending) return;
        this.pending.delete(message.id);
        clearTimeout(pending.timeout);
        if (message.error) pending.reject(new Error(`${message.error.code}: ${message.error.message}`));
        else pending.resolve(message.result);
      } else this.listeners.get(message.method)?.forEach((listener) => listener(message.params));
    });
  }

  send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP ${method} timed out.`));
      }, 15_000);
      this.pending.set(id, { resolve, reject, timeout });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }

  on(method, listener) {
    if (!this.listeners.has(method)) this.listeners.set(method, new Set());
    this.listeners.get(method).add(listener);
  }

  waitFor(method, timeout = 10_000) {
    return new Promise((resolve, reject) => {
      const handler = (params) => {
        clearTimeout(timer);
        this.listeners.get(method)?.delete(handler);
        resolve(params);
      };
      const timer = setTimeout(() => {
        this.listeners.get(method)?.delete(handler);
        reject(new Error(`CDP event ${method} timed out.`));
      }, timeout);
      this.on(method, handler);
    });
  }

  close() { this.socket.close(); }
}

function assert(condition, message, details) {
  if (!condition) throw new Error(`${message}${details === undefined ? "" : `: ${JSON.stringify(details)}`}`);
}

function close(actual, expected, label, tolerance = 0.01) {
  assert(Number.isFinite(actual) && Math.abs(actual - expected) <= tolerance, label, { actual, expected });
}

const edgePath = await firstExisting([
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
  path.join(os.homedir(), "AppData", "Local", "Microsoft", "Edge", "Application", "msedge.exe"),
]);
const temporaryRoot = await fs.mkdtemp(path.join(os.tmpdir(), "heechang-cad-smoke-"));
const profileDirectory = path.join(temporaryRoot, "profile");
const downloadDirectory = path.join(temporaryRoot, "downloads");
await fs.mkdir(downloadDirectory);
const port = await freePort();
const edge = spawn(edgePath, [
  "--headless=new", "--disable-gpu", "--disable-background-networking", "--no-first-run",
  "--no-default-browser-check", "--allow-file-access-from-files", `--remote-debugging-port=${port}`,
  `--user-data-dir=${profileDirectory}`, "--window-size=1600,1000", pathToFileURL(projectConfig.output).href,
], { stdio: "ignore", windowsHide: true });

let client;
try {
  const target = await pageTarget(port);
  client = new CdpClient(target.webSocketDebuggerUrl);
  await client.open();
  const runtimeErrors = [];
  const externalRequests = [];
  client.on("Runtime.exceptionThrown", (event) => runtimeErrors.push(event.exceptionDetails?.exception?.description || event.exceptionDetails?.text));
  client.on("Network.requestWillBeSent", ({ request }) => {
    if (!/^(file|data|blob|devtools):/.test(request?.url || "")) externalRequests.push(request.url);
  });
  await Promise.all([client.send("Page.enable"), client.send("Runtime.enable"), client.send("Network.enable")]);
  await client.send("Browser.setDownloadBehavior", { behavior: "allow", downloadPath: downloadDirectory, eventsEnabled: true });
  const acceptedDialogs = [];
  client.on("Page.javascriptDialogOpening", (event) => {
    acceptedDialogs.push(event.type);
    client.send("Page.handleJavaScriptDialog", { accept: true }).catch((error) => runtimeErrors.push(error.message));
  });

  async function evaluate(expression) {
    const response = await client.send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true, userGesture: true });
    if (response.exceptionDetails) throw new Error(response.exceptionDetails.exception?.description || response.exceptionDetails.text);
    return response.result.value;
  }

  async function waitFor(expression, label) {
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const value = await evaluate(expression);
      if (value) return value;
      await delay(40);
    }
    throw new Error(`Timed out waiting for ${label}.`);
  }

  async function rect(selector) {
    return evaluate(`(() => {
      const node = document.querySelector(${JSON.stringify(selector)});
      if (!node) return null;
      node.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      const r = node.getBoundingClientRect();
      return { x: r.x, y: r.y, width: r.width, height: r.height };
    })()`);
  }

  async function mouseClick(x, y, modifiers = 0) {
    await client.send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y, modifiers });
    await client.send("Input.dispatchMouseEvent", { type: "mousePressed", x, y, modifiers, button: "left", clickCount: 1 });
    await client.send("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, modifiers, button: "left", clickCount: 1 });
  }

  async function click(selector) {
    const bounds = await rect(selector);
    assert(bounds && bounds.width > 0 && bounds.height > 0, `Visible control missing: ${selector}`, bounds);
    await mouseClick(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
    await delay(40);
  }

  async function key(keyValue, code, modifiers = 0) {
    const keyCodes = { Enter: 13, Escape: 27, Delete: 46, F8: 119, F3: 114, F9: 120, a: 65, z: 90, y: 89 };
    const windowsVirtualKeyCode = keyCodes[keyValue] || keyValue.toUpperCase().charCodeAt(0);
    const params = { key: keyValue, code, modifiers, windowsVirtualKeyCode, nativeVirtualKeyCode: windowsVirtualKeyCode };
    await client.send("Input.dispatchKeyEvent", { type: "keyDown", ...params, ...(keyValue === "Enter" ? { text: "\r", unmodifiedText: "\r" } : {}) });
    await client.send("Input.dispatchKeyEvent", { type: "keyUp", ...params });
    await delay(30);
  }

  async function submit(value) {
    await click('[data-role="cad-command"]');
    assert(await evaluate("document.activeElement === document.querySelector('[data-role=\"cad-command\"]')"), "Pointer should focus CAD command input", await rect('[data-role="cad-command"]'));
    await key("a", "KeyA", 2);
    await client.send("Input.insertText", { text: value });
    await key("Enter", "Enter");
  }

  async function cancel() { await key("Escape", "Escape"); }

  async function snapshot() {
    await delay(500);
    return evaluate(`(() => {
      const app = JSON.parse(localStorage.getItem(${JSON.stringify(STORAGE_KEY)}));
      const drawing = app?.documents?.['drawing-dimension'];
      return drawing?.cad || drawing?.cadState || drawing?.drawing || null;
    })()`);
  }

  async function selectDocument(documentId) {
    const navigation = await evaluate(`(() => {
      const node = document.querySelector(${JSON.stringify(`[data-document="${documentId}"]`)});
      return { visible: Boolean(node?.getBoundingClientRect().width), group: node?.closest('[data-document-group]')?.dataset.documentGroup };
    })()`);
    if (!navigation.visible && navigation.group) await click(`[data-nav-group="${navigation.group}"]`);
    await click(`[data-document="${documentId}"]`);
  }

  async function reload() {
    const loaded = client.waitFor("Page.loadEventFired");
    await client.send("Page.reload", { ignoreCache: true });
    await loaded;
    await delay(150);
  }

  await waitFor("document.querySelector('[data-document=\"drawing-dimension\"]')", "drawing navigation");
  await selectDocument("drawing-dimension");
  await waitFor("document.querySelector('[data-role=\"cad-canvas\"]')?.getBoundingClientRect().width > 100", "CAD workspace");

  // Interact through the same input, pointer and shortcuts used by a person.
  // Geometry assertions use persisted document data, without calling the controller.
  const initial = await snapshot();
  assert(initial && initial.entities.length === 0, "CAD should start with an empty drawing", initial);

  await submit("L");
  await submit("0,0");
  await submit("200,0");
  await cancel();
  let state = await snapshot();
  assert(state.entities.length === 1 && state.entities[0].type === "line", "LINE command should add one line", state);
  const firstLineId = state.entities[0].id;
  close(state.entities[0].a.x, 0, "LINE start x");
  close(state.entities[0].b.x, 200, "LINE end x");

  await submit("REC");
  await submit("250,20");
  await submit("400,120");
  await cancel();
  await submit("C");
  await submit("100,150");
  await submit("40");
  await cancel();
  state = await snapshot();
  assert(state.entities.some((entity) => entity.type === "rect"), "RECTANGLE command should add a rectangle", state);
  const circle = state.entities.find((entity) => entity.type === "circle");
  assert(circle, "CIRCLE command should add a circle", state);
  close(circle.radius, 40, "CIRCLE numeric radius");

  await submit("PL");
  await submit("450,0");
  await submit("@100,0");
  await submit("@0,100");
  await submit("C");
  await cancel();
  state = await snapshot();
  const polyline = state.entities.find((entity) => entity.type === "polyline");
  assert(polyline?.closed && polyline.points.length === 3, "PLINE relative coordinates and close", polyline);
  close(polyline.points[1].x, 550, "PLINE relative x");
  close(polyline.points[2].y, -100, "PLINE relative y");

  await submit("A");
  await submit("600,200");
  await submit("650,200");
  await submit("600,250");
  await cancel();
  await submit("L");
  await submit("0,300");
  await submit("@50<45");
  await cancel();
  state = await snapshot();
  const arc = state.entities.find((entity) => entity.type === "arc");
  assert(arc, "ARC command should add an arc", state);
  close(arc.radius, 50, "ARC radius from its start point");
  const polarLine = state.entities.at(-1);
  close(Math.hypot(polarLine.b.x - polarLine.a.x, polarLine.b.y - polarLine.a.y), 50, "LINE polar length");
  close(polarLine.b.x, 50 / Math.SQRT2, "LINE polar x");
  close(polarLine.b.y, -300 - 50 / Math.SQRT2, "LINE polar Cartesian y");

  await submit("T");
  await submit("10,220");
  await submit("CAD <check> & 도면");
  await cancel();
  await submit("D");
  await submit("0,0");
  await submit("200,0");
  await submit("100,40");
  await cancel();
  state = await snapshot();
  assert(state.entities.some((entity) => entity.type === "text" && entity.text === "CAD <check> & 도면"), "TEXT command should preserve entered text", state);
  assert(state.entities.some((entity) => entity.type === "dimension"), "DIM command should add a dimension", state);

  async function canvasView() {
    return evaluate(`(() => {
      const canvas = document.querySelector('[data-role="cad-canvas"]');
      const r = canvas.getBoundingClientRect();
      return { x: r.x, y: r.y, width: r.width, height: r.height,
        scale: Number(canvas.dataset.viewScale), tx: Number(canvas.dataset.viewTx), ty: Number(canvas.dataset.viewTy) };
    })()`);
  }

  async function worldClick(point, modifiers = 0) {
    const view = await canvasView();
    assert([view.scale, view.tx, view.ty].every(Number.isFinite) && view.scale > 0, "CAD view transform should be readable", view);
    const x = view.x + view.tx + point.x * view.scale;
    const y = view.y + view.ty + point.y * view.scale;
    assert(x > view.x && x < view.x + view.width && y > view.y && y < view.y + view.height, "Drawing point should be in the visible canvas", { point, view });
    await mouseClick(x, y, modifiers);
    await delay(40);
  }

  await click('[data-cad-action="fit"]');
  await click('[data-cad-tool="select"]');
  await worldClick({ x: 100, y: 0 });
  const selected = await evaluate("Number(document.querySelector('[data-role=\"cad-selected-count\"]').textContent.replace(/[^0-9]/g, ''))");
  assert(selected === 1, "Pointer should select a single line", selected);
  const beforeMove = state.entities.find((entity) => entity.id === firstLineId);
  await submit("M");
  await submit("0,0");
  await submit("10,20");
  await cancel();
  state = await snapshot();
  const moved = state.entities.find((entity) => entity.id === firstLineId);
  close(moved.a.x, beforeMove.a.x + 10, "MOVE delta x");
  close(moved.a.y, beforeMove.a.y - 20, "MOVE Cartesian delta y");
  close(moved.b.x, beforeMove.b.x + 10, "MOVE end delta x");

  await evaluate("document.querySelector('[data-role=\"cad-canvas\"]').focus()");
  await key("z", "KeyZ", 2);
  state = await snapshot();
  assert(JSON.stringify(state.entities.find((entity) => entity.id === firstLineId)) === JSON.stringify(beforeMove), "Ctrl+Z should undo MOVE", state);
  await key("y", "KeyY", 2);
  state = await snapshot();
  assert(JSON.stringify(state.entities.find((entity) => entity.id === firstLineId)) === JSON.stringify(moved), "Ctrl+Y should redo MOVE", state);

  // Pointer-based LINE, Delete, and toolbar undo/redo verify the other input path.
  const entityCountBeforePointer = state.entities.length;
  await click('[data-cad-tool="line"]');
  let view = await canvasView();
  const pointerStart = { x: view.x + view.width * 0.12, y: view.y + view.height * 0.82 };
  const pointerEnd = { x: view.x + view.width * 0.27, y: view.y + view.height * 0.72 };
  await mouseClick(pointerStart.x, pointerStart.y);
  await mouseClick(pointerEnd.x, pointerEnd.y);
  await cancel();
  state = await snapshot();
  assert(state.entities.length === entityCountBeforePointer + 1, "Pointer LINE should add one entity", state);
  const pointerLine = state.entities.at(-1);
  assert(pointerLine.type === "line" && Math.hypot(pointerLine.b.x - pointerLine.a.x, pointerLine.b.y - pointerLine.a.y) > 0, "Pointer LINE should have nonzero length", pointerLine);
  await click('[data-cad-tool="select"]');
  await worldClick({ x: (pointerLine.a.x + pointerLine.b.x) / 2, y: (pointerLine.a.y + pointerLine.b.y) / 2 });
  await key("Delete", "Delete");
  state = await snapshot();
  assert(state.entities.length === entityCountBeforePointer, "Delete should remove the selected pointer line", state);
  await click('[data-cad-action="undo"]');
  state = await snapshot();
  assert(state.entities.length === entityCountBeforePointer + 1, "Toolbar undo should restore the erased line", state);
  await click('[data-cad-action="redo"]');
  state = await snapshot();
  assert(state.entities.length === entityCountBeforePointer, "Toolbar redo should erase the line again", state);

  await evaluate("document.querySelector('[data-role=\"cad-canvas\"]').focus()");
  const orthoBefore = state.settings.ortho;
  await key("F8", "F8");
  state = await snapshot();
  assert(state.settings.ortho === !orthoBefore, "F8 should toggle orthographic drawing", state.settings);
  await key("F8", "F8");
  view = await canvasView();
  await client.send("Input.dispatchMouseEvent", { type: "mouseWheel", x: view.x + view.width / 2, y: view.y + view.height / 2, deltaX: 0, deltaY: -120 });
  await delay(80);
  const zoomed = await canvasView();
  assert(zoomed.scale > view.scale, "Mouse wheel should zoom in", { before: view.scale, after: zoomed.scale });
  await click('[data-cad-action="fit"]');

  state = await snapshot();
  const persistedGeometry = JSON.stringify(state.entities);
  await selectDocument("daily");
  await selectDocument("drawing-dimension");
  await waitFor("document.querySelector('[data-role=\"cad-canvas\"]')", "remounted CAD canvas");
  assert(JSON.stringify((await snapshot()).entities) === persistedGeometry, "CAD geometry should survive navigation");
  await reload();
  await waitFor("document.querySelector('[data-role=\"cad-canvas\"]')", "reloaded CAD canvas");
  state = await snapshot();
  assert(JSON.stringify(state.entities) === persistedGeometry, "CAD geometry should survive reload", state);

  const downloads = {};
  let exportedJson;
  for (const format of ["svg", "dxf", "json", "png"]) {
    await click(`[data-cad-action="export-${format}"]`);
    let file;
    for (let attempt = 0; attempt < 100; attempt += 1) {
      file = (await fs.readdir(downloadDirectory)).find((name) => name.toLowerCase().endsWith(`.${format}`));
      if (file) break;
      await delay(50);
    }
    assert(file, `CAD ${format.toUpperCase()} download should finish`);
    const bytes = await fs.readFile(path.join(downloadDirectory, file));
    assert(bytes.length > 100, `${format.toUpperCase()} download should contain data`, bytes.length);
    if (format === "svg") {
      const source = bytes.toString("utf8");
      assert(source.includes('xmlns="http://www.w3.org/2000/svg"') && source.includes("<circle") && source.includes("&lt;check&gt;") && source.includes("&amp;"), "SVG export should include geometry and escape text", source.slice(0, 300));
    } else if (format === "dxf") {
      const source = bytes.toString("utf8");
      assert(source.includes("SECTION") && source.includes("ENTITIES") && source.includes("CIRCLE") && source.trimEnd().endsWith("EOF"), "DXF export should be a complete drawing", source.slice(0, 300));
    } else if (format === "json") {
      exportedJson = bytes.toString("utf8");
      const exported = JSON.parse(exportedJson);
      assert(exported.format === "heechang-cad" && JSON.stringify(exported.entities) === persistedGeometry, "JSON export should contain the persisted CAD entities", exported);
    } else assert(bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), "PNG export signature");
    downloads[format] = { file, bytes: bytes.length };
  }

  // Use an isolated temporary drawing for each edit, then reopen the exported
  // document so the final workspace and screenshot retain the original shapes.
  await click('[data-cad-action="new"]');
  state = await snapshot();
  assert(state.entities.length === 0, "New drawing should clear the entities", state);

  async function numericLine(a, b) {
    await submit("L");
    await submit(a);
    await submit(b);
    await cancel();
  }

  await click('[data-cad-tool="select"]');
  await evaluate("document.querySelector('[data-cad-tool=\"line\"]').focus()");
  await key("Enter", "Enter");
  assert(await evaluate("document.querySelector('[data-cad-tool=\"line\"]').classList.contains('is-active')"), "Enter on a focused toolbar button should activate its tool");
  await submit("0,0");
  await submit("100,0");
  await cancel();
  state = await snapshot();
  const editLine = state.entities[0];

  async function selectEditLine() {
    await click('[data-cad-tool="select"]');
    await worldClick({ x: 50, y: 0 });
    assert(await evaluate("document.querySelector('[data-role=\"cad-selected-count\"]').textContent === '1'"), "Temporary line should be selected");
  }

  async function undoEdit() {
    await submit("U");
    state = await snapshot();
    assert(state.entities.length === 1 && JSON.stringify(state.entities[0]) === JSON.stringify(editLine), "Undo should restore the temporary baseline line", state);
  }

  await selectEditLine();
  await submit("CO");
  await submit("0,0");
  await submit("@0,100");
  state = await snapshot();
  assert(state.entities.length === 2, "COPY should preserve the source and add a line", state);
  let transformed = state.entities.find((entity) => entity.id !== editLine.id);
  close(transformed.a.x, 0, "COPY start x");
  close(transformed.a.y, -100, "COPY Cartesian delta y");
  close(transformed.b.x, 100, "COPY end x");
  await undoEdit();

  await selectEditLine();
  await submit("RO");
  await submit("0,0");
  await submit("90");
  state = await snapshot();
  transformed = state.entities[0];
  close(transformed.b.x, 0, "ROTATE ninety-degree endpoint x");
  close(transformed.b.y, -100, "ROTATE positive angle should be counterclockwise");
  await undoEdit();

  await selectEditLine();
  await submit("SC");
  await submit("0,0");
  await submit("2");
  state = await snapshot();
  close(state.entities[0].b.x, 200, "SCALE factor two");
  await undoEdit();

  await selectEditLine();
  await submit("MI");
  await submit("0,0");
  await submit("0,100");
  state = await snapshot();
  assert(state.entities.length === 2, "MIRROR should retain the source and create a reflected copy", state);
  transformed = state.entities.find((entity) => entity.id !== editLine.id);
  close(transformed.b.x, -100, "MIRROR endpoint across the vertical axis");
  close(transformed.b.y, 0, "MIRROR endpoint y");
  await undoEdit();

  await submit("O");
  await submit("10");
  await worldClick({ x: 50, y: 0 });
  await submit("50,20");
  await cancel();
  state = await snapshot();
  assert(state.entities.length === 2, "OFFSET should create a parallel copy", state);
  transformed = state.entities.find((entity) => entity.id !== editLine.id);
  close(transformed.a.y, -10, "OFFSET should use the requested distance and side");
  close(transformed.b.y, -10, "OFFSET end y");
  await undoEdit();

  await numericLine("20,-20", "20,20");
  await numericLine("80,-20", "80,20");
  await submit("TR");
  await worldClick({ x: 50, y: 0 });
  await cancel();
  state = await snapshot();
  const trimmed = state.entities.filter((entity) => entity.type === "line" && Math.abs(entity.a.y) < 0.001 && Math.abs(entity.b.y) < 0.001).sort((a, b) => a.a.x - b.a.x);
  assert(state.entities.length === 4 && trimmed.length === 2, "TRIM should split the line around the removed middle segment", state);
  close(trimmed[0].a.x, 0, "TRIM left start");
  close(trimmed[0].b.x, 20, "TRIM left cut");
  close(trimmed[1].a.x, 80, "TRIM right cut");
  close(trimmed[1].b.x, 100, "TRIM right end");

  await click('[data-cad-action="new"]');
  await numericLine("0,0", "100,0");
  await click('[data-layer-visible="0"]');
  state = await snapshot();
  assert(state.layers.find((layer) => layer.name === "0")?.visible === false, "Layer visibility should turn off", state.layers);
  await click('[data-cad-tool="select"]');
  await worldClick({ x: 50, y: 0 });
  assert(await evaluate("document.querySelector('[data-role=\"cad-selected-count\"]').textContent === '0'"), "Hidden-layer entities should not be selectable");
  await click('[data-layer-visible="0"]');
  await click('[data-layer-lock="0"]');
  state = await snapshot();
  assert(state.layers.find((layer) => layer.name === "0")?.visible && state.layers.find((layer) => layer.name === "0")?.locked, "Layer should be visible and locked", state.layers);
  await worldClick({ x: 50, y: 0 });
  assert(await evaluate("document.querySelector('[data-role=\"cad-selected-count\"]').textContent === '0'"), "Locked-layer entities should not be selectable");
  await numericLine("0,50", "100,50");
  state = await snapshot();
  assert(state.entities.length === 1, "Drawing on a locked active layer should be blocked", state);
  await click('[data-layer-lock="0"]');
  await click('[data-role="cad-layer-form"] input');
  await client.send("Input.insertText", { text: "Smoke layer" });
  await key("Enter", "Enter");
  await numericLine("0,50", "100,50");
  state = await snapshot();
  assert(state.layers.some((layer) => layer.name === "Smoke layer") && state.settings.layer === "Smoke layer" && state.entities.at(-1).layer === "Smoke layer", "New layers should become active and own newly drawn entities", state);

  assert(exportedJson, "Downloaded JSON should be available for reopen");
  await evaluate(`(() => {
    const input = document.querySelector('[data-role="cad-file"]');
    const transfer = new DataTransfer();
    transfer.items.add(new File([${JSON.stringify(exportedJson)}], ${JSON.stringify(downloads.json.file)}, { type: 'application/json' }));
    input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  })()`);
  await waitFor(`Number(document.querySelector('[data-role="cad-count"]')?.textContent) === ${JSON.parse(exportedJson).entities.length}`, "reopened JSON entities");
  state = await snapshot();
  assert(JSON.stringify(state.entities) === persistedGeometry, "Reopened downloaded JSON should restore the exact original geometry", state);

  await click('[data-cad-tool="select"]');
  await worldClick({ x: 110, y: -20 });
  await worldClick({ x: circle.center.x + circle.radius, y: circle.center.y }, 8);
  state = await snapshot();
  assert(state.selectedIds.length === 2, "Shift+click should select two entities for a property edit", state.selectedIds);
  const propertyColorBefore = state.settings.color;
  const propertySelected = state.selectedIds.slice();
  await evaluate(`(() => {
    const input = document.querySelector('[data-cad-setting="color"]');
    input.value = '#ff0000';
    input.dispatchEvent(new Event('change', { bubbles: true }));
  })()`);
  state = await snapshot();
  assert(state.settings.color === "#ff0000" && state.entities.filter((entity) => propertySelected.includes(entity.id)).every((entity) => entity.color === "#ff0000"), "One color edit should apply to the settings and both selected entities", state);
  await submit("U");
  state = await snapshot();
  assert(state.settings.color === propertyColorBefore && JSON.stringify(state.entities) === persistedGeometry, "One Undo should restore all selected colors and the current color setting", state);

  await evaluate("document.querySelector('[data-drawing-mode=\"image\"]').focus()");
  await key(" ", "Space");
  await waitFor("document.querySelector('.drawing-image-workspace') && !document.querySelector('[data-role=\"cad-canvas\"]')", "image dimension workspace");
  assert(JSON.stringify((await snapshot()).entities) === persistedGeometry, "Image tab should preserve CAD entities");

  await evaluate(`(async () => {
    const source = document.createElement('canvas'); source.width = 800; source.height = 500;
    const ctx = source.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, 800, 500);
    ctx.strokeStyle = '#222222'; ctx.lineWidth = 4; ctx.strokeRect(100, 100, 600, 300);
    const blob = await new Promise((resolve) => source.toBlob(resolve, 'image/png'));
    const transfer = new DataTransfer(); transfer.items.add(new File([blob], 'cad-smoke-reference.png', { type: 'image/png' }));
    const input = document.querySelector('[data-role="file-input"]'); input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  })()`);
  await waitFor("document.querySelector('[data-role=\"busy\"]')?.hidden && document.querySelector('[data-role=\"drop-message\"]')?.hidden", "valid reference image load");
  if (await evaluate("document.querySelector('[data-action=\"toggle-ask\"]').classList.contains('is-active')")) await click('[data-action="toggle-ask"]');
  const imageCanvas = await rect('[data-role="canvas"]');
  await mouseClick(imageCanvas.x + imageCanvas.width * 0.28, imageCanvas.y + imageCanvas.height * 0.42);
  await mouseClick(imageCanvas.x + imageCanvas.width * 0.65, imageCanvas.y + imageCanvas.height * 0.60);
  await waitFor("Number(document.querySelector('[data-role=\"dimension-count\"]')?.textContent) === 1", "reference image dimension");
  await delay(500);
  const imageBeforeInvalid = await evaluate(`JSON.parse(localStorage.getItem(${JSON.stringify(STORAGE_KEY)})).documents['drawing-dimension']`);
  assert(imageBeforeInvalid.image?.name === "cad-smoke-reference.png" && imageBeforeInvalid.dimensions.length === 1, "Valid reference image should have saved metadata and a dimension", imageBeforeInvalid.image);
  await evaluate(`(() => {
    const transfer = new DataTransfer(); transfer.items.add(new File(['not a PNG'], 'corrupt-reference.png', { type: 'image/png' }));
    const input = document.querySelector('[data-role="file-input"]'); input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  })()`);
  await waitFor("document.querySelector('[data-role=\"busy\"]')?.hidden", "corrupt image rejection");
  await delay(500);
  const imageAfterInvalid = await evaluate(`JSON.parse(localStorage.getItem(${JSON.stringify(STORAGE_KEY)})).documents['drawing-dimension']`);
  assert(JSON.stringify(imageAfterInvalid.image) === JSON.stringify(imageBeforeInvalid.image) && JSON.stringify(imageAfterInvalid.dimensions) === JSON.stringify(imageBeforeInvalid.dimensions), "A corrupt image should preserve the previous image metadata and dimensions", imageAfterInvalid.image);

  await click('[data-drawing-mode="cad"]');
  await waitFor("document.querySelector('[data-role=\"cad-canvas\"]')", "CAD tab after image mode");
  state = await snapshot();
  assert(JSON.stringify(state.entities) === persistedGeometry, "Switching back to CAD should preserve the original drawing", state);

  await evaluate(`(() => {
    const file = new File([${JSON.stringify(exportedJson)}], 'deferred.json', { type: 'application/json' });
    Object.defineProperty(file, 'text', { value: () => new Promise((resolve) => { window.__cadSmokeResolveJson = resolve; }) });
    const transfer = new DataTransfer(); transfer.items.add(file);
    const input = document.querySelector('[data-role="cad-file"]'); input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  })()`);
  await waitFor("typeof window.__cadSmokeResolveJson === 'function'", "deferred JSON read");
  await click('[data-drawing-mode="image"]');
  await evaluate(`window.__cadSmokeResolveJson(${JSON.stringify(exportedJson)}); delete window.__cadSmokeResolveJson`);
  await delay(120);
  assert(!runtimeErrors.length, "Switching away during JSON read should finish without a runtime error", runtimeErrors);
  await click('[data-drawing-mode="cad"]');
  await waitFor("document.querySelector('[data-role=\"cad-canvas\"]')", "CAD tab after deferred JSON read");
  state = await snapshot();
  assert(JSON.stringify(state.entities) === persistedGeometry, "Disposed JSON loading should preserve the original geometry", state);

  const layouts = {};
  for (const [width, height] of [[1280, 720], [1600, 1000]]) {
    await client.send("Emulation.setDeviceMetricsOverride", { width, height, deviceScaleFactor: 1, mobile: false });
    await delay(100);
    const layout = await evaluate(`(() => {
      const canvas = document.querySelector('[data-role="cad-canvas"]');
      const command = document.querySelector('[data-role="cad-command"]');
      const r = canvas.getBoundingClientRect();
      const c = command.getBoundingClientRect();
      return { width: r.width, height: r.height, documentOverflow: document.documentElement.scrollWidth > innerWidth,
        commandVisible: c.width > 80 && c.height > 0 && c.bottom <= innerHeight + 1 };
    })()`);
    assert(layout.width > 300 && layout.height > 180 && !layout.documentOverflow && layout.commandVisible, "CAD workspace should fit the viewport", { width, height, layout });
    layouts[`${width}x${height}`] = layout;
  }
  await client.send("Emulation.clearDeviceMetricsOverride");
  const screenshotPath = path.join(os.tmpdir(), "heechang-cad-workspace.png");
  const screenshot = await client.send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
  await fs.writeFile(screenshotPath, Buffer.from(screenshot.data, "base64"));
  assert(!runtimeErrors.length && !externalRequests.length, "CAD runtime errors or external network requests", { runtimeErrors, externalRequests });
  console.log(JSON.stringify({ initialEmpty: true, entityCount: state.entities.length, commands: ["L", "REC", "C", "PL", "A", "T", "D", "M", "CO", "RO", "SC", "MI", "O", "TR", "U"], relativeAndPolarCoordinates: true, pointerDrawing: true, keyboardUndoRedo: true, toolbarUndoRedo: true, navigationRestore: true, reloadRestore: true, layerVisibilityAndLock: true, downloadedJsonReopen: true, drawingTabsPreserveGeometry: true, nativeButtonKeyboardActivation: true, selectedPropertiesUndoTogether: true, disposedJsonLoadSafe: true, corruptImagePreservesPrevious: true, acceptedDialogs, downloads, layouts, screenshotPath, runtimeErrors, externalRequests }, null, 2));
} catch (error) {
  if (client) {
    try {
      const diagnostics = await client.send("Runtime.evaluate", { returnByValue: true, expression: `(() => ({
        activeDocument: document.querySelector('.nav-button.is-active')?.dataset.document,
        activeElement: document.activeElement?.outerHTML?.slice(0, 300),
        command: document.querySelector('[data-role="cad-command"]')?.value,
        hint: document.querySelector('[data-role="cad-command"]')?.placeholder,
        history: document.querySelector('[data-role="cad-history"]')?.textContent,
        count: document.querySelector('[data-role="cad-count"]')?.textContent,
        selected: document.querySelector('[data-role="cad-selected-count"]')?.textContent
      }))()` });
      console.error("CAD smoke diagnostics:", JSON.stringify(diagnostics.result.value));
      const screenshot = await client.send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
      const screenshotPath = path.join(os.tmpdir(), "heechang-cad-smoke-failure.png");
      await fs.writeFile(screenshotPath, Buffer.from(screenshot.data, "base64"));
      console.error("CAD smoke screenshot:", screenshotPath);
    } catch {}
  }
  throw error;
} finally {
  client?.close();
  edge.kill();
  await delay(400);
  const resolved = path.resolve(temporaryRoot);
  assert(resolved.startsWith(`${path.resolve(os.tmpdir())}${path.sep}`) && path.basename(resolved).startsWith("heechang-cad-smoke-"), "Unsafe temporary cleanup path", resolved);
  await fs.rm(resolved, { recursive: true, force: true, maxRetries: 8, retryDelay: 100 });
}
