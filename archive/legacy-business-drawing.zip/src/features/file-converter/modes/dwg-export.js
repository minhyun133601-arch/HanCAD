(function registerDwgExportMode(Tool) {
  "use strict";

  const registry = Tool.core.converterModes;
  const internals = Tool.core.fileConversionInternals;
  const { ensureActive, formatBytes, outputFormats, stripExtension, withExtension } = internals.shared;
  const { canvasToBlob, imageQuality } = internals.image;
  const { createPdfBlob, pdfPageLayout } = internals.pdfWriter;
  const {
    createDwgItem,
    createDwgWorker,
    dwgErrorMessage,
    getCadCore,
    isDwg,
    renderDwg,
  } = internals.dwg;
  const dwgRenderPresets = Object.freeze({
    standard: { maxSide: 1600, jpegQuality: 0.84 },
    high: { maxSide: 2400, jpegQuality: 0.9 },
    ultra: { maxSide: 3200, jpegQuality: 0.94 },
  });
  const dwgFormatOptions = [
    { value: "png", label: "PNG" },
    { value: "jpeg", label: "JPG" },
    { value: "pdf", label: "PDF" },
  ];

  async function dwgsToOutput({ items, settings, progress, cancelled }) {
    const cadCore = await getCadCore();
    const target = settings["target-format"] === "pdf" ? "pdf" : settings["target-format"];
    const format = target === "jpeg" ? outputFormats.jpeg : outputFormats.png;
    const preset = dwgRenderPresets[settings.resolution] || dwgRenderPresets.high;
    const imageEncodingQuality = imageQuality[settings.quality] || imageQuality.high;
    const entries = [];
    const pages = [];
    const warnings = [];
    for (let index = 0; index < items.length; index += 1) {
      ensureActive(cancelled);
      const item = items[index];
      let conversionWorker;
      try {
        conversionWorker = createDwgWorker(cancelled);
        progress?.(`DWG 해석 중 · ${index + 1}/${items.length}`, (index + 0.1) / items.length);
        const dxf = await conversionWorker.convert(item.file);
        conversionWorker.dispose();
        conversionWorker = null;
        ensureActive(cancelled);
        progress?.(`도면 렌더링 중 · ${index + 1}/${items.length}`, (index + 0.62) / items.length);
        const canvas = await renderDwg(dxf, settings, preset, cadCore);
        ensureActive(cancelled);
        if (target === "pdf") {
          const blob = await canvasToBlob(canvas, "image/jpeg", preset.jpegQuality);
          const bytes = new Uint8Array(await blob.arrayBuffer());
          pages.push({
            ...pdfPageLayout(canvas.width, canvas.height, settings),
            bytes,
            imageWidth: canvas.width,
            imageHeight: canvas.height,
          });
        } else {
          const blob = await canvasToBlob(canvas, format.mime, format.mime === "image/png" ? undefined : imageEncodingQuality);
          entries.push({
            name: `${String(index + 1).padStart(3, "0")}-${stripExtension(item.file.name)}.${format.extension}`,
            blob,
          });
        }
        canvas.width = 1;
        canvas.height = 1;
      } catch (error) {
        if (cancelled?.()) throw error;
        warnings.push(`${item.file.name}: ${dwgErrorMessage(error)}`);
      } finally {
        conversionWorker?.dispose();
      }
    }

    if (target === "pdf") {
      if (!pages.length) throw new Error(warnings[0] || "변환된 DWG 페이지가 없습니다.");
      return {
        blob: createPdfBlob(pages),
        fileName: withExtension(settings["output-name"], "pdf", "dwg-drawings"),
        label: "PDF 다시 받기",
        warnings,
      };
    }
    if (!entries.length) throw new Error(warnings[0] || "변환된 DWG 이미지가 없습니다.");
    const downloads = entries.map((entry) => ({
      blob: entry.blob,
      fileName: entries.length === 1 && items.length === 1
        ? `${stripExtension(items[0].file.name)}.${format.extension}`
        : entry.name,
    }));
    if (downloads.length === 1) return { ...downloads[0], label: `${format.label} 다시 받기`, warnings };
    return { downloads, label: `${format.label} ${downloads.length}장 다시 받기`, warnings };
  }

  registry.register({
    id: "dwg-export",
    label: "DWG → 이미지·PDF",
    inputFormat: "dwg",
    inputLabel: "DWG",
    outputs: dwgFormatOptions,
    outputSetting: "target-format",
    accept: ".dwg,application/acad,application/autocad_dwg,application/dwg,application/x-acad,application/x-autocad,image/vnd.dwg",
    queueKind: "dwg",
    queueLabel: "DWG",
    iconText: "DWG",
    invalidFileMessage: "DWG 파일을 선택하세요.",
    dropTitle: "DWG 도면을 놓으세요",
    dropHint: "R13 이상 · 대용량 도면은 처리 시간이 오래 걸릴 수 있습니다",
    actionTitle: "도면 출력",
    convertText: "DWG 변환",
    defaults: {
      "target-format": "png",
      "output-name": "dwg-drawings",
      resolution: "high",
      background: "light",
      quality: "high",
      "page-size": "a4",
      orientation: "auto",
      margin: "10",
    },
    fields: [
      { id: "output-name", label: "파일명", type: "text", placement: "primary", suffix: ".pdf", maxLength: 120, visible: (settings) => settings["target-format"] === "pdf" },
      {
        id: "resolution",
        label: "해상도",
        type: "select",
        options: [
          { value: "standard", label: "일반 · 1600px" },
          { value: "high", label: "선명 · 2400px" },
          { value: "ultra", label: "고해상도 · 3200px" },
        ],
        note: "파일 크기 제한 없이 순차 처리합니다. 다만 매우 큰 도면은 브라우저 메모리에 따라 실패할 수 있습니다. 2D 모델 공간 간이 출력이며 레이아웃·XRef·일부 전용 객체·글꼴은 빠질 수 있습니다. 첫 사용 시 약 7 MB 엔진을 받지만 DWG 파일은 외부로 전송하지 않습니다.",
      },
      { id: "background", label: "배경", type: "select", options: [{ value: "light", label: "흰색" }, { value: "dark", label: "어두운 CAD" }] },
      { id: "quality", label: "JPG 품질", type: "select", options: [{ value: "high", label: "높음" }, { value: "balanced", label: "보통" }, { value: "compact", label: "작은 용량" }], visible: (settings) => settings["target-format"] === "jpeg" },
      { id: "page-size", label: "페이지", type: "select", options: [{ value: "a4", label: "A4" }, { value: "letter", label: "Letter" }], visible: (settings) => settings["target-format"] === "pdf" },
      { id: "orientation", label: "방향", type: "select", options: [{ value: "auto", label: "자동" }, { value: "portrait", label: "세로" }, { value: "landscape", label: "가로" }], visible: (settings) => settings["target-format"] === "pdf" },
      { id: "margin", label: "여백", type: "select", options: [{ value: "0", label: "없음" }, { value: "5", label: "5 mm" }, { value: "10", label: "10 mm" }, { value: "15", label: "15 mm" }], visible: (settings) => settings["target-format"] === "pdf" },
    ],
    filterFiles: (files) => Array.from(files).filter(isDwg),
    createItem: createDwgItem,
    describeItem: (item) => `${item.release} · ${item.version} · ${formatBytes(item.file.size)}`,
    convert: dwgsToOutput,
  });
})(window.HeechangTool);
