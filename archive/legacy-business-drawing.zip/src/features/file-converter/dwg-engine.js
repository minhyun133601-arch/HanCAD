(function createFileConversionDwgEngine(Tool) {
  "use strict";

  const internals = Tool.core.fileConversionInternals;
  if (!internals?.shared) throw new Error("파일 변환 공통 모듈을 먼저 불러와야 합니다.");

  const { createId, ensureActive, extensionOf } = internals.shared;
  const CADVIEW_CORE_VERSION = "0.5.0";
  const CADVIEW_DWG_VERSION = "0.2.0";
  const CADVIEW_CORE_URL = `https://cdn.jsdelivr.net/npm/@cadview/core@${CADVIEW_CORE_VERSION}/+esm`;
  const CADVIEW_DWG_URL = `https://cdn.jsdelivr.net/npm/@cadview/dwg@${CADVIEW_DWG_VERSION}/+esm`;
  const CADVIEW_WASM_URL = `https://cdn.jsdelivr.net/npm/@cadview/dwg@${CADVIEW_DWG_VERSION}/dist/libredwg.wasm`;
  const dwgMimeTypes = new Set(["application/acad", "application/autocad_dwg", "application/dwg", "application/x-acad", "application/x-autocad", "image/vnd.dwg"]);
  const dwgReleases = Object.freeze({
    AC1009: "R11/R12",
    AC1012: "R13",
    AC1014: "R14",
    AC1015: "R2000",
    AC1018: "R2004",
    AC1021: "R2007",
    AC1024: "R2010",
    AC1027: "R2013",
    AC1032: "R2018 이상",
  });
  let cadCorePromise = null;

  function isDwg(file) {
    const type = String(file?.type || "").toLowerCase();
    return extensionOf(file?.name) === "dwg" || dwgMimeTypes.has(type);
  }

  function dwgVersionOf(bytes) {
    const header = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || 0);
    if (header.byteLength < 6) return "";
    const version = String.fromCharCode(...header.subarray(0, 6));
    return /^AC10\d{2}$/.test(version) ? version : "";
  }

  async function createDwgItem(file) {
    const header = new Uint8Array(await file.slice(0, 6).arrayBuffer());
    const version = dwgVersionOf(header);
    if (!version) throw new Error("DWG 파일 서명을 확인할 수 없습니다.");
    if (Number(version.slice(2)) < 1012) throw new Error("R12 이하 DWG는 지원하지 않습니다. R13 이상으로 저장한 뒤 다시 시도하세요.");
    return {
      id: createId(),
      file,
      version,
      release: dwgReleases[version] || version,
      previewUrl: "",
      dispose() {},
    };
  }

  async function getCadCore() {
    if (!cadCorePromise) {
      cadCorePromise = import(CADVIEW_CORE_URL).then((module) => {
        if (typeof module.CanvasRenderer !== "function" || typeof module.parseDxf !== "function" || typeof module.computeEntitiesBounds !== "function" || typeof module.fitToView !== "function") {
          throw new Error("CAD 렌더러 구성이 올바르지 않습니다.");
        }
        return module;
      }).catch((error) => {
        cadCorePromise = null;
        const detail = error?.message ? ` (${error.message})` : "";
        throw new Error(`DWG 변환 엔진을 불러오지 못했습니다. 인터넷 연결을 확인하세요.${detail}`);
      });
    }
    return cadCorePromise;
  }

  function createDwgWorker(cancelled) {
    if (typeof Worker !== "function" || typeof WebAssembly !== "object") {
      throw new Error("이 브라우저는 DWG 변환에 필요한 기능을 지원하지 않습니다.");
    }
    const source = `
      let modulePromise = null;
      async function getModule() {
        if (!modulePromise) modulePromise = import(${JSON.stringify(CADVIEW_DWG_URL)});
        try {
          return await modulePromise;
        } catch (error) {
          modulePromise = null;
          throw error;
        }
      }
      self.onmessage = async (event) => {
        const { id, file, timeout } = event.data;
        try {
          const module = await getModule();
          const buffer = await file.arrayBuffer();
          const dxf = await module.convertDwgToDxf(buffer, {
            timeout,
            wasmUrl: ${JSON.stringify(CADVIEW_WASM_URL)}
          });
          self.postMessage({ id, ok: true, dxf });
        } catch (error) {
          self.postMessage({ id, ok: false, message: error?.message || String(error) });
        }
      };
    `;
    const workerUrl = URL.createObjectURL(new Blob([source], { type: "text/javascript" }));
    const worker = new Worker(workerUrl, { name: "dwg-converter" });
    const pending = new Map();
    let nextRequestId = 0;
    let closed = false;

    function settle(entry, action, value) {
      clearTimeout(entry.timeoutId);
      clearInterval(entry.cancelId);
      action(value);
    }

    function shutdown(error) {
      if (closed) return;
      closed = true;
      worker.terminate();
      URL.revokeObjectURL(workerUrl);
      pending.forEach((entry) => settle(entry, entry.reject, error));
      pending.clear();
    }

    worker.onmessage = (event) => {
      const entry = pending.get(event.data?.id);
      if (!entry) return;
      pending.delete(event.data.id);
      if (event.data.ok) settle(entry, entry.resolve, event.data.dxf);
      else settle(entry, entry.reject, new Error(event.data.message || "DWG 도면을 해석하지 못했습니다."));
    };
    worker.onerror = (event) => {
      event.preventDefault?.();
      const location = event.filename ? ` (${event.filename}:${event.lineno || 0})` : "";
      shutdown(new Error(`${event.message || "DWG 변환 작업 스레드에서 오류가 발생했습니다."}${location}`));
    };

    return {
      convert(file) {
        ensureActive(cancelled);
        if (closed) return Promise.reject(new Error("DWG 변환 작업을 다시 시작해야 합니다."));
        return new Promise((resolve, reject) => {
          const megabytes = Math.max(1, Number(file?.size || 0) / (1024 * 1024));
          const mainTimeout = Math.min(600000, 90000 + Math.ceil(megabytes / 50) * 60000);
          const engineTimeout = Math.max(60000, mainTimeout - 30000);
          nextRequestId += 1;
          const id = nextRequestId;
          const timeoutId = setTimeout(() => {
            const minutes = Math.ceil(mainTimeout / 60000);
            shutdown(new Error(`DWG 변환 시간이 ${minutes}분을 초과했습니다. 도면 복잡도나 손상 여부를 확인하세요.`));
          }, mainTimeout);
          const cancelId = setInterval(() => {
            if (cancelled?.()) shutdown(new Error("변환이 취소되었습니다."));
          }, 100);
          pending.set(id, { resolve, reject, timeoutId, cancelId });
          try {
            worker.postMessage({ id, file, timeout: engineTimeout });
          } catch (error) {
            const entry = pending.get(id);
            pending.delete(id);
            settle(entry, reject, error);
          }
        });
      },
      dispose() {
        shutdown(new Error("DWG 변환 작업이 종료되었습니다."));
      },
      isClosed() {
        return closed;
      },
    };
  }

  function usableBounds(bounds) {
    if (!bounds) return null;
    const values = [bounds.minX, bounds.minY, bounds.maxX, bounds.maxY].map(Number);
    if (!values.every(Number.isFinite)) return null;
    const [minX, minY, maxX, maxY] = values;
    if (maxX <= minX || maxY <= minY) return null;
    return { minX, minY, maxX, maxY };
  }

  function drawingBounds(documentData, cadCore) {
    const headerBounds = usableBounds(documentData?.header?.extMin && documentData?.header?.extMax ? {
      minX: documentData.header.extMin.x,
      minY: documentData.header.extMin.y,
      maxX: documentData.header.extMax.x,
      maxY: documentData.header.extMax.y,
    } : null);
    return headerBounds || usableBounds(cadCore.computeEntitiesBounds(documentData.entities, documentData));
  }

  function dwgCanvasSize(bounds, maxSide) {
    const limit = Math.max(800, Math.min(4000, Math.round(Number(maxSide) || 1600)));
    if (!bounds) return { width: limit, height: Math.round(limit * 0.75) };
    const worldWidth = bounds.maxX - bounds.minX;
    const worldHeight = bounds.maxY - bounds.minY;
    const ratio = Math.max(0.125, Math.min(8, worldWidth / worldHeight));
    if (ratio >= 1) return { width: limit, height: Math.max(320, Math.round(limit / ratio)) };
    return { width: Math.max(320, Math.round(limit * ratio)), height: limit };
  }

  async function renderDwg(dxf, settings, preset, cadCore) {
    const sourceCanvas = document.createElement("canvas");
    const deviceScale = Math.max(1, Number(window.devicePixelRatio) || 1);
    Object.assign(sourceCanvas.style, {
      position: "fixed",
      left: "-10000px",
      top: "0",
      width: `${640 / deviceScale}px`,
      height: `${480 / deviceScale}px`,
      opacity: "0",
      pointerEvents: "none",
    });
    sourceCanvas.setAttribute("aria-hidden", "true");
    document.body.appendChild(sourceCanvas);
    let renderer;
    try {
      const documentData = cadCore.parseDxf(dxf);
      if (!documentData.entities.length) throw new Error("표시할 수 있는 2D 도면 요소가 없습니다.");
      const bounds = drawingBounds(documentData, cadCore);
      if (!bounds) throw new Error("도면의 출력 영역을 계산할 수 없습니다.");
      const size = dwgCanvasSize(bounds, preset.maxSide);
      sourceCanvas.style.width = `${size.width / deviceScale}px`;
      sourceCanvas.style.height = `${size.height / deviceScale}px`;
      renderer = new cadCore.CanvasRenderer(sourceCanvas);
      const transform = cadCore.fitToView(
        renderer.getWidth(),
        renderer.getHeight(),
        bounds.minX,
        bounds.minY,
        bounds.maxX,
        bounds.maxY
      );
      const visibleLayers = new Set(Array.from(documentData.layers, ([name, layer]) => {
        return layer.isOff || layer.isFrozen ? null : name;
      }).filter(Boolean));
      renderer.render(
        documentData,
        transform,
        settings.background === "dark" ? "dark" : "light",
        visibleLayers,
        -1
      );

      const outputCanvas = document.createElement("canvas");
      outputCanvas.width = size.width;
      outputCanvas.height = size.height;
      const context = outputCanvas.getContext("2d", { alpha: false });
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";
      context.drawImage(sourceCanvas, 0, 0, outputCanvas.width, outputCanvas.height);
      return outputCanvas;
    } finally {
      renderer?.destroy?.();
      sourceCanvas.remove();
    }
  }

  function dwgErrorMessage(error) {
    const message = String(error?.message || error || "알 수 없는 오류");
    if (/fetch|network|dynamically imported|module|wasm|load/i.test(message)) {
      return "DWG 변환 엔진을 불러오지 못했습니다. 인터넷 연결을 확인하세요.";
    }
    if (/memory|allocation|out of bounds|array\s*buffer|arraybuffer|heap|malloc|oom|rangeerror/i.test(message)) {
      return "도면을 처리할 브라우저 메모리가 부족합니다. 다른 창을 닫은 뒤 다시 시도해 주세요.";
    }
    if (/password/i.test(message)) return "암호로 보호된 DWG는 변환할 수 없습니다.";
    if (message.length <= 140) return message;
    return `${message.slice(0, 137)}...`;
  }

  internals.dwg = Object.freeze({
    CADVIEW_CORE_URL,
    CADVIEW_CORE_VERSION,
    CADVIEW_DWG_URL,
    CADVIEW_DWG_VERSION,
    CADVIEW_WASM_URL,
    createDwgItem,
    createDwgWorker,
    drawingBounds,
    dwgCanvasSize,
    dwgErrorMessage,
    dwgVersionOf,
    getCadCore,
    isDwg,
    renderDwg,
    usableBounds,
  });
})(window.HeechangTool);
