(function createCadWorkspace(Tool) {
  "use strict";

  const TOOLS = [
    ["select", "선택", "Esc"], ["line", "선", "L"], ["polyline", "폴리선", "PL"],
    ["rect", "사각형", "REC"], ["circle", "원", "C"], ["arc", "호", "A"],
    ["text", "문자", "T"], ["dimension", "치수", "D"], ["move", "이동", "M"],
    ["copy", "복사", "CO"], ["rotate", "회전", "RO"], ["scale", "축척", "SC"],
    ["mirror", "대칭", "MI"], ["offset", "간격복사", "O"], ["trim", "자르기", "TR"], ["erase", "삭제", "E"],
  ];
  const ALIASES = {
    L: "line", LINE: "line", PL: "polyline", PLINE: "polyline", POLYLINE: "polyline",
    REC: "rect", RECTANG: "rect", RECTANGLE: "rect", C: "circle", CIRCLE: "circle",
    A: "arc", ARC: "arc", T: "text", TEXT: "text", MT: "text", D: "dimension", DIM: "dimension", DLI: "dimension", DAL: "dimension",
    M: "move", MOVE: "move", CO: "copy", CP: "copy", COPY: "copy", RO: "rotate", ROTATE: "rotate",
    SC: "scale", SCALE: "scale", MI: "mirror", MIRROR: "mirror", O: "offset", OFFSET: "offset",
    TR: "trim", TRIM: "trim", E: "erase", ERASE: "erase", SELECT: "select",
  };
  const TRANSFORMS = new Set(["move", "copy", "rotate", "scale", "mirror"]);
  const round = (value) => Number(value.toFixed(2));
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);

  function markup() {
    return `
      <div class="cad-toolbar" aria-label="CAD 도구">
        ${TOOLS.map(([id, label, key]) => `<button type="button" data-cad-tool="${id}" title="${label} (${key})">${label}<kbd>${key}</kbd></button>`).join("")}
        <span class="cad-toolbar-break"></span>
        <button type="button" data-cad-action="undo" title="Ctrl+Z / U">↶</button>
        <button type="button" data-cad-action="redo" title="Ctrl+Y / Ctrl+Shift+Z">↷</button>
        <button type="button" data-cad-action="fit">화면 맞춤</button>
        <button type="button" data-cad-action="new">새 도면</button>
        <button type="button" data-cad-action="open">도면 열기</button>
        <button type="button" data-cad-action="export-json">도면 저장</button>
        <button type="button" data-cad-action="export-dxf" class="is-positive">DXF</button>
        <button type="button" data-cad-action="export-svg">SVG</button>
        <button type="button" data-cad-action="export-png">PNG</button>
        <button type="button" data-cad-action="help">단축키 ?</button>
      </div>
      <div class="cad-main">
        <div class="cad-stage"><canvas data-role="cad-canvas" tabindex="0" aria-label="간이 CAD 도면 캔버스"></canvas>
          <div class="cad-stage-hint" data-role="cad-empty"><strong>빈 도면에서 바로 시작하세요</strong>선택할 도구를 누르거나 L ↵, REC ↵, C ↵ 입력<br>휠 확대 · 가운데 버튼 드래그 이동 · Esc 취소</div>
        </div>
        <aside class="cad-properties" aria-label="도면 속성">
          <h3>그리기 속성</h3>
          <label>색상<input type="color" data-cad-setting="color" aria-label="선 색상"></label>
          <label>선 굵기<input type="number" data-cad-setting="lineWidth" min="0.1" max="12" step="0.1"></label>
          <label>문자 크기<input type="number" data-cad-setting="textSize" min="1" max="500" step="1"></label>
          <label>도면 단위<select data-cad-setting="unit"><option>mm</option><option>cm</option><option>m</option></select></label>
          <label>격자 간격<input type="number" data-cad-setting="gridSize" min="0.01" max="1000000" step="1"></label>
          <h3>레이어</h3><div data-role="cad-layers"></div>
          <form class="cad-layer-add" data-role="cad-layer-form"><input type="text" maxlength="40" placeholder="새 레이어" aria-label="새 레이어 이름"><button type="submit">＋</button></form>
          <h3>선택 객체 <span data-role="cad-selected-count">0</span></h3><div class="cad-selection-info" data-role="cad-selection-info">객체를 클릭해 선택하세요.<br>Shift+클릭으로 추가 선택<br>왼쪽→오른쪽: 완전히 포함<br>오른쪽→왼쪽: 걸친 객체</div>
        </aside>
      </div>
      <div class="cad-command-area"><div class="cad-command-history" data-role="cad-history" role="log" aria-live="polite"></div>
        <form class="cad-command-form" data-role="cad-command-form"><label for="cadCommandInput">명령</label><input id="cadCommandInput" data-role="cad-command" type="text" autocomplete="off" spellcheck="false" aria-label="CAD 명령 또는 좌표 입력"><button type="submit">실행 ↵</button></form>
      </div>
      <div class="cad-status"><span data-role="cad-coordinates">X 0 · Y 0</span><span>객체 <b data-role="cad-count">0</b></span><span data-role="cad-snap-status"></span><span class="cad-status-gap"></span>
        <button type="button" data-cad-toggle="grid">격자 F7</button><button type="button" data-cad-toggle="objectSnap">객체스냅 F3</button><button type="button" data-cad-toggle="ortho">직교 F8</button><button type="button" data-cad-toggle="gridSnap">격자스냅 F9</button><span data-role="cad-unit"></span>
      </div>
      <input type="file" accept=".json,application/json" data-role="cad-file" hidden>
      <dialog class="cad-help-dialog" data-role="cad-help"><button class="cad-help-close" type="button" data-cad-action="close-help">닫기</button><h3>간이 CAD 명령과 단축키</h3>
        <p>명령을 입력하고 Enter를 누른 뒤 점을 클릭하거나 좌표를 입력하세요. 좌표는 X 오른쪽, Y 위쪽이 양수입니다. <b>100,50</b> 절대 좌표 · <b>@100,50</b> 이전 점 기준 상대 좌표 · <b>@100&lt;45</b> 길이 100, 각도 45°. 선은 다음 점을 계속 지정하고 Enter로 끝냅니다. 폴리선은 C로 닫습니다.</p>
        <table><thead><tr><th>명령</th><th>사용 방법</th></tr></thead><tbody>
          <tr><td>L / PL / REC</td><td>선 / 폴리선 / 사각형의 점 지정</td></tr><tr><td>C / A</td><td>원: 중심→반지름 / 호: 중심→시작점→끝 방향</td></tr>
          <tr><td>T / D (DAL)</td><td>문자: 위치→명령창에 내용 / 치수: 첫 점→둘째 점→배치 위치</td></tr>
          <tr><td>M / CO / MI</td><td>객체 선택→Enter→기준점→목표점 / 대칭축 두 점 (원본 유지)</td></tr><tr><td>RO / SC</td><td>객체 선택→Enter→기준점→회전 각도 / 배율 입력</td></tr>
          <tr><td>O / TR / E</td><td>간격복사: 거리→객체→복사할 쪽 / 자르기: 교차 선의 제거할 부분 클릭 / 삭제</td></tr>
          <tr><td>U / REDO / Ctrl+Z / Ctrl+Y</td><td>되돌리기 / 다시 실행</td></tr><tr><td>Z→E / ZE / F</td><td>전체 도면 화면 맞춤</td></tr><tr><td>F3 / F7 / F8 / F9</td><td>객체 스냅 / 격자 표시 / 직교 / 격자 스냅</td></tr>
          <tr><td>Esc / Enter / Space</td><td>현재 작업 취소 / 완료 또는 마지막 명령 반복</td></tr><tr><td>Ctrl+A / Ctrl+C / Ctrl+V / Delete</td><td>전체 선택 / 복사 / 붙여넣기 / 선택 삭제</td></tr><tr><td>Ctrl+S</td><td>다시 열 수 있는 JSON 도면 파일 저장</td></tr>
        </tbody></table><p>간격복사는 선·원·사각형을 지원합니다. 자르기는 다른 선과 교차하는 직선을 지원합니다. DXF는 CAD에서 열 수 있으며, 이 편집기에서는 저장한 JSON 도면을 다시 엽니다. 도면 단위 선택은 표시·출력 단위를 정하며 기존 좌표를 변환하지 않습니다.</p>
      </dialog>`;
  }

  function mount({ context, root }) {
    root.innerHTML = markup();
    const q = (selector) => root.querySelector(selector);
    const canvas = q('[data-role="cad-canvas"]');
    const ctx = canvas.getContext("2d");
    const command = q('[data-role="cad-command"]');
    const historyBox = q('[data-role="cad-history"]');
    const removers = [];
    const messages = [];
    let disposed = false;
    let frame = 0;
    let tool = "select";
    let lastTool = "line";
    let points = [];
    let phase = "";
    let value = 0;
    let targetId = null;
    let mouse = { x: 0, y: 0 };
    let snapped = null;
    let pan = null;
    let gesture = null;
    let clipboard = [];
    let lastPoint = { x: 0, y: 0 };
    let commandIndex = -1;
    const commandHistory = [];
    const view = { scale: 1, tx: 0, ty: 0 };
    const model = Tool.core.cadEngine.create({ initialState: context.documentState.cad, onChange(snapshot) {
      if (disposed) return;
      context.updateDocument((state) => { state.cad = snapshot; });
      refresh(); invalidate();
    } });

    function listen(target, type, handler, options) {
      target.addEventListener(type, handler, options);
      removers.push(() => target.removeEventListener(type, handler, options));
    }
    function log(message) {
      messages.push(message);
      historyBox.textContent = messages.slice(-2).join("\n");
    }
    function invalidate() {
      if (!disposed && !frame) frame = window.requestAnimationFrame(() => { frame = 0; draw(); });
    }
    function world(screen) { return { x: (screen.x - view.tx) / view.scale, y: (screen.y - view.ty) / view.scale }; }
    function position(event) { const b = canvas.getBoundingClientRect(); return { x: event.clientX - b.left, y: event.clientY - b.top }; }
    function visible(entity) { return model.state.layers.find((layer) => layer.name === entity.layer)?.visible !== false; }
    function editable(entity) { const layer = model.state.layers.find((candidate) => candidate.name === entity.layer); return layer?.visible !== false && !layer?.locked; }
    function selected() { return model.state.entities.filter((entity) => model.state.selectedIds.includes(entity.id) && editable(entity)); }
    function select(ids) { model.select(ids); refresh(); invalidate(); }
    function setPhase(next) { phase = next; hint(); }
    function hint() {
      const name = TOOLS.find(([id]) => id === tool)?.[1] || tool;
      let text = "명령 입력 (L, PL, REC, C…) · 객체 클릭 / 드래그 선택";
      if (tool === "line" || tool === "polyline") text = points.length ? "다음 점 / 길이 입력 · Enter 완료" + (tool === "polyline" ? " · C 닫기" : "") : "첫 점 지정 (클릭 또는 x,y)";
      if (tool === "rect") text = points.length ? "반대쪽 모서리 지정" : "첫 모서리 지정";
      if (tool === "circle") text = points.length ? "반지름 입력 또는 원 위의 점 지정" : "중심점 지정";
      if (tool === "arc") text = ["중심점 지정", "호 시작점 지정", "호 끝 방향 지정"][Math.min(2, points.length)];
      if (tool === "dimension") text = ["치수 첫 점 지정", "치수 둘째 점 지정", "치수 배치 위치 지정"][Math.min(2, points.length)];
      if (tool === "text") text = points.length ? "문자 내용을 입력하고 Enter" : "문자를 넣을 위치 지정";
      if (TRANSFORMS.has(tool)) text = phase === "select" ? "객체 선택 후 Enter" : points.length ? ({ rotate: "회전 각도 입력 (반시계 방향 +)", scale: "배율 입력 (예: 2 또는 0.5)", mirror: "대칭축 둘째 점 지정" }[tool] || "목표점 지정 / @상대좌표 입력") : tool === "mirror" ? "대칭축 첫 점 지정" : "기준점 지정";
      if (tool === "offset") text = phase === "distance" ? "간격 거리 입력" : phase === "entity" ? "간격복사할 객체 선택" : "복사할 쪽의 점 지정";
      if (tool === "trim") text = "교차하는 선의 제거할 부분 클릭 · Enter 완료";
      if (tool === "erase") text = "삭제할 객체 선택 후 Enter";
      if (tool === "zoom") text = "E 입력 = 전체 도면 맞춤 / 배율 입력";
      command.placeholder = `${name}: ${text}`;
      q('[data-role="cad-empty"]').hidden = model.state.entities.length > 0 || tool !== "select";
    }
    function refresh() {
      q('[data-role="cad-count"]').textContent = model.state.entities.length;
      q('[data-role="cad-selected-count"]').textContent = model.state.selectedIds.length;
      q('[data-role="cad-unit"]').textContent = model.state.settings.unit;
      root.querySelectorAll("[data-cad-tool]").forEach((button) => { button.classList.toggle("is-active", button.dataset.cadTool === tool); button.setAttribute("aria-pressed", String(button.dataset.cadTool === tool)); });
      root.querySelectorAll("[data-cad-setting]").forEach((input) => { if (document.activeElement !== input) input.value = model.state.settings[input.dataset.cadSetting]; });
      root.querySelectorAll("[data-cad-toggle]").forEach((button) => { const active = !!model.state.settings[button.dataset.cadToggle]; button.classList.toggle("is-active", active); button.setAttribute("aria-pressed", String(active)); });
      const entities = selected();
      const info = q('[data-role="cad-selection-info"]');
      if (entities.length) {
        const entity = entities[0];
        const label = TOOLS.find(([id]) => id === entity.type)?.[1] || entity.type;
        info.textContent = `${entities.length}개 선택 · ${label}\n레이어: ${entity.layer}`;
        if (entity.type === "line" || entity.type === "dimension") info.textContent += `\n길이: ${round(distance(entity.a, entity.b))} ${model.state.settings.unit}`;
        if (entity.radius) info.textContent += `\n반지름: ${round(entity.radius)} ${model.state.settings.unit}`;
        if (entity.type === "text") info.textContent += `\n문자: ${entity.text}`;
      } else info.textContent = "객체 클릭 · Shift로 추가 선택\n왼쪽→오른쪽: 완전히 포함\n오른쪽→왼쪽: 걸친 객체\n선택 후 이동·복사 명령 사용";
      q('[data-role="cad-layers"]').innerHTML = model.state.layers.map((layer) => `<div class="cad-layer-row"><button type="button" data-layer-visible="${escapeHtml(layer.name)}" title="표시 / 숨김" aria-label="${escapeHtml(layer.name)} 레이어 표시" aria-pressed="${layer.visible}">${layer.visible ? "◉" : "○"}</button><button type="button" data-layer-lock="${escapeHtml(layer.name)}" title="잠금 / 해제" aria-label="${escapeHtml(layer.name)} 레이어 잠금" aria-pressed="${layer.locked}">${layer.locked ? "🔒" : "◇"}</button><button type="button" data-layer-pick="${escapeHtml(layer.name)}" class="${model.state.settings.layer === layer.name ? "is-active" : ""}">${escapeHtml(layer.name)}</button></div>`).join("");
      hint();
    }
    function reset(keepSelection = true) {
      tool = "select"; points = []; phase = ""; targetId = null; gesture = null; snapped = null; command.value = "";
      if (!keepSelection) model.select([]);
      refresh(); invalidate();
    }
    function begin(next) {
      points = []; phase = ""; targetId = null; gesture = null; tool = next; command.value = "";
      if (next !== "select") lastTool = next;
      if (TRANSFORMS.has(next)) phase = selected().length ? "points" : "select";
      if (next === "offset") phase = "distance";
      if (next === "erase" && selected().length) { model.remove(model.state.selectedIds); reset(); return; }
      log(`${TOOLS.find(([id]) => id === next)?.[1] || next}: ${next === "select" ? "객체를 선택하세요." : "점을 지정하거나 명령창에 값을 입력하세요."}`);
      refresh(); invalidate();
      if (next === "offset") command.focus({ preventScroll: true }); else canvas.focus({ preventScroll: true });
    }
    function add(entity) {
      const settings = model.state.settings;
      const layer = model.state.layers.find((candidate) => candidate.name === settings.layer);
      if (layer?.locked || layer?.visible === false) { log("현재 레이어가 잠겨 있거나 숨겨져 있습니다. 다른 레이어를 선택하세요."); return null; }
      return model.add({ ...entity, layer: settings.layer, color: settings.color, lineWidth: settings.lineWidth });
    }
    function constrain(point) {
      const settings = model.state.settings;
      const base = points.at(-1);
      let result = { ...point };
      snapped = null;
      if (settings.objectSnap && !gesture) {
        const candidate = model.snap(result, 10 / view.scale);
        if (candidate && candidate.type !== "free") { snapped = candidate; result = { ...candidate.point }; }
      }
      if (!snapped && settings.gridSnap) result = { x: Math.round(result.x / settings.gridSize) * settings.gridSize, y: Math.round(result.y / settings.gridSize) * settings.gridSize };
      if (base && settings.ortho && ["line", "polyline", "move", "copy"].includes(tool)) result = Math.abs(result.x - base.x) >= Math.abs(result.y - base.y) ? { x: result.x, y: base.y } : { x: base.x, y: result.y };
      return result;
    }
    function acceptPoint(point) {
      lastPoint = { ...point };
      if (TRANSFORMS.has(tool)) {
        if (phase === "select") { log("먼저 객체를 선택한 뒤 Enter를 누르세요."); return; }
        if (!points.length) { points.push(point); hint(); invalidate(); if (tool === "scale" || tool === "rotate") command.focus({ preventScroll: true }); return; }
        if (tool === "scale") { log("명령창에 배율을 입력하세요. 예: 2 또는 0.5"); command.focus({ preventScroll: true }); return; }
        const base = points[0];
        const options = tool === "mirror" ? { type: "mirror", axisA: base, axisB: point, copy: true }
          : tool === "rotate" ? { type: "rotate", base, angle: -Math.atan2(point.y - base.y, point.x - base.x) * 180 / Math.PI }
          : { type: tool, delta: { x: point.x - base.x, y: point.y - base.y } };
        if ((tool === "mirror" && distance(base, point) < 1e-8) || (tool === "scale" && !options.factor)) { log("서로 다른 두 점을 지정하세요."); return; }
        model.transform(model.state.selectedIds, options); reset(); return;
      }
      if (tool === "offset") {
        if (phase === "side" && targetId) { const result = model.offset(targetId, value, point); if (!result) log("이 객체는 간격복사를 지원하지 않습니다."); targetId = null; setPhase("entity"); invalidate(); }
        else log("간격 거리를 입력한 뒤 객체를 클릭하세요.");
        return;
      }
      if (tool === "text") { if (!points.length) { points.push(point); hint(); command.focus({ preventScroll: true }); } return; }
      if (tool === "line") {
        if (points.length && distance(points[0], point) > 1e-8) add({ type: "line", a: points[0], b: point });
        points = [point];
      } else if (tool === "polyline") {
        if (!points.length || distance(points.at(-1), point) > 1e-8) points.push(point);
      } else if (tool === "rect" && points.length) {
        if (Math.abs(point.x - points[0].x) < 1e-8 || Math.abs(point.y - points[0].y) < 1e-8) { log("너비와 높이가 있는 사각형을 지정하세요."); return; }
        add({ type: "rect", a: points[0], b: point }); reset();
      } else if (tool === "circle" && points.length) {
        const radius = distance(points[0], point); if (radius <= 0) return;
        add({ type: "circle", center: points[0], radius }); reset();
      } else if (tool === "arc" && points.length === 2) {
        const radius = distance(points[0], points[1]); if (!radius || distance(points[0], point) < 1e-8) return;
        add({ type: "arc", center: points[0], radius, startAngle: Math.atan2(points[1].y - points[0].y, points[1].x - points[0].x), endAngle: Math.atan2(point.y - points[0].y, point.x - points[0].x), clockwise: false }); reset();
      } else if (tool === "dimension" && points.length === 2) {
        const [a, b] = points; const length = distance(a, b);
        if (length > 1e-8) add({ type: "dimension", a, b, offset: ((point.x - a.x) * (a.y - b.y) + (point.y - a.y) * (b.x - a.x)) / length, textSize: model.state.settings.textSize });
        reset();
      } else if (["rect", "circle", "arc", "dimension"].includes(tool)) points.push(point);
      hint(); invalidate();
    }

    function finishDrawing(close = false) {
      if (tool === "polyline" && points.length >= (close ? 3 : 2)) add({ type: "polyline", points: points.map((point) => ({ ...point })), closed: close });
      reset();
    }
    function submit(raw) {
      const input = String(raw).trim(); const upper = input.toUpperCase();
      command.value = "";
      if (input) { commandHistory.push(input); commandIndex = commandHistory.length; log(`> ${input}`); }
      if (tool === "text" && points.length && input) {
        add({ type: "text", point: points[0], text: input, textSize: model.state.settings.textSize, rotation: 0 }); reset(); return;
      }
      if (!input) {
        if (TRANSFORMS.has(tool) && phase === "select") { if (!selected().length) log("객체를 먼저 선택하세요."); else setPhase("points"); return; }
        if (tool === "erase") { model.remove(model.state.selectedIds); reset(); return; }
        if (tool === "select") { begin(lastTool); return; }
        finishDrawing(); return;
      }
      if (upper === "U" || upper === "UNDO") { reset(); model.undo(); return; }
      if (upper === "REDO") { reset(); model.redo(); return; }
      if (["ZE", "EXTENTS", "F"].includes(upper)) { reset(); fit(); return; }
      if (upper === "Z" || upper === "ZOOM") { begin("zoom"); return; }
      if (tool === "zoom") {
        if (upper === "E" || upper === "A") { reset(); fit(); return; }
        const factor = Number(input); if (Number.isFinite(factor) && factor > 0) { zoomAtCenter(factor); reset(); return; }
        log("E 또는 양수 배율을 입력하세요."); return;
      }
      if (tool === "polyline" && points.length && (upper === "C" || upper === "CLOSE")) {
        if (points.length < 3) { log("닫힌 폴리선에는 세 점 이상이 필요합니다."); return; }
        finishDrawing(true); return;
      }
      if (tool === "offset" && phase === "distance") {
        const number = Number(input);
        if (!Number.isFinite(number) || number <= 0) { log("0보다 큰 간격 거리를 입력하세요."); return; }
        value = number; setPhase("entity"); return;
      }
      if (points.length && (tool === "rotate" || tool === "scale")) {
        const number = Number(input);
        if (!Number.isFinite(number) || (tool === "scale" && number <= 0)) { log(tool === "scale" ? "0보다 큰 배율을 입력하세요." : "회전 각도를 숫자로 입력하세요."); return; }
        model.transform(model.state.selectedIds, { type: tool, base: points[0], ...(tool === "rotate" ? { angle: number } : { factor: number }) }); reset(); return;
      }
      const point = Tool.core.cadEngine.parsePoint(input, points.at(-1) || lastPoint);
      if (point && tool !== "select") { acceptPoint(point); return; }
      if (points.length && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(input) && ["line", "polyline", "circle"].includes(tool)) {
        const length = Number(input); const base = points.at(-1);
        if (!Number.isFinite(length) || length <= 0) { log("0보다 큰 길이를 입력하세요."); return; }
        if (tool === "circle") { add({ type: "circle", center: base, radius: length }); reset(); return; }
        let direction = { x: mouse.x - base.x, y: mouse.y - base.y };
        if (model.state.settings.ortho) direction = Math.abs(direction.x) >= Math.abs(direction.y) ? { x: Math.sign(direction.x) || 1, y: 0 } : { x: 0, y: Math.sign(direction.y) || 1 };
        const norm = Math.hypot(direction.x, direction.y) || 1;
        if (!direction.x && !direction.y) direction.x = 1;
        acceptPoint({ x: base.x + direction.x / norm * length, y: base.y + direction.y / norm * length }); return;
      }
      if (ALIASES[upper]) { begin(ALIASES[upper]); return; }
      log("알 수 없는 명령 또는 값입니다. 단축키 ? 버튼에서 사용법을 확인하세요.");
    }
    function fit() {
      const size = canvas.getBoundingClientRect(); const bounds = model.bounds();
      if (!bounds) { view.scale = 1; view.tx = size.width / 2; view.ty = size.height / 2; }
      else {
        const width = Math.max(80, bounds.maxX - bounds.minX); const height = Math.max(80, bounds.maxY - bounds.minY);
        view.scale = Math.max(0.001, Math.min(100, Math.min((size.width - 80) / width, (size.height - 80) / height)));
        view.tx = size.width / 2 - (bounds.minX + bounds.maxX) / 2 * view.scale;
        view.ty = size.height / 2 - (bounds.minY + bounds.maxY) / 2 * view.scale;
      }
      invalidate();
    }
    function zoomAt(screen, factor) {
      const anchor = world(screen); view.scale = Math.max(0.001, Math.min(100, view.scale * factor));
      view.tx = screen.x - anchor.x * view.scale; view.ty = screen.y - anchor.y * view.scale; invalidate();
    }
    function zoomAtCenter(factor) { const b = canvas.getBoundingClientRect(); zoomAt({ x: b.width / 2, y: b.height / 2 }, factor); }
    function toggle(name) { model.setSettings({ [name]: !model.state.settings[name] }); invalidate(); }
    function pointerDown(event) {
      if (event.button === 2) { event.preventDefault(); finishDrawing(); return; }
      if (event.button !== 0 && event.button !== 1) return;
      canvas.focus({ preventScroll: true }); event.preventDefault();
      try { canvas.setPointerCapture(event.pointerId); } catch (_) { /* Pointer may have ended. */ }
      const screen = position(event); const point = world(screen);
      if (event.button === 1) { pan = { screen, tx: view.tx, ty: view.ty }; return; }
      const hit = model.hitTest(point, 8 / view.scale);
      if (tool === "offset" && phase === "entity") {
        if (!hit) { log("선을 클릭해 선택하세요."); return; }
        targetId = hit.id; select([hit.id]); setPhase("side"); return;
      }
      if (tool === "trim") { if (!hit || !model.trim(hit.id, point)) log("다른 선과 교차하는 직선의 제거할 부분을 클릭하세요."); return; }
      if (tool === "select" || tool === "erase" || (TRANSFORMS.has(tool) && phase === "select")) {
        if (hit) {
          const ids = model.state.selectedIds.slice();
          if (event.shiftKey) select(ids.includes(hit.id) ? ids.filter((id) => id !== hit.id) : [...ids, hit.id]);
          else if (!ids.includes(hit.id)) select([hit.id]);
          if (tool === "select" && !event.shiftKey) gesture = { type: "move", screen, point, entities: selected().map((entity) => JSON.parse(JSON.stringify(entity))), delta: { x: 0, y: 0 }, moved: false };
        } else {
          if (!event.shiftKey) select([]);
          gesture = { type: "box", screen, point, end: point, moved: false, additive: event.shiftKey, ids: model.state.selectedIds.slice() };
        }
        return;
      }
      acceptPoint(constrain(point));
    }
    function pointerMove(event) {
      const screen = position(event); const raw = world(screen);
      if (pan) { view.tx = pan.tx + screen.x - pan.screen.x; view.ty = pan.ty + screen.y - pan.screen.y; invalidate(); return; }
      mouse = constrain(raw);
      q('[data-role="cad-coordinates"]').textContent = `X ${round(mouse.x)} · Y ${round(-mouse.y)}`;
      q('[data-role="cad-snap-status"]').textContent = snapped ? ({ endpoint: "끝점", midpoint: "중간점", center: "중심", quadrant: "사분점", intersection: "교차점" }[snapped.type] || "스냅") : "";
      if (gesture) {
        gesture.moved = gesture.moved || distance(screen, gesture.screen) > 4;
        if (gesture.type === "box") gesture.end = raw;
        else gesture.delta = { x: raw.x - gesture.point.x, y: raw.y - gesture.point.y };
      }
      invalidate();
    }
    function pointerUp(event) {
      if (event?.pointerId !== undefined) { try { canvas.releasePointerCapture(event.pointerId); } catch (_) { /* No active capture. */ } }
      if (gesture?.moved) {
        if (gesture.type === "box") select([...new Set([...gesture.ids, ...model.boxSelect(gesture.point, gesture.end, gesture.end.x < gesture.point.x)])]);
        else model.transform(gesture.entities.map((entity) => entity.id), { type: "move", delta: gesture.delta });
      }
      gesture = null; pan = null; invalidate();
    }
    function keyDown(event) {
      const key = event.key.toLowerCase(); const ctrl = event.ctrlKey || event.metaKey;
      const textInput = /INPUT|TEXTAREA|SELECT/.test(event.target.tagName) || event.target.isContentEditable;
      if (q('[data-role="cad-help"]').open) return;
      const switches = { f3: "objectSnap", f7: "grid", f8: "ortho", f9: "gridSnap" };
      if (switches[key]) { event.preventDefault(); toggle(switches[key]); return; }
      if (key === "escape") { event.preventDefault(); reset(false); canvas.focus({ preventScroll: true }); return; }
      if (ctrl && key === "s") { event.preventDefault(); exportFile("json"); return; }
      if ((key === "enter" || key === " ") && event.target.closest?.("button")) return;
      if ((!textInput || (event.target === command && !command.value)) && ctrl && (key === "z" || key === "y")) {
        event.preventDefault(); reset(); if (key === "y" || event.shiftKey) model.redo(); else model.undo(); return;
      }
      if (textInput) {
        if (event.target === command && (key === "arrowup" || key === "arrowdown")) {
          event.preventDefault(); commandIndex = Math.max(0, Math.min(commandHistory.length, commandIndex + (key === "arrowup" ? -1 : 1))); command.value = commandHistory[commandIndex] || "";
        }
        return;
      }
      if (ctrl && key === "a") { event.preventDefault(); select(model.state.entities.filter(editable).map((entity) => entity.id)); return; }
      if (ctrl && key === "c") { event.preventDefault(); clipboard = selected().map((entity) => JSON.parse(JSON.stringify(entity))); log(`${clipboard.length}개 객체 복사`); return; }
      if (ctrl && key === "v") {
        event.preventDefault(); if (!clipboard.length) return;
        const shift = model.state.settings.gridSize;
        const pasted = clipboard.map((entity) => Tool.core.cadEngine.transformEntity(entity, { type: "move", delta: { x: shift, y: shift } }));
        if (pasted.some((entity) => !entity)) { log("붙여넣을 객체가 지원하는 좌표 범위를 벗어납니다."); return; }
        pasted.forEach((entity) => delete entity.id); const added = model.add(pasted); select(added.map((entity) => entity.id)); return;
      }
      if (key === "delete" || key === "backspace") { event.preventDefault(); model.remove(model.state.selectedIds); return; }
      if (key === "enter" || key === " ") { event.preventDefault(); submit(""); return; }
      if (!ctrl && !event.altKey && event.key.length === 1) { event.preventDefault(); command.focus({ preventScroll: true }); command.value = event.key; }
    }

    function entityPreview() {
      const point = mouse;
      if (points.length && tool === "line") return { type: "line", a: points[0], b: point };
      if (points.length && tool === "polyline") return { type: "polyline", points: [...points, point] };
      if (points.length && tool === "rect") return { type: "rect", a: points[0], b: point };
      if (points.length && tool === "circle") return { type: "circle", center: points[0], radius: distance(points[0], point) };
      if (points.length === 2 && tool === "arc") return { type: "arc", center: points[0], radius: distance(points[0], points[1]), startAngle: Math.atan2(points[1].y - points[0].y, points[1].x - points[0].x), endAngle: Math.atan2(point.y - points[0].y, point.x - points[0].x), clockwise: false };
      if (points.length === 2 && tool === "dimension") { const [a,b] = points; const len = distance(a,b) || 1; return { type: "dimension", a,b,offset: ((point.x-a.x)*(a.y-b.y)+(point.y-a.y)*(b.x-a.x))/len,textSize:model.state.settings.textSize }; }
      return null;
    }
    function drawGrid(width, height) {
      const settings = model.state.settings;
      let step = settings.gridSize;
      while (step * view.scale < 15) step *= 5;
      const spacing = step * view.scale;
      if (settings.grid) {
        ctx.lineWidth = 1; ctx.strokeStyle = "#223044"; ctx.beginPath();
        for (let x = ((view.tx % spacing) + spacing) % spacing; x < width; x += spacing) { ctx.moveTo(Math.round(x)+.5,0); ctx.lineTo(Math.round(x)+.5,height); }
        for (let y = ((view.ty % spacing) + spacing) % spacing; y < height; y += spacing) { ctx.moveTo(0,Math.round(y)+.5); ctx.lineTo(width,Math.round(y)+.5); }
        ctx.stroke();
      }
      ctx.lineWidth = 1; ctx.strokeStyle = "#4c3943"; ctx.beginPath(); ctx.moveTo(0,view.ty); ctx.lineTo(width,view.ty); ctx.stroke();
      ctx.strokeStyle = "#2c504c"; ctx.beginPath(); ctx.moveTo(view.tx,0); ctx.lineTo(view.tx,height); ctx.stroke();
      ctx.fillStyle = "#6da09b"; ctx.font = "10px Consolas"; ctx.fillText("Y",view.tx+5,14); ctx.fillStyle = "#b98490"; ctx.fillText("X",width-15,view.ty-6);
    }
    function draw() {
      const b = canvas.getBoundingClientRect(); const ratio = window.devicePixelRatio || 1;
      const w = Math.max(1,Math.round(b.width*ratio)); const h = Math.max(1,Math.round(b.height*ratio));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      canvas.dataset.viewScale = String(view.scale); canvas.dataset.viewTx = String(view.tx); canvas.dataset.viewTy = String(view.ty);
      ctx.setTransform(ratio,0,0,ratio,0,0); ctx.fillStyle = "#131a24"; ctx.fillRect(0,0,b.width,b.height); drawGrid(b.width,b.height);
      ctx.save(); ctx.translate(view.tx,view.ty); ctx.scale(view.scale,view.scale);
      model.state.entities.filter(visible).forEach((entity) => Tool.core.cadExporters.drawEntity(ctx,entity,{ selected:model.state.selectedIds.includes(entity.id),scale:view.scale,unit:model.state.settings.unit }));
      if (gesture?.type === "move" && gesture.moved) {
        ctx.setLineDash([6/view.scale,4/view.scale]);
        gesture.entities.forEach((entity) => Tool.core.cadExporters.drawEntity(ctx,Tool.core.cadEngine.transformEntity(entity,{type:"move",delta:gesture.delta}),{color:"#fbbf24",scale:view.scale,unit:model.state.settings.unit})); ctx.setLineDash([]);
      }
      const preview = entityPreview();
      if (preview) { ctx.setLineDash([6/view.scale,4/view.scale]); Tool.core.cadExporters.drawEntity(ctx,preview,{color:"#fbbf24",scale:view.scale,unit:model.state.settings.unit}); ctx.setLineDash([]); }
      if (TRANSFORMS.has(tool) && points.length) {
        ctx.setLineDash([5/view.scale,5/view.scale]); ctx.lineWidth = 1/view.scale; ctx.strokeStyle="#fbbf24"; ctx.beginPath(); ctx.moveTo(points[0].x,points[0].y); ctx.lineTo(mouse.x,mouse.y); ctx.stroke(); ctx.setLineDash([]);
      }
      if (gesture?.type === "box" && gesture.moved) {
        const cross = gesture.end.x < gesture.point.x; ctx.fillStyle = cross ? "#2cb66e22" : "#388bfa22"; ctx.strokeStyle = cross ? "#52c58a" : "#61a5ff"; ctx.lineWidth=1/view.scale; if(cross)ctx.setLineDash([4/view.scale,4/view.scale]);
        ctx.fillRect(gesture.point.x,gesture.point.y,gesture.end.x-gesture.point.x,gesture.end.y-gesture.point.y);ctx.strokeRect(gesture.point.x,gesture.point.y,gesture.end.x-gesture.point.x,gesture.end.y-gesture.point.y);ctx.setLineDash([]);
      }
      if (snapped) { const p=snapped.point,s=5/view.scale;ctx.strokeStyle="#4ade80";ctx.lineWidth=1.5/view.scale;ctx.strokeRect(p.x-s,p.y-s,2*s,2*s); }
      ctx.restore();
    }
    async function exportFile(format) {
      try { await Tool.core.cadExporters.download(model.snapshot(),format); log(`${format.toUpperCase()} 도면을 저장했습니다.`); }
      catch(error) { context.ui.showToast(error.message || "도면을 저장하지 못했습니다."); }
    }
    async function openFile(file) {
      if (!file) return;
      if (file.size > 20 * 1024 * 1024) { context.ui.showToast("20MB 이하 JSON 도면을 선택하세요."); return; }
      try {
        const data = JSON.parse(await file.text());
        if (disposed) return;
        if (!data || !Array.isArray(data.entities) || (data.format && data.format !== "heechang-cad")) throw new Error("이 도구에서 저장한 JSON 도면을 선택하세요.");
        if (model.state.entities.length && !window.confirm("현재 도면 대신 선택한 도면을 열까요? 현재 도면은 되돌리기로 복원할 수 있습니다.")) return;
        reset(false); model.load(data); fit(); log("JSON 도면을 열었습니다.");
      } catch(error) { context.ui.showToast(error.message || "도면 파일을 읽지 못했습니다."); }
      finally { const input = q('[data-role="cad-file"]'); if (input) input.value = ""; }
    }

    listen(q('[data-role="cad-command-form"]'),"submit",(event) => { event.preventDefault(); submit(command.value); });
    listen(canvas,"pointerdown",pointerDown); listen(canvas,"pointermove",pointerMove); listen(canvas,"pointerup",pointerUp);
    listen(canvas,"pointercancel",() => { gesture=null;pan=null;invalidate(); });
    listen(canvas,"contextmenu",(event) => event.preventDefault());
    listen(canvas,"wheel",(event) => { event.preventDefault(); zoomAt(position(event),event.deltaY<0?1.15:1/1.15); },{passive:false});
    listen(canvas,"dblclick",(event) => {
      if (tool === "polyline") { finishDrawing(); return; }
      if (tool !== "select") return;
      const hit=model.hitTest(world(position(event)),8/view.scale);
      if (hit && (hit.type === "text" || hit.type === "dimension")) { const text=window.prompt(hit.type === "text"?"문자 내용":"치수 표시값 (비워두면 자동 측정)",hit.text||"");if(text!==null)model.update(hit.id,{text}); }
    });
    listen(window,"keydown",keyDown);
    listen(root,"click",(event) => {
      const button=event.target.closest("button");if(!button)return;
      if(button.dataset.cadTool) { begin(button.dataset.cadTool);return; }
      if(button.dataset.cadToggle) { toggle(button.dataset.cadToggle);return; }
      if(button.dataset.layerPick !== undefined) { model.setSettings({layer:button.dataset.layerPick});return; }
      if(button.dataset.layerVisible !== undefined || button.dataset.layerLock !== undefined) {
        const name=button.dataset.layerVisible ?? button.dataset.layerLock;const layer=model.state.layers.find((item)=>item.name===name);
        model.setLayer(name,button.dataset.layerVisible!==undefined?{visible:!layer.visible}:{locked:!layer.locked});return;
      }
      const action=button.dataset.cadAction;
      if(action==="undo"||action==="redo") {reset();model[action]();}
      else if(action==="fit")fit();
      else if(action==="new") {if(!model.state.entities.length||window.confirm("새 도면을 시작할까요? 현재 도면은 되돌리기로 복원할 수 있습니다.")){reset(false);model.clear();fit();}}
      else if(action==="open")q('[data-role="cad-file"]').click();
      else if(action?.startsWith("export-"))exportFile(action.slice(7));
      else if(action==="help")q('[data-role="cad-help"]').showModal();
      else if(action==="close-help")q('[data-role="cad-help"]').close();
    });
    root.querySelectorAll("[data-cad-setting]").forEach((input) => listen(input,"change",() => {
      const name=input.dataset.cadSetting; const patch={ [name]:["lineWidth","textSize","gridSize"].includes(name)?Number(input.value):input.value };
      if (["color","lineWidth","textSize"].includes(name)) model.applyProperties(patch);
      else model.setSettings(patch);
    }));
    listen(q('[data-role="cad-layer-form"]'),"submit",(event) => {
      event.preventDefault();const input=event.target.querySelector("input");const name=input.value.trim();if(!name)return;
      model.setLayer(name,{color:model.state.settings.color,visible:true,locked:false});model.setSettings({layer:name});input.value="";
    });
    listen(q('[data-role="cad-file"]'),"change",(event) => openFile(event.target.files?.[0]));
    const observer=new ResizeObserver(invalidate);observer.observe(canvas);
    fit();refresh();log("준비 · L 선 / REC 사각형 / C 원 · 명령 뒤 Enter");
    return () => { disposed=true;observer.disconnect();removers.reverse().forEach((remove)=>remove());if(frame)window.cancelAnimationFrame(frame);root.replaceChildren(); };
  }

  Tool.core.cadWorkspace = Object.freeze({ mount });
})(window.HeechangTool);
