(function createDrawingEngineModule(Tool) {
  "use strict";

  const COLORS = Object.freeze({ red: "#e01b24", blue: "#1a56d6", black: "#111111" });
  const UNITS = Object.freeze(["", "mm", "cm", "m"]);

  function cloneDimensions(dimensions) {
    return JSON.parse(JSON.stringify(Array.isArray(dimensions) ? dimensions : []));
  }

  function createRegistry(kind, emit) {
    const entries = new Map();
    return Object.freeze({
      kind,
      register(name, definition) {
        if (entries.has(name)) throw new Error(`${kind} 중복 등록: ${name}`);
        const value = Object.freeze({ name, ...definition });
        entries.set(name, value);
        emit("registry:add", { kind, name });
        return value;
      },
      get(name) { return entries.get(name) || null; },
      has(name) { return entries.has(name); },
      names() { return Array.from(entries.keys()); },
      list() { return Array.from(entries.values()); },
    });
  }

  function create(options = {}) {
    const initial = options.initialState || {};
    const handlers = new Map();
    const state = {
      image: null,
      width: 0,
      height: 0,
      name: "",
      gray: null,
      mask: null,
      response: null,
      responseMax: 0,
      corners: [],
      grid: null,
      gridWidth: 0,
      gridHeight: 0,
      gridCell: 24,
      dimensions: cloneDimensions(initial.dimensions),
      selected: null,
      view: { scale: 1, tx: 0, ty: 0 },
      mouse: { x: 0, y: 0 },
      snap: null,
      unitsPerPixel: 1,
    };
    const style = {
      color: initial.settings?.color || COLORS.red,
      textSize: Number(initial.settings?.textSize) || 16,
      offset: Number(initial.settings?.offset) || 34,
      decimals: 1,
      unit: UNITS.includes(initial.settings?.unit) ? initial.settings.unit : "mm",
    };
    let dirty = true;
    let history = [cloneDimensions(state.dimensions)];

    const vector = Object.freeze({
      sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y }),
      add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y }),
      mul: (a, scalar) => ({ x: a.x * scalar, y: a.y * scalar }),
      dot: (a, b) => a.x * b.x + a.y * b.y,
      len: (value) => Math.hypot(value.x, value.y),
      per: (value) => ({ x: -value.y, y: value.x }),
      dst: (a, b) => Math.hypot(a.x - b.x, a.y - b.y),
      mid: (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }),
      nrm(value) {
        const length = Math.hypot(value.x, value.y) || 1;
        return { x: value.x / length, y: value.y / length };
      },
      distSeg(point, a, b) {
        const ab = vector.sub(b, a);
        const denominator = vector.dot(ab, ab) || 1e-9;
        const ratio = Math.max(0, Math.min(1, vector.dot(vector.sub(point, a), ab) / denominator));
        return vector.dst(point, { x: a.x + ab.x * ratio, y: a.y + ab.y * ratio });
      },
    });

    function on(eventName, handler) {
      const eventHandlers = handlers.get(eventName) || [];
      eventHandlers.push(handler);
      handlers.set(eventName, eventHandlers);
      return () => {
        const current = handlers.get(eventName) || [];
        handlers.set(eventName, current.filter((candidate) => candidate !== handler));
      };
    }

    function emit(eventName, payload) {
      (handlers.get(eventName) || []).forEach((handler) => {
        try {
          handler(payload);
        } catch (error) {
          console.error(`[drawing:${eventName}]`, error);
        }
      });
    }

    function invalidate() {
      dirty = true;
    }

    function consumeDirty() {
      const value = dirty;
      dirty = false;
      return value;
    }

    const types = createRegistry("치수종류", emit);
    const exporters = createRegistry("내보내기", emit);
    const measureContext = document.createElement("canvas").getContext("2d");

    function textWidth(text, textSize) {
      measureContext.font = `${textSize}px Arial`;
      return measureContext.measureText(String(text)).width;
    }

    function styleOf(dimension) {
      const textSize = Number(dimension?.th) || style.textSize;
      return {
        textSize,
        color: dimension?.col || style.color,
        arrow: Math.max(4, Math.round(textSize * 0.72)),
        gap: Math.max(2, Math.round(textSize * 0.32)),
        over: Math.max(3, Math.round(textSize * 0.52)),
        lineWidth: Math.max(0.7, Number((textSize / 12).toFixed(2))),
      };
    }

    function format(value) {
      let result = Number(value).toFixed(style.decimals);
      if (result.includes(".")) result = result.replace(/0+$/, "").replace(/\.$/, "");
      return result;
    }

    function commit(reason) {
      history.push(cloneDimensions(state.dimensions));
      if (history.length > 80) history.shift();
      const snapshot = cloneDimensions(state.dimensions);
      options.onDimensionsChange?.(snapshot, reason || "change");
      emit("dimensions:change", snapshot);
      invalidate();
    }

    const model = {
      typeOf(dimension) {
        return types.get(dimension?.type || "linear") || types.get("linear");
      },
      unitOf(dimension) {
        return dimension?.unit !== undefined ? dimension.unit : style.unit;
      },
      measure(dimension) {
        const type = model.typeOf(dimension);
        return type?.measure ? type.measure(dimension) : 0;
      },
      rawLabel(dimension) {
        return dimension?.txt !== undefined && dimension.txt !== ""
          ? String(dimension.txt)
          : format(model.measure(dimension) * state.unitsPerPixel);
      },
      label(dimension) {
        let label = model.rawLabel(dimension);
        const unit = model.unitOf(dimension);
        if (unit && /^[+-]?\d+(\.\d+)?$/.test(label)) label += unit;
        return label;
      },
      createLinear(a, b) {
        return types.get("linear").create(a, b);
      },
      add(dimension) {
        state.dimensions.push(dimension);
        state.selected = dimension;
        commit("add");
        emit("dimension:add", dimension);
        return dimension;
      },
      remove(dimension) {
        const index = state.dimensions.indexOf(dimension);
        if (index < 0) return false;
        state.dimensions.splice(index, 1);
        if (state.selected === dimension) state.selected = null;
        commit("remove");
        emit("dimension:remove", dimension);
        return true;
      },
      clear() {
        if (!state.dimensions.length) return false;
        state.dimensions = [];
        state.selected = null;
        commit("clear");
        return true;
      },
      resetForImage() {
        state.dimensions = [];
        state.selected = null;
        state.snap = null;
        history = [cloneDimensions(state.dimensions)];
        options.onDimensionsChange?.([], "image");
        emit("dimensions:change", []);
        invalidate();
      },
      undo() {
        if (history.length <= 1) return false;
        history.pop();
        state.dimensions = cloneDimensions(history[history.length - 1]);
        state.selected = null;
        const snapshot = cloneDimensions(state.dimensions);
        options.onDimensionsChange?.(snapshot, "undo");
        emit("dimensions:change", snapshot);
        invalidate();
        return true;
      },
      setText(dimension, value) {
        if (!dimension) return false;
        dimension.txt = String(value ?? "").trim();
        commit("text");
        return true;
      },
      updateSelected(values) {
        if (!state.selected) return false;
        if (values.color) state.selected.col = values.color;
        if (Number.isFinite(values.textSize)) state.selected.th = values.textSize;
        if (values.unit !== undefined) state.selected.unit = values.unit;
        commit("style");
        return true;
      },
      commitDrag() {
        commit("move");
      },
      hitTest(worldPoint, tolerancePixels = 10) {
        const tolerance = tolerancePixels / state.view.scale;
        for (let index = state.dimensions.length - 1; index >= 0; index -= 1) {
          const dimension = state.dimensions[index];
          const type = model.typeOf(dimension);
          if (!type?.emit) continue;
          const sink = sinks.hit();
          type.emit(dimension, sink);
          if (sink.hit(worldPoint, tolerance)) return dimension;
        }
        return null;
      },
      splitAt(point, tolerancePixels = 12) {
        const tolerance = tolerancePixels / state.view.scale;
        let target = null;
        let bestDistance = tolerance;
        state.dimensions.forEach((dimension) => {
          const type = model.typeOf(dimension);
          const edge = type?.edge?.(dimension);
          if (!edge || !type.split) return;
          const distance = vector.distSeg(point, edge[0], edge[1]);
          if (distance < bestDistance) {
            bestDistance = distance;
            target = dimension;
          }
        });
        if (!target) return null;
        const parts = model.typeOf(target).split(target, point);
        if (!parts) return null;
        const index = state.dimensions.indexOf(target);
        state.dimensions.splice(index, 1, parts[0], parts[1]);
        state.selected = parts[0];
        commit("split");
        emit("dimension:split", parts);
        return parts;
      },
      snapshot() {
        return cloneDimensions(state.dimensions);
      },
    };

    const sinks = {
      canvas(context) {
        const sink = {
          color: "#000000",
          lineWidth: 1,
          textSize: 16,
          forceColor: null,
          line(a, b) {
            context.strokeStyle = sink.color;
            context.lineWidth = sink.lineWidth;
            context.beginPath();
            context.moveTo(a.x, a.y);
            context.lineTo(b.x, b.y);
            context.stroke();
          },
          triangle(points) {
            context.fillStyle = sink.color;
            context.beginPath();
            context.moveTo(points[0].x, points[0].y);
            context.lineTo(points[1].x, points[1].y);
            context.lineTo(points[2].x, points[2].y);
            context.closePath();
            context.fill();
          },
          text(value, point, angle, textSize) {
            context.save();
            context.translate(point.x, point.y);
            context.rotate(angle);
            context.fillStyle = sink.color;
            context.font = `${textSize}px Arial`;
            context.textAlign = "center";
            context.textBaseline = "middle";
            context.fillText(value, 0, 0);
            context.restore();
          },
        };
        return sink;
      },
      hit() {
        const segments = [];
        const texts = [];
        const sink = {
          color: "",
          lineWidth: 1,
          textSize: 16,
          forceColor: null,
          line(a, b) { segments.push([a, b]); },
          triangle(points) {
            segments.push([points[0], points[1]], [points[1], points[2]], [points[2], points[0]]);
          },
          text(value, point, angle, textSize) {
            texts.push({ point, angle, width: textWidth(value, textSize), height: textSize });
          },
          hit(point, tolerance) {
            if (segments.some((segment) => vector.distSeg(point, segment[0], segment[1]) < tolerance)) return true;
            return texts.some((text) => {
              const delta = vector.sub(point, text.point);
              const cosine = Math.cos(-text.angle);
              const sine = Math.sin(-text.angle);
              return Math.abs(delta.x * cosine - delta.y * sine) < text.width / 2 + tolerance
                && Math.abs(delta.x * sine + delta.y * cosine) < text.height / 2 + tolerance;
            });
          },
        };
        return sink;
      },
    };

    function emitAll(sink) {
      state.dimensions.forEach((dimension) => {
        model.typeOf(dimension)?.emit?.(dimension, sink);
      });
    }

    function screenToWorld(point) {
      return {
        x: (point.x - state.view.tx) / state.view.scale,
        y: (point.y - state.view.ty) / state.view.scale,
      };
    }

    function worldToScreen(point) {
      return {
        x: point.x * state.view.scale + state.view.tx,
        y: point.y * state.view.scale + state.view.ty,
      };
    }

    const engine = {
      COLORS,
      UNITS,
      exporters,
      format,
      emit,
      emitAll,
      invalidate,
      consumeDirty,
      model,
      on,
      screenToWorld,
      sinks,
      state,
      style,
      styleOf,
      textWidth,
      types,
      vector,
      worldToScreen,
    };

    const { sub, add, mul, dot, nrm, per, dst, mid } = vector;

    function geometry(dimension) {
      const direction = nrm(sub(dimension.b, dimension.a));
      let normal = per(direction);
      if (Math.abs(normal.y) > 1e-6) {
        if (normal.y < 0) normal = mul(normal, -1);
      } else if (normal.x < 0) normal = mul(normal, -1);
      return {
        direction,
        normal,
        q1: add(dimension.a, mul(normal, dimension.off)),
        q2: add(dimension.b, mul(normal, dimension.off)),
      };
    }

    function arrow(sink, tip, direction, size) {
      const base = sub(tip, mul(direction, size));
      const normal = mul(per(direction), size * 0.28);
      sink.triangle([tip, add(base, normal), sub(base, normal)]);
    }

    function emitLinear(dimension, sink) {
      const actualStyle = styleOf(dimension);
      const shape = geometry(dimension);
      const extensionDirection = mul(shape.normal, dimension.off < 0 ? -1 : 1);
      sink.lineWidth = actualStyle.lineWidth;
      sink.color = sink.forceColor || actualStyle.color;
      sink.textSize = actualStyle.textSize;
      sink.line(add(dimension.a, mul(extensionDirection, actualStyle.gap)), add(shape.q1, mul(extensionDirection, actualStyle.over)));
      sink.line(add(dimension.b, mul(extensionDirection, actualStyle.gap)), add(shape.q2, mul(extensionDirection, actualStyle.over)));

      const lineDirection = nrm(sub(shape.q2, shape.q1));
      const length = dst(shape.q1, shape.q2);
      const label = model.label(dimension);
      const labelWidth = textWidth(label, actualStyle.textSize);
      sink.line(shape.q1, shape.q2);
      if (length > 2.6 * actualStyle.arrow) {
        arrow(sink, shape.q1, mul(lineDirection, -1), actualStyle.arrow);
        arrow(sink, shape.q2, lineDirection, actualStyle.arrow);
      } else {
        arrow(sink, shape.q1, lineDirection, actualStyle.arrow);
        arrow(sink, shape.q2, mul(lineDirection, -1), actualStyle.arrow);
        sink.line(shape.q1, sub(shape.q1, mul(lineDirection, actualStyle.arrow * 2)));
        sink.line(shape.q2, add(shape.q2, mul(lineDirection, actualStyle.arrow * 2)));
      }

      let textAngle = Math.atan2(shape.direction.y, shape.direction.x);
      if (textAngle > Math.PI / 2) textAngle -= Math.PI;
      else if (textAngle <= -Math.PI / 2) textAngle += Math.PI;
      const upward = { x: Math.sin(textAngle), y: -Math.cos(textAngle) };
      const center = mid(shape.q1, shape.q2);
      const base = length > labelWidth + 2 * actualStyle.arrow
        ? center
        : add(center, mul(lineDirection, length / 2 + actualStyle.arrow * 2 + labelWidth / 2));
      sink.text(label, add(base, mul(upward, actualStyle.textSize * 0.62 + 2)), textAngle, actualStyle.textSize);
    }

    types.register("linear", {
      title: "선형 (두 점 사이)",
      geometry,
      create(a, b) {
        return {
          type: "linear",
          a: { x: a.x, y: a.y },
          b: { x: b.x, y: b.y },
          off: style.offset,
          col: style.color,
          th: style.textSize,
          unit: style.unit,
        };
      },
      measure(dimension) { return dst(dimension.a, dimension.b); },
      emit: emitLinear,
      edge(dimension) { return [dimension.a, dimension.b]; },
      dragTo(dimension, worldPoint) {
        dimension.off = dot(sub(worldPoint, mid(dimension.a, dimension.b)), geometry(dimension).normal);
      },
      split(dimension, point) {
        const ab = sub(dimension.b, dimension.a);
        const lengthSquared = dot(ab, ab) || 1;
        const ratio = dot(sub(point, dimension.a), ab) / lengthSquared;
        if (ratio < 0.02 || ratio > 0.98) return null;
        const projected = {
          x: dimension.a.x + ab.x * ratio,
          y: dimension.a.y + ab.y * ratio,
        };
        const common = {
          off: dimension.off,
          col: dimension.col,
          th: dimension.th,
          unit: model.unitOf(dimension),
        };
        return [
          { type: "linear", a: { ...dimension.a }, b: projected, ...common },
          { type: "linear", a: projected, b: { ...dimension.b }, ...common },
        ];
      },
    });

    return engine;
  }

  Tool.core.drawingEngine = Object.freeze({ COLORS, UNITS, cloneDimensions, create });
})(window.HeechangTool);
