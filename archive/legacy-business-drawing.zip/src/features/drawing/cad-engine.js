(function createCadEngineModule(Tool) {
  "use strict";

  const EPSILON = 1e-8;
  const TAU = Math.PI * 2;
  const TYPES = new Set(["line", "polyline", "rect", "circle", "arc", "text", "dimension"]);
  const DEFAULT_SETTINGS = Object.freeze({
    unit: "mm", grid: true, gridSnap: false, ortho: false, objectSnap: true,
    gridSize: 10, color: "#e2e8f0", lineWidth: 1.5, layer: "0", textSize: 16,
  });
  const NUMBER = "[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:e[+-]?\\d+)?";
  const CARTESIAN = new RegExp(`^(@)?\\s*(${NUMBER})\\s*,\\s*(${NUMBER})$`, "i");
  const POLAR = new RegExp(`^@\\s*(${NUMBER})\\s*<\\s*(${NUMBER})$`, "i");
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const finite = (value) => typeof value === "number" && Number.isFinite(value) && Math.abs(value) <= 1e12;
  const point = (value) => value && finite(value.x) && finite(value.y) ? { x: value.x, y: value.y } : null;
  const addPoint = (a, b) => ({ x: a.x + b.x, y: a.y + b.y });
  const subtract = (a, b) => ({ x: a.x - b.x, y: a.y - b.y });
  const multiply = (a, value) => ({ x: a.x * value, y: a.y * value });
  const dot = (a, b) => a.x * b.x + a.y * b.y;
  const cross = (a, b) => a.x * b.y - a.y * b.x;
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const midpoint = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  const modulo = (angle) => ((angle % TAU) + TAU) % TAU;
  const color = (value, fallback = DEFAULT_SETTINGS.color) => typeof value === "string" && /^#[\da-f]{6}$/i.test(value) ? value : fallback;
  const layerName = (value) => typeof value === "string" && value.trim() ? value.trim().slice(0, 80) : "0";
  const positive = (value, fallback, maximum = 1e6) => finite(value) && value > EPSILON ? Math.min(value, maximum) : fallback;

  function parsePoint(input, base = { x: 0, y: 0 }) {
    if (typeof input !== "string") return null;
    const text = input.trim();
    const cartesian = text.match(CARTESIAN);
    if (cartesian) {
      const x = Number(cartesian[2]);
      const y = -Number(cartesian[3]);
      const origin = cartesian[1] ? point(base) : { x: 0, y: 0 };
      return origin ? point({ x: origin.x + x, y: origin.y + y }) : null;
    }
    const polar = text.match(POLAR);
    if (!polar || !point(base)) return null;
    const length = Number(polar[1]);
    const angle = Number(polar[2]) * Math.PI / 180;
    if (!finite(length) || length < 0 || !finite(angle)) return null;
    return point({ x: base.x + length * Math.cos(angle), y: base.y - length * Math.sin(angle) });
  }

  function normalizeSettings(raw = {}) {
    const settings = { ...DEFAULT_SETTINGS };
    ["grid", "gridSnap", "ortho", "objectSnap"].forEach((name) => {
      if (typeof raw[name] === "boolean") settings[name] = raw[name];
    });
    settings.unit = ["", "mm", "cm", "m"].includes(raw.unit) ? raw.unit : settings.unit;
    settings.gridSize = positive(raw.gridSize, settings.gridSize);
    settings.color = color(raw.color);
    settings.lineWidth = positive(raw.lineWidth, settings.lineWidth, 100);
    settings.textSize = positive(raw.textSize, settings.textSize, 1000);
    settings.layer = layerName(raw.layer);
    return settings;
  }

  function normalizeEntity(raw, settings = DEFAULT_SETTINGS) {
    if (!raw || !TYPES.has(raw.type)) return null;
    const entity = {
      id: typeof raw.id === "string" && raw.id.length <= 120 ? raw.id : "",
      type: raw.type, layer: layerName(raw.layer || settings.layer),
      color: color(raw.color, settings.color), lineWidth: positive(raw.lineWidth, settings.lineWidth, 100),
    };
    if (["line", "dimension"].includes(raw.type)) {
      entity.a = point(raw.a); entity.b = point(raw.b);
      if (!entity.a || !entity.b || distance(entity.a, entity.b) < EPSILON) return null;
      if (raw.type === "dimension") {
        entity.offset = finite(raw.offset) ? raw.offset : 20;
        entity.textSize = positive(raw.textSize, settings.textSize, 1000);
        if (typeof raw.text === "string") entity.text = raw.text.slice(0, 2000);
      }
    } else if (["polyline", "rect"].includes(raw.type)) {
      if (raw.type === "rect" && point(raw.a) && point(raw.b) && !Array.isArray(raw.points)) {
        const a = point(raw.a); const b = point(raw.b);
        entity.points = [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }];
      } else {
        if (!Array.isArray(raw.points) || raw.points.length > 10000) return null;
        entity.points = raw.points.map(point);
      }
      if (entity.points.some((entry) => !entry) || entity.points.length < 2 || (raw.type === "rect" && entity.points.length !== 4)) return null;
      if (raw.type === "rect" && (distance(entity.points[0], entity.points[1]) < EPSILON || distance(entity.points[1], entity.points[2]) < EPSILON)) return null;
      entity.closed = raw.type === "rect" || raw.closed === true;
    } else if (["circle", "arc"].includes(raw.type)) {
      entity.center = point(raw.center); entity.radius = raw.radius;
      if (!entity.center || !finite(raw.radius) || raw.radius < EPSILON) return null;
      if (raw.type === "arc") {
        if (!finite(raw.startAngle) || !finite(raw.endAngle)) return null;
        entity.startAngle = raw.startAngle; entity.endAngle = raw.endAngle;
        entity.clockwise = raw.clockwise === true;
      }
    } else if (raw.type === "text") {
      entity.point = point(raw.point);
      if (!entity.point || typeof raw.text !== "string" || !raw.text.trim()) return null;
      entity.text = raw.text.slice(0, 2000);
      entity.textSize = positive(raw.textSize, settings.textSize, 1000);
      entity.rotation = finite(raw.rotation) ? raw.rotation : 0;
    }
    return entity;
  }

  function normalizeState(raw = {}) {
    if (!raw || typeof raw !== "object") raw = {};
    const settings = normalizeSettings(raw.settings || {});
    const layers = [{ name: "0", color: DEFAULT_SETTINGS.color, visible: true, locked: false }];
    const seenLayers = new Set(["0"]);
    (Array.isArray(raw.layers) ? raw.layers.slice(0, 256) : []).forEach((entry) => {
      if (!entry || typeof entry !== "object") return;
      const name = layerName(entry.name);
      const layer = { name, color: color(entry.color), visible: entry.visible !== false, locked: entry.locked === true };
      if (name === "0") Object.assign(layers[0], layer);
      else if (!seenLayers.has(name)) { layers.push(layer); seenLayers.add(name); }
    });
    if (!seenLayers.has(settings.layer)) settings.layer = "0";
    const ids = new Set();
    let counter = 1;
    const entities = (Array.isArray(raw.entities) ? raw.entities.slice(0, 20000) : []).map((entry) => normalizeEntity(entry, settings)).filter(Boolean);
    const reservedIds = new Set(entities.map((entity) => entity.id).filter(Boolean));
    entities.forEach((entity) => {
      if (!entity.id || ids.has(entity.id)) {
        while (ids.has(`cad-${counter}`) || reservedIds.has(`cad-${counter}`)) counter += 1;
        entity.id = `cad-${counter++}`;
      }
      ids.add(entity.id);
      if (!seenLayers.has(entity.layer)) {
        layers.push({ name: entity.layer, color: entity.color, visible: true, locked: false });
        seenLayers.add(entity.layer);
      }
    });
    if (!seenLayers.has(settings.layer)) settings.layer = "0";
    const selectedIds = [...new Set(Array.isArray(raw.selectedIds) ? raw.selectedIds : [])].filter((id) => ids.has(id));
    return { version: 1, entities, layers, selectedIds, settings };
  }

  function arcContains(entity, angle) {
    if (Math.abs(entity.endAngle - entity.startAngle) >= TAU - EPSILON) return true;
    const span = entity.clockwise ? modulo(entity.endAngle - entity.startAngle) : modulo(entity.startAngle - entity.endAngle);
    const offset = entity.clockwise ? modulo(angle - entity.startAngle) : modulo(entity.startAngle - angle);
    return offset <= span + EPSILON;
  }

  function circlePoint(entity, angle) {
    return { x: entity.center.x + entity.radius * Math.cos(angle), y: entity.center.y + entity.radius * Math.sin(angle) };
  }

  function dimensionGeometry(entity, unit = "mm") {
    const direction = subtract(entity.b, entity.a);
    const length = Math.hypot(direction.x, direction.y) || 1;
    const normal = { x: -direction.y / length, y: direction.x / length };
    const q1 = addPoint(entity.a, multiply(normal, entity.offset));
    const q2 = addPoint(entity.b, multiply(normal, entity.offset));
    const labelPoint = midpoint(q1, q2);
    const textSize = entity.textSize || 16;
    const textPoint = addPoint(labelPoint, multiply(normal, (entity.offset < 0 ? -1 : 1) * textSize * 0.7));
    let rotation = Math.atan2(direction.y, direction.x);
    if (rotation > Math.PI / 2 || rotation < -Math.PI / 2) rotation += Math.PI;
    const label = entity.text || `${Math.round(length * 1000) / 1000}${unit}`;
    return { q1, q2, normal, length, labelPoint, textPoint, textSize, rotation, label };
  }

  function textCorners(entity, centered = false) {
    const size = entity.textSize || 16;
    const lines = String(entity.text || "").split(/\r?\n/);
    const width = Math.max(size * 0.6, ...lines.map((line) => Array.from(line).reduce((sum, character) => sum + (character.charCodeAt(0) > 127 ? 1.05 : 0.85) * size, 0)));
    const angle = entity.rotation || 0;
    const cosine = Math.cos(angle); const sine = Math.sin(angle);
    const left = centered ? -width / 2 : 0;
    const top = centered ? -size * 0.6 : -size;
    const bottom = top + size * 1.2 + (lines.length - 1) * size * 1.25;
    return [{ x: left, y: top }, { x: left + width, y: top }, { x: left + width, y: bottom }, { x: left, y: bottom }].map((entry) => ({
      x: entity.point.x + entry.x * cosine - entry.y * sine,
      y: entity.point.y + entry.x * sine + entry.y * cosine,
    }));
  }

  function dimensionTextCorners(entity) {
    const geometry = dimensionGeometry(entity);
    return textCorners({ point: geometry.textPoint, text: geometry.label, textSize: geometry.textSize, rotation: geometry.rotation }, true);
  }

  function entityPoints(entity) {
    if (entity.type === "line") return [entity.a, entity.b];
    if (entity.type === "dimension") {
      const geometry = dimensionGeometry(entity);
      return [entity.a, entity.b, geometry.q1, geometry.q2, ...dimensionTextCorners(entity)];
    }
    if (["rect", "polyline"].includes(entity.type)) return entity.points;
    if (entity.type === "text") return textCorners(entity);
    if (entity.type === "circle") return [0, Math.PI / 2, Math.PI, Math.PI * 1.5].map((angle) => circlePoint(entity, angle));
    if (entity.type === "arc") return [entity.startAngle, entity.endAngle, ...[0, Math.PI / 2, Math.PI, Math.PI * 1.5].filter((angle) => arcContains(entity, angle))].map((angle) => circlePoint(entity, angle));
    return [];
  }

  function bounds(value) {
    const points = (Array.isArray(value) ? value : value ? [value] : []).flatMap(entityPoints);
    if (!points.length) return null;
    const minX = points.reduce((value, entry) => Math.min(value, entry.x), Infinity);
    const minY = points.reduce((value, entry) => Math.min(value, entry.y), Infinity);
    const maxX = points.reduce((value, entry) => Math.max(value, entry.x), -Infinity);
    const maxY = points.reduce((value, entry) => Math.max(value, entry.y), -Infinity);
    return { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY };
  }

  function segments(entity) {
    if (entity.type === "line") return [[entity.a, entity.b]];
    if (entity.type === "dimension") {
      const geometry = dimensionGeometry(entity);
      return [[entity.a, geometry.q1], [geometry.q1, geometry.q2], [entity.b, geometry.q2]];
    }
    if (["rect", "polyline", "text"].includes(entity.type)) {
      const points = entity.type === "text" ? textCorners(entity) : entity.points;
      const result = points.slice(1).map((entry, index) => [points[index], entry]);
      if (entity.closed || entity.type === "text") result.push([points[points.length - 1], points[0]]);
      return result;
    }
    return [];
  }

  function segmentParameter(testPoint, a, b) {
    const vector = subtract(b, a);
    return dot(subtract(testPoint, a), vector) / (dot(vector, vector) || 1);
  }

  function distanceToSegment(testPoint, a, b) {
    return distance(testPoint, addPoint(a, multiply(subtract(b, a), Math.max(0, Math.min(1, segmentParameter(testPoint, a, b))))));
  }

  function insidePolygon(testPoint, points) {
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
      const a = points[i]; const b = points[j];
      if ((a.y > testPoint.y) !== (b.y > testPoint.y) && testPoint.x < (b.x - a.x) * (testPoint.y - a.y) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
  }

  function hitDistance(entity, testPoint) {
    if (entity.type === "circle") return Math.abs(distance(testPoint, entity.center) - entity.radius);
    if (entity.type === "arc") {
      const angle = Math.atan2(testPoint.y - entity.center.y, testPoint.x - entity.center.x);
      return arcContains(entity, angle) ? Math.abs(distance(testPoint, entity.center) - entity.radius) : Math.min(distance(testPoint, circlePoint(entity, entity.startAngle)), distance(testPoint, circlePoint(entity, entity.endAngle)));
    }
    if (entity.type === "text" && insidePolygon(testPoint, textCorners(entity))) return 0;
    if (entity.type === "dimension" && insidePolygon(testPoint, dimensionTextCorners(entity))) return 0;
    return Math.min(...segments(entity).map(([a, b]) => distanceToSegment(testPoint, a, b)));
  }

  function hitTest(entities, testPoint, tolerance = 6) {
    let result = null; let nearest = tolerance;
    for (let index = entities.length - 1; index >= 0; index -= 1) {
      const entity = entities[index];
      const candidateDistance = hitDistance(entity, testPoint);
      if (candidateDistance <= nearest && (!result || candidateDistance < nearest - EPSILON)) {
        result = entity; nearest = candidateDistance;
      }
    }
    return result;
  }

  function lineIntersection(a, b, c, d, bounded = true) {
    const ab = subtract(b, a); const cd = subtract(d, c);
    const denominator = cross(ab, cd);
    if (Math.abs(denominator) < EPSILON) return null;
    const ac = subtract(c, a);
    const t = cross(ac, cd) / denominator; const u = cross(ac, ab) / denominator;
    if (bounded && (t < -EPSILON || t > 1 + EPSILON || u < -EPSILON || u > 1 + EPSILON)) return null;
    return addPoint(a, multiply(ab, t));
  }

  function lineCircleIntersections(a, b, circle) {
    const vector = subtract(b, a); const offset = subtract(a, circle.center);
    const qa = dot(vector, vector); const qb = 2 * dot(offset, vector); const qc = dot(offset, offset) - circle.radius ** 2;
    if (qa < EPSILON) return [];
    const discriminant = qb * qb - 4 * qa * qc;
    if (discriminant < -EPSILON) return [];
    const root = Math.sqrt(Math.max(0, discriminant));
    const candidates = root < EPSILON ? [-qb / (2 * qa)] : [(-qb - root) / (2 * qa), (-qb + root) / (2 * qa)];
    return candidates.filter((t) => t >= -EPSILON && t <= 1 + EPSILON).map((t) => addPoint(a, multiply(vector, t))).filter((entry) => circle.type !== "arc" || arcContains(circle, Math.atan2(entry.y - circle.center.y, entry.x - circle.center.x)));
  }

  function circleIntersections(a, b) {
    const length = distance(a.center, b.center);
    if (length < EPSILON || length > a.radius + b.radius + EPSILON || length < Math.abs(a.radius - b.radius) - EPSILON) return [];
    const along = (a.radius ** 2 - b.radius ** 2 + length ** 2) / (2 * length);
    const height = Math.sqrt(Math.max(0, a.radius ** 2 - along ** 2));
    const unit = multiply(subtract(b.center, a.center), 1 / length);
    const center = addPoint(a.center, multiply(unit, along));
    const normal = { x: -unit.y, y: unit.x };
    return (height < EPSILON ? [center] : [addPoint(center, multiply(normal, height)), addPoint(center, multiply(normal, -height))]).filter((entry) => [a, b].every((entity) => entity.type !== "arc" || arcContains(entity, Math.atan2(entry.y - entity.center.y, entry.x - entity.center.x))));
  }

  function intersections(a, b) {
    const aCircle = ["circle", "arc"].includes(a.type); const bCircle = ["circle", "arc"].includes(b.type);
    if (aCircle && bCircle) return circleIntersections(a, b);
    if (aCircle) return segments(b).flatMap(([p, q]) => lineCircleIntersections(p, q, a));
    if (bCircle) return segments(a).flatMap(([p, q]) => lineCircleIntersections(p, q, b));
    return segments(a).flatMap(([p, q]) => segments(b).map(([r, s]) => lineIntersection(p, q, r, s)).filter(Boolean));
  }

  function snap(entities, testPoint, tolerance = 6) {
    const candidates = [];
    entities.forEach((entity) => {
      if (["circle", "arc"].includes(entity.type)) {
        candidates.push({ point: entity.center, type: "center", entityId: entity.id });
        if (entity.type === "arc") [entity.startAngle, entity.endAngle].forEach((angle) => candidates.push({ point: circlePoint(entity, angle), type: "endpoint", entityId: entity.id }));
        else [0, Math.PI / 2, Math.PI, Math.PI * 1.5].forEach((angle) => candidates.push({ point: circlePoint(entity, angle), type: "quadrant", entityId: entity.id }));
      } else if (entity.type === "text") candidates.push({ point: entity.point, type: "endpoint", entityId: entity.id });
      else segments(entity).forEach(([a, b]) => {
        candidates.push({ point: a, type: "endpoint", entityId: entity.id }, { point: b, type: "endpoint", entityId: entity.id }, { point: midpoint(a, b), type: "midpoint", entityId: entity.id });
      });
    });
    // Spatially limit intersection work to objects near the cursor.
    const nearby = entities.filter((entity) => hitDistance(entity, testPoint) <= tolerance).slice(-80);
    nearby.forEach((entity, index) => nearby.slice(index + 1).forEach((other) => intersections(entity, other).forEach((entry) => candidates.push({ point: entry, type: "intersection", entityId: entity.id, otherId: other.id }))));
    let nearest = null;
    candidates.forEach((candidate) => {
      const length = distance(candidate.point, testPoint);
      if (length <= tolerance && (!nearest || length < nearest.distance - EPSILON || (Math.abs(length - nearest.distance) < EPSILON && candidate.type === "intersection"))) nearest = { ...candidate, x: candidate.point.x, y: candidate.point.y, distance: length };
    });
    return nearest;
  }

  function boxSelect(entities, a, b, crossing = false) {
    const minX = Math.min(a.x, b.x); const maxX = Math.max(a.x, b.x);
    const minY = Math.min(a.y, b.y); const maxY = Math.max(a.y, b.y);
    const inside = (entry) => entry.x >= minX && entry.x <= maxX && entry.y >= minY && entry.y <= maxY;
    const box = { type: "rect", points: [{ x: minX, y: minY }, { x: maxX, y: minY }, { x: maxX, y: maxY }, { x: minX, y: maxY }], closed: true };
    return entities.filter((entity) => {
      const extent = bounds(entity);
      if (!extent || extent.maxX < minX || extent.minX > maxX || extent.maxY < minY || extent.minY > maxY) return false;
      if (!crossing) return extent.minX >= minX && extent.maxX <= maxX && extent.minY >= minY && extent.maxY <= maxY;
      return entityPoints(entity).some(inside) || intersections(entity, box).length > 0 || (entity.type === "text" && insidePolygon(box.points[0], textCorners(entity))) || (entity.type === "dimension" && insidePolygon(box.points[0], dimensionTextCorners(entity)));
    }).map((entity) => entity.id);
  }

  function transformEntity(entity, options) {
    const result = clone(entity);
    const type = options.type === "copy" ? "move" : options.type;
    const base = point(options.base) || { x: 0, y: 0 };
    const delta = point(options.delta) || { x: 0, y: 0 };
    const angle = -(finite(options.angle) ? options.angle : 0) * Math.PI / 180;
    const factor = finite(options.factor) && options.factor > EPSILON ? options.factor : 1;
    const axisA = point(options.axisA) || base; const axisB = point(options.axisB) || { x: base.x, y: base.y + 1 };
    const axis = subtract(axisB, axisA); const denominator = dot(axis, axis);
    if (type === "mirror" && denominator < EPSILON) return null;
    if (!["move", "rotate", "scale", "mirror"].includes(type)) return null;
    const apply = (entry) => {
      if (type === "move") return addPoint(entry, delta);
      if (type === "scale") return addPoint(base, multiply(subtract(entry, base), factor));
      if (type === "mirror") {
        const projection = addPoint(axisA, multiply(axis, dot(subtract(entry, axisA), axis) / denominator));
        return subtract(multiply(projection, 2), entry);
      }
      const relative = subtract(entry, base);
      return addPoint(base, { x: relative.x * Math.cos(angle) - relative.y * Math.sin(angle), y: relative.x * Math.sin(angle) + relative.y * Math.cos(angle) });
    };
    ["a", "b", "point", "center"].forEach((name) => { if (result[name]) result[name] = apply(result[name]); });
    if (result.points) result.points = result.points.map(apply);
    if (type === "scale") {
      if (result.radius) result.radius *= factor;
      if (result.textSize) result.textSize *= factor;
      if (result.offset !== undefined) result.offset *= factor;
    }
    if (result.type === "arc" && ["rotate", "mirror"].includes(type)) {
      const start = apply(circlePoint(entity, entity.startAngle)); const end = apply(circlePoint(entity, entity.endAngle));
      result.startAngle = Math.atan2(start.y - result.center.y, start.x - result.center.x);
      result.endAngle = Math.atan2(end.y - result.center.y, end.x - result.center.x);
      if (type === "mirror") result.clockwise = !result.clockwise;
      if (Math.abs(entity.endAngle - entity.startAngle) >= TAU - EPSILON) result.endAngle = result.startAngle + (result.clockwise ? TAU : -TAU);
    }
    if (result.type === "text") {
      if (type === "rotate") result.rotation += angle;
      if (type === "mirror") result.rotation = 2 * Math.atan2(axis.y, axis.x) - result.rotation;
    }
    if (result.type === "dimension" && type === "mirror") result.offset *= -1;
    return normalizeEntity(result, DEFAULT_SETTINGS);
  }

  function offsetEntity(entity, amount, sidePoint) {
    if (!finite(amount) || Math.abs(amount) < EPSILON) return null;
    const result = clone(entity);
    if (["circle", "arc"].includes(entity.type)) {
      let sign = Math.sign(amount);
      if (point(sidePoint)) sign = distance(sidePoint, entity.center) < entity.radius ? -1 : 1;
      result.radius += Math.abs(amount) * sign;
      return result.radius > EPSILON ? result : null;
    }
    if (!["line", "rect", "polyline"].includes(entity.type)) return null;
    const lines = segments(entity);
    if (!lines.length || lines.some(([a, b]) => distance(a, b) < EPSILON)) return null;
    let signedAmount = amount;
    if (point(sidePoint)) {
      const nearest = lines.reduce((best, line) => distanceToSegment(sidePoint, ...line) < distanceToSegment(sidePoint, ...best) ? line : best, lines[0]);
      signedAmount = Math.abs(amount) * (cross(subtract(nearest[1], nearest[0]), subtract(sidePoint, nearest[0])) >= 0 ? 1 : -1);
    }
    const shifted = lines.map(([a, b]) => {
      const direction = subtract(b, a); const length = distance(a, b);
      const normal = { x: -direction.y / length * signedAmount, y: direction.x / length * signedAmount };
      return [addPoint(a, normal), addPoint(b, normal)];
    });
    if (entity.type === "line") { result.a = shifted[0][0]; result.b = shifted[0][1]; return result; }
    const closed = entity.closed;
    const points = entity.points.map((entry, index) => {
      if (!closed && index === 0) return shifted[0][0];
      if (!closed && index === entity.points.length - 1) return shifted[shifted.length - 1][1];
      const before = shifted[(index - 1 + shifted.length) % shifted.length]; const after = shifted[index % shifted.length];
      return lineIntersection(...before, ...after, false) || midpoint(before[1], after[0]);
    });
    if (points.some((entry) => !point(entry))) return null;
    // Avoid inverted edges when a closed outline collapses under an inward offset.
    if (closed && points.some((entry, index) => dot(subtract(points[(index + 1) % points.length], entry), subtract(entity.points[(index + 1) % points.length], entity.points[index])) <= EPSILON)) return null;
    result.points = points;
    return result;
  }

  function create(options = {}) {
    const state = normalizeState(options.initialState);
    const history = []; const future = [];
    let idCounter = 1;
    const layerFor = (entity) => state.layers.find((layer) => layer.name === entity.layer);
    const visible = (entity) => layerFor(entity)?.visible !== false;
    const editable = (entity) => visible(entity) && !layerFor(entity)?.locked;
    const emit = (reason) => { if (typeof options.onChange === "function") options.onChange(snapshot(), reason); };
    const snapshot = () => clone(state);
    const restore = (raw) => Object.assign(state, normalizeState(raw));
    function nextId(reservedIds = []) {
      const used = new Set([...state.entities.map((entity) => entity.id), ...reservedIds]);
      while (used.has(`cad-${idCounter}`)) idCounter += 1;
      return `cad-${idCounter++}`;
    }
    function commit(reason, action) {
      const before = snapshot();
      const result = action();
      state.selectedIds = state.selectedIds.filter((id) => state.entities.some((entity) => entity.id === id && editable(entity)));
      if (JSON.stringify(before) !== JSON.stringify(state)) {
        history.push(before); if (history.length > 200) history.shift();
        future.length = 0; emit(reason);
      }
      return result;
    }
    function idsList(ids) { return ids === undefined ? state.selectedIds : Array.isArray(ids) ? ids : [ids]; }
    function add(raw) {
      const isArray = Array.isArray(raw);
      const values = (isArray ? raw : [raw]).map((entry) => normalizeEntity(entry, state.settings));
      if (!values.length || values.some((entry) => !entry)) return isArray ? [] : null;
      if (values.some((entity) => state.layers.some((layer) => layer.name === entity.layer && (layer.locked || !layer.visible)))) return isArray ? [] : null;
      return commit("add", () => {
        const reservedIds = values.map((entity) => entity.id).filter(Boolean);
        values.forEach((entity) => {
          if (!entity.id || state.entities.some((entry) => entry.id === entity.id)) entity.id = nextId(reservedIds);
          if (!state.layers.some((layer) => layer.name === entity.layer)) state.layers.push({ name: entity.layer, color: entity.color, visible: true, locked: false });
          state.entities.push(entity);
        });
        return isArray ? values : values[0];
      });
    }
    function update(id, patch) {
      const current = state.entities.find((entity) => entity.id === id);
      if (!current || !editable(current)) return null;
      const value = normalizeEntity({ ...current, ...patch, id: current.id }, state.settings);
      if (!value) return null;
      if (state.layers.some((layer) => layer.name === value.layer && (layer.locked || !layer.visible))) return null;
      return commit("update", () => {
        if (!state.layers.some((layer) => layer.name === value.layer)) state.layers.push({ name: value.layer, color: value.color, visible: true, locked: false });
        state.entities[state.entities.indexOf(current)] = value; return value;
      });
    }
    function remove(ids) {
      const selected = new Set(idsList(ids));
      return commit("remove", () => {
        const count = state.entities.length;
        state.entities = state.entities.filter((entity) => !selected.has(entity.id) || !editable(entity));
        return count - state.entities.length;
      });
    }
    function clear() {
      return commit("clear", () => { const count = state.entities.length; state.entities = []; state.selectedIds = []; return count; });
    }
    function select(ids) {
      const wanted = new Set(idsList(ids));
      state.selectedIds = state.entities.filter((entity) => wanted.has(entity.id) && editable(entity)).map((entity) => entity.id);
      emit("selection"); return state.selectedIds;
    }
    function setSettings(patch) {
      return commit("settings", () => {
        state.settings = normalizeSettings({ ...state.settings, ...patch });
        if (!state.layers.some((layer) => layer.name === state.settings.layer)) state.settings.layer = "0";
        return state.settings;
      });
    }
    function applyProperties(patch = {}, ids) {
      const wanted = new Set(idsList(ids));
      return commit("properties", () => {
        state.settings = normalizeSettings({ ...state.settings, ...patch });
        if (!state.layers.some((layer) => layer.name === state.settings.layer)) state.settings.layer = "0";
        const style = {};
        ["color", "lineWidth", "textSize"].forEach((name) => {
          if (Object.prototype.hasOwnProperty.call(patch, name)) style[name] = state.settings[name];
        });
        state.entities = state.entities.map((entity) => wanted.has(entity.id) && editable(entity)
          ? normalizeEntity({ ...entity, ...style }, state.settings)
          : entity);
        return state.settings;
      });
    }
    function setLayer(name, patch = {}) {
      name = layerName(name);
      return commit("layer", () => {
        let layer = state.layers.find((entry) => entry.name === name);
        if (!layer) { layer = { name, color: state.settings.color, visible: true, locked: false }; state.layers.push(layer); }
        if ("color" in patch) layer.color = color(patch.color, layer.color);
        if (typeof patch.visible === "boolean") layer.visible = patch.visible;
        if (typeof patch.locked === "boolean") layer.locked = patch.locked;
        return layer;
      });
    }
    function transform(ids, transformOptions = {}) {
      const wanted = new Set(idsList(ids));
      const originals = state.entities.filter((entity) => wanted.has(entity.id) && editable(entity));
      const transformed = originals.map((entity) => transformEntity(entity, transformOptions));
      if (!transformed.length || transformed.some((entity) => !entity)) return [];
      return commit("transform", () => {
        const copying = transformOptions.type === "copy" || transformOptions.copy === true;
        transformed.forEach((entity, index) => {
          if (copying) { entity.id = nextId(); state.entities.push(entity); }
          else state.entities[state.entities.indexOf(originals[index])] = entity;
        });
        state.selectedIds = transformed.map((entity) => entity.id); return transformed;
      });
    }
    function offset(id, amount, sidePoint) {
      const entity = state.entities.find((entry) => entry.id === id);
      if (!entity || !editable(entity)) return null;
      const value = offsetEntity(entity, amount, sidePoint);
      if (!value) return null;
      value.id = "";
      return add(value);
    }
    function trim(id, clickPoint) {
      const entity = state.entities.find((entry) => entry.id === id);
      if (!entity || entity.type !== "line" || !editable(entity) || !point(clickPoint)) return false;
      const cuts = state.entities.filter((other) => other.id !== id && visible(other)).flatMap((other) => intersections(entity, other)).map((entry) => segmentParameter(entry, entity.a, entity.b)).filter((t) => t > EPSILON && t < 1 - EPSILON).sort((a, b) => a - b);
      const parameters = [0, ...cuts.filter((t, index) => index === 0 || Math.abs(t - cuts[index - 1]) > EPSILON), 1];
      if (parameters.length < 3) return false;
      const t = Math.max(0, Math.min(1, segmentParameter(clickPoint, entity.a, entity.b)));
      let cutIndex = parameters.findIndex((entry, index) => index < parameters.length - 1 && t >= entry - EPSILON && t <= parameters[index + 1] + EPSILON);
      if (cutIndex < 0) cutIndex = parameters.length - 2;
      const vector = subtract(entity.b, entity.a);
      const kept = [];
      if (parameters[cutIndex] > EPSILON) kept.push({ ...clone(entity), b: addPoint(entity.a, multiply(vector, parameters[cutIndex])) });
      if (parameters[cutIndex + 1] < 1 - EPSILON) kept.push({ ...clone(entity), a: addPoint(entity.a, multiply(vector, parameters[cutIndex + 1])) });
      return commit("trim", () => {
        const index = state.entities.indexOf(entity);
        kept.forEach((value, valueIndex) => { if (valueIndex > 0) value.id = nextId(); });
        state.entities.splice(index, 1, ...kept); return true;
      });
    }
    function undo() {
      if (!history.length) return false;
      future.push(snapshot()); restore(history.pop()); emit("undo"); return true;
    }
    function redo() {
      if (!future.length) return false;
      history.push(snapshot()); restore(future.pop()); emit("redo"); return true;
    }
    function load(raw) {
      const normalized = normalizeState(raw);
      return commit("load", () => { restore(normalized); return snapshot(); });
    }
    return Object.freeze({
      state, add, update, remove, clear, select, setSettings, applyProperties, setLayer, transform, offset, trim,
      undo, redo, load, snapshot,
      get canUndo() { return history.length > 0; },
      get canRedo() { return future.length > 0; },
      bounds(ids) { const selected = ids === undefined ? null : new Set(idsList(ids)); return bounds(state.entities.filter((entity) => visible(entity) && (!selected || selected.has(entity.id)))); },
      hitTest(testPoint, tolerance) { return hitTest(state.entities.filter(editable), testPoint, tolerance); },
      snap(testPoint, tolerance, excluded = []) { const ids = new Set(idsList(excluded)); return snap(state.entities.filter((entity) => visible(entity) && !ids.has(entity.id)), testPoint, tolerance); },
      boxSelect(a, b, crossing) { return boxSelect(state.entities.filter(editable), a, b, crossing); },
    });
  }

  Tool.core.cadEngine = Object.freeze({
    DEFAULT_SETTINGS, create, normalizeState, hydrate: normalizeState, normalizeEntity,
    parsePoint, bounds, entityPoints, segments, hitTest, snap, boxSelect,
    intersections, dimensionGeometry, transformEntity, offsetEntity,
  });
})(window.HeechangTool);
