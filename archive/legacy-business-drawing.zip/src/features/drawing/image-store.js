(function createDrawingMediaStore(Tool) {
  "use strict";

  const DATABASE_NAME = "heechang-drawing-media-v1";
  const STORE_NAME = "images";
  const DATABASE_VERSION = 1;
  const DEFAULT_RECORD_ID = "drawing-dimension-current";

  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error("이 브라우저에서는 도면 이미지 저장소를 사용할 수 없습니다."));
        return;
      }
      const request = window.indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) database.createObjectStore(STORE_NAME, { keyPath: "id" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("도면 이미지 저장소를 열지 못했습니다."));
      request.onblocked = () => reject(new Error("다른 창에서 도면 이미지 저장소를 사용 중입니다."));
    });
  }

  async function runTransaction(mode, action) {
    const database = await openDatabase();
    try {
      return await new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, mode);
        const store = transaction.objectStore(STORE_NAME);
        let result;
        try {
          result = action(store);
        } catch (error) {
          reject(error);
          return;
        }
        transaction.oncomplete = () => resolve(result?.result ?? result);
        transaction.onerror = () => reject(transaction.error || new Error("도면 이미지 저장에 실패했습니다."));
        transaction.onabort = () => reject(transaction.error || new Error("도면 이미지 저장이 취소되었습니다."));
      });
    } finally {
      database.close();
    }
  }

  function validImageBlob(blob) {
    return blob instanceof Blob && /^image\/(?:png|jpe?g|webp|gif|bmp)$/i.test(blob.type || "");
  }

  async function saveImage(file, recordId = DEFAULT_RECORD_ID) {
    if (!validImageBlob(file)) throw new Error("PNG, JPG, WebP, GIF, BMP 이미지만 열 수 있습니다.");
    const record = {
      id: recordId,
      blob: file,
      name: String(file.name || "도면 이미지"),
      type: file.type,
      size: Number(file.size) || 0,
      updatedAt: new Date().toISOString(),
    };
    await runTransaction("readwrite", (store) => store.put(record));
    return {
      source: "stored",
      recordId,
      name: record.name,
      type: record.type,
      size: record.size,
    };
  }

  async function loadImage(recordId = DEFAULT_RECORD_ID) {
    const record = await runTransaction("readonly", (store) => store.get(recordId));
    if (!record || !validImageBlob(record.blob)) return null;
    return record;
  }

  async function removeImage(recordId = DEFAULT_RECORD_ID) {
    await runTransaction("readwrite", (store) => store.delete(recordId));
  }

  Tool.core.drawingMedia = Object.freeze({
    DATABASE_NAME,
    DEFAULT_RECORD_ID,
    STORE_NAME,
    loadImage,
    removeImage,
    saveImage,
    validImageBlob,
  });
})(window.HeechangTool);
