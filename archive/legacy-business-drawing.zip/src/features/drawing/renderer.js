(function registerDrawingDimensionRenderer(Tool) {
  "use strict";

  const DEFAULT_COLOR = "#e01b24";
  const VALID_COLORS = new Set(Object.values(Tool.core.drawingEngine.COLORS));
  const VALID_UNITS = new Set(Tool.core.drawingEngine.UNITS);

  function clampNumber(value, minimum, maximum, fallback) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(minimum, Math.min(maximum, number));
  }

  function normalizePoint(value) {
    if (!value || !Number.isFinite(Number(value.x)) || !Number.isFinite(Number(value.y))) return null;
    return { x: Number(value.x), y: Number(value.y) };
  }

  function normalizeDimension(value) {
    if (!value || value.type !== "linear") return null;
    const a = normalizePoint(value.a);
    const b = normalizePoint(value.b);
    if (!a || !b) return null;
    const dimension = {
      type: "linear",
      a,
      b,
      off: Number.isFinite(Number(value.off)) ? Number(value.off) : 34,
      col: VALID_COLORS.has(value.col) ? value.col : DEFAULT_COLOR,
      th: Number.isFinite(Number(value.th)) ? clampNumber(value.th, 4, 128, 16) : 16,
      unit: VALID_UNITS.has(value.unit) ? value.unit : "mm",
    };
    if (typeof value.txt === "string") dimension.txt = value.txt.slice(0, 200);
    return dimension;
  }

  function normalizeImage(value) {
    if (value?.source !== "stored") return null;
    const recordId = typeof value.recordId === "string" && /^[a-zA-Z0-9_-]{1,120}$/.test(value.recordId)
      ? value.recordId
      : null;
    const type = typeof value.type === "string" && /^image\/(?:png|jpe?g|webp|gif|bmp)$/i.test(value.type)
      ? value.type
      : null;
    if (!recordId || !type) return null;
    return {
      source: "stored",
      name: typeof value.name === "string" && value.name.trim() ? value.name.slice(0, 255) : "도면 이미지",
      type,
      size: Math.max(0, Number.isFinite(Number(value.size)) ? Number(value.size) : 0),
      recordId,
    };
  }

  function createDefaultState() {
    return {
      version: 1,
      image: null,
      dimensions: [],
      settings: {
        color: DEFAULT_COLOR,
        textSize: 16,
        unit: "mm",
        askForValue: true,
      },
      detection: { quality: 15, minDistance: 10 },
      activeMode: "cad",
      cad: Tool.core.cadEngine.normalizeState(),
    };
  }

  function hydrate(documentDefinition, rawState) {
    const defaults = createDefaultState(documentDefinition);
    if (!rawState || typeof rawState !== "object") return defaults;
    const image = normalizeImage(rawState.image);
    const settings = rawState.settings && typeof rawState.settings === "object" ? rawState.settings : {};
    const detection = rawState.detection && typeof rawState.detection === "object" ? rawState.detection : {};
    return {
      version: 1,
      image,
      dimensions: image && Array.isArray(rawState.dimensions) ? rawState.dimensions.map(normalizeDimension).filter(Boolean) : [],
      settings: {
        color: VALID_COLORS.has(settings.color) ? settings.color : defaults.settings.color,
        textSize: clampNumber(settings.textSize, 4, 128, defaults.settings.textSize),
        unit: VALID_UNITS.has(settings.unit) ? settings.unit : defaults.settings.unit,
        askForValue: typeof settings.askForValue === "boolean" ? settings.askForValue : defaults.settings.askForValue,
      },
      detection: {
        quality: clampNumber(detection.quality, 1, 120, defaults.detection.quality),
        minDistance: clampNumber(detection.minDistance, 4, 40, defaults.detection.minDistance),
      },
      activeMode: rawState.activeMode === "image" || (!rawState.activeMode && image) ? "image" : "cad",
      cad: Tool.core.cadEngine.normalizeState(rawState.cad),
    };
  }

  function mount(context) {
    const root = document.createElement("article");
    root.className = "paper drawing-tool-paper drawing-suite";
    root.dataset.documentId = context.documentDefinition.id;
    root.setAttribute("aria-label", "간이 CAD 및 도면 이미지 치수 작업공간");
    context.ui.mountPaper(root, context.documentDefinition.page);
    root.innerHTML = '<nav class="drawing-mode-tabs" aria-label="도면 작업 방식"><button type="button" data-drawing-mode="cad">간이 CAD <span>직접 그리기</span></button><button type="button" data-drawing-mode="image">이미지 치수 <span>기존 도면에 치수 넣기</span></button></nav><div class="drawing-suite-body"></div>';
    const body = root.querySelector(".drawing-suite-body");
    const buttons = Array.from(root.querySelectorAll("[data-drawing-mode]"));
    let dispose = null;
    function switchMode(mode) {
      dispose?.();
      context.updateDocument((state) => { state.activeMode = mode; });
      buttons.forEach((button) => {
        button.classList.toggle("is-active", button.dataset.drawingMode === mode);
        button.setAttribute("aria-pressed", String(button.dataset.drawingMode === mode));
      });
      body.className = mode === "cad" ? "drawing-suite-body cad-workspace" : "drawing-suite-body drawing-image-workspace";
      dispose = (mode === "cad" ? Tool.core.cadWorkspace : Tool.core.drawingWorkspace).mount({ context, root: body });
    }
    const handlers = buttons.map((button) => {
      const handler = () => switchMode(button.dataset.drawingMode);
      button.addEventListener("click", handler);
      return () => button.removeEventListener("click", handler);
    });
    switchMode(context.documentState.activeMode);
    return () => { dispose?.(); handlers.forEach((remove) => remove()); root.replaceChildren(); };
  }

  Tool.core.renderers.register("drawing-dimension", { createDefaultState, hydrate, mount });
})(window.HeechangTool);
