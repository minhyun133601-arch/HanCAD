(function createDrawingExportersModule(Tool) {
  "use strict";

  function baseName(name) {
    return String(name || "drawing").replace(/\.[^.]+$/, "").replace(/[\\/:*?"<>|]+/g, "_") || "drawing";
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.hidden = true;
    document.body.appendChild(anchor);
    anchor.click();
    window.setTimeout(() => {
      anchor.remove();
      URL.revokeObjectURL(url);
    }, 1000);
  }

  function register(engine) {
    engine.exporters.register("png", {
      label: "PNG 저장",
      async run() {
        const state = engine.state;
        if (!state.image) throw new Error("먼저 도면 이미지를 여세요.");
        const canvas = document.createElement("canvas");
        canvas.width = state.width;
        canvas.height = state.height;
        const context = canvas.getContext("2d");
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, state.width, state.height);
        context.drawImage(state.image, 0, 0);
        engine.emitAll(engine.sinks.canvas(context));
        const blob = await new Promise((resolve, reject) => {
          canvas.toBlob((value) => value ? resolve(value) : reject(new Error("PNG 파일을 만들지 못했습니다.")), "image/png");
        });
        downloadBlob(blob, `${baseName(state.name)}_치수.png`);
      },
    });

    engine.exporters.register("dxf", {
      label: "DXF 저장",
      primary: true,
      run() {
        const state = engine.state;
        if (!state.image) throw new Error("먼저 도면 이미지를 여세요.");
        const scale = state.unitsPerPixel;
        const height = state.height;
        const lines = [];
        const push = (code, value) => lines.push(code, value);
        const xValue = (point) => (point.x * scale).toFixed(4);
        const yValue = (point) => ((height - point.y) * scale).toFixed(4);
        let sink;
        const colorCode = () => ({ "#e01b24": 1, "#1a56d6": 5, "#111111": 7 })[sink.color] || 1;

        push(0, "SECTION"); push(2, "HEADER"); push(9, "$ACADVER"); push(1, "AC1009"); push(0, "ENDSEC");
        push(0, "SECTION"); push(2, "TABLES");
        push(0, "TABLE"); push(2, "LTYPE"); push(70, 1);
        push(0, "LTYPE"); push(2, "CONTINUOUS"); push(70, 0); push(3, "Solid line"); push(72, 65); push(73, 0); push(40, "0.0");
        push(0, "ENDTAB");
        push(0, "TABLE"); push(2, "LAYER"); push(70, 1);
        push(0, "LAYER"); push(2, "DIM"); push(70, 0); push(62, 1); push(6, "CONTINUOUS");
        push(0, "ENDTAB");
        push(0, "TABLE"); push(2, "STYLE"); push(70, 1);
        push(0, "STYLE"); push(2, "STANDARD"); push(70, 0); push(40, "0.0"); push(41, "1.0"); push(50, "0.0");
        push(71, 0); push(42, "2.5"); push(3, "txt"); push(4, "");
        push(0, "ENDTAB"); push(0, "ENDSEC");
        push(0, "SECTION"); push(2, "ENTITIES");

        sink = {
          color: "#e01b24",
          lineWidth: 1,
          textSize: 16,
          forceColor: null,
          line(a, b) {
            push(0, "LINE"); push(8, "DIM"); push(62, colorCode());
            push(10, xValue(a)); push(20, yValue(a)); push(30, "0.0");
            push(11, xValue(b)); push(21, yValue(b)); push(31, "0.0");
          },
          triangle(points) {
            push(0, "SOLID"); push(8, "DIM"); push(62, colorCode());
            push(10, xValue(points[0])); push(20, yValue(points[0])); push(30, "0.0");
            push(11, xValue(points[1])); push(21, yValue(points[1])); push(31, "0.0");
            push(12, xValue(points[2])); push(22, yValue(points[2])); push(32, "0.0");
            push(13, xValue(points[2])); push(23, yValue(points[2])); push(33, "0.0");
          },
          text(value, point, angle, textSize) {
            let degrees = (-angle * 180 / Math.PI) % 360;
            if (degrees < 0) degrees += 360;
            push(0, "TEXT"); push(8, "DIM"); push(62, colorCode());
            push(10, xValue(point)); push(20, yValue(point)); push(30, "0.0");
            push(40, (textSize * scale).toFixed(4)); push(1, value); push(50, degrees.toFixed(4));
            push(72, 1); push(73, 2); push(11, xValue(point)); push(21, yValue(point)); push(31, "0.0");
          },
        };
        engine.emitAll(sink);
        push(0, "ENDSEC"); push(0, "EOF");
        downloadBlob(new Blob([`${lines.join("\r\n")}\r\n`], { type: "application/dxf" }), `${baseName(state.name)}_치수.dxf`);
      },
    });
  }

  Tool.core.drawingExporters = Object.freeze({ baseName, downloadBlob, register });
})(window.HeechangTool);
