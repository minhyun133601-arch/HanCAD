(function createCadExportersModule(Tool) {
  "use strict";

  const TAU = Math.PI * 2;
  const number = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
  const point = (value) => ({ x: number(value && value.x), y: number(value && value.y) });
  const cleanNumber = (value) => String(Math.round(number(value) * 1000000) / 1000000);
  const escapeXml = (value) => String(value == null ? "" : value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[character]);
  const normalAngle = (angle) => ((number(angle) % TAU) + TAU) % TAU;
  let textMeasureContext = null;
  let measurementAttempted = false;

  function color(value, readable = false) {
    let hex = /^#[a-f0-9]{6}$/i.test(String(value)) ? String(value) : "#26364c";
    if (/^#[a-f0-9]{3}$/i.test(String(value))) hex = `#${String(value).slice(1).split("").map((digit) => digit + digit).join("")}`;
    if (!readable) return hex;
    const rgb = [1, 3, 5].map((offset) => parseInt(hex.slice(offset, offset + 2), 16));
    const luminance = (rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722) / 255;
    if (luminance > 0.65) return `#${rgb.map((channel) => Math.round(channel * 0.42).toString(16).padStart(2, "0")).join("")}`;
    return hex;
  }

  function layerName(entity) {
    return String(entity.layer == null ? "0" : entity.layer);
  }

  function layerOf(snapshot, entity) {
    return (Array.isArray(snapshot.layers) ? snapshot.layers : []).find((layer) => String(layer.name == null ? layer.id : layer.name) === layerName(entity));
  }

  function entitiesOf(snapshot, visibleOnly = false) {
    return (Array.isArray(snapshot.entities) ? snapshot.entities : []).filter((entity) => entity && (!visibleOnly || !layerOf(snapshot, entity) || layerOf(snapshot, entity).visible !== false));
  }

  function entityColor(snapshot, entity, readable = false) {
    const layer = layerOf(snapshot, entity);
    return color(entity.color || (layer && layer.color) || "#26364c", readable);
  }

  function polygonPoints(entity) {
    if (Array.isArray(entity.points)) return entity.points.map(point);
    if (entity.type === "rect" && entity.a && entity.b) {
      const a = point(entity.a), b = point(entity.b);
      return [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }];
    }
    return [];
  }

  function arcSweep(entity) {
    const start = number(entity.startAngle), end = number(entity.endAngle);
    if (Math.abs(end - start) >= TAU - 1e-9) return entity.clockwise ? TAU : -TAU;
    return entity.clockwise ? normalAngle(end - start) : -normalAngle(start - end);
  }

  function dimensionGeometry(entity, unit) {
    const a = point(entity.a), b = point(entity.b);
    const dx = b.x - a.x, dy = b.y - a.y, length = Math.hypot(dx, dy);
    const ux = length ? dx / length : 1, uy = length ? dy / length : 0;
    const nx = -uy, ny = ux, offset = number(entity.offset, 20);
    const q1 = { x: a.x + nx * offset, y: a.y + ny * offset };
    const q2 = { x: b.x + nx * offset, y: b.y + ny * offset };
    const textSize = Math.max(0.1, number(entity.textSize, 12));
    const arrow = Math.min(textSize * 0.55, Math.max(length * 0.15, 1));
    let rotation = Math.atan2(dy, dx);
    if (rotation > Math.PI / 2 || rotation < -Math.PI / 2) rotation += Math.PI;
    const label = entity.text == null || entity.text === "" ? `${cleanNumber(Math.round(length * 1000) / 1000)}${entity.unit == null ? (unit == null ? "mm" : unit) : entity.unit}` : String(entity.text);
    const textPoint = { x: (q1.x + q2.x) / 2 + nx * (offset < 0 ? -textSize * 0.7 : textSize * 0.7), y: (q1.y + q2.y) / 2 + ny * (offset < 0 ? -textSize * 0.7 : textSize * 0.7) };
    return {
      a, b, q1, q2, label, textPoint, textSize, rotation,
      lines: [[a, q1], [b, q2], [q1, q2]],
      arrows: [[q1, { x: q1.x + ux * arrow + nx * arrow * 0.4, y: q1.y + uy * arrow + ny * arrow * 0.4 }, { x: q1.x + ux * arrow - nx * arrow * 0.4, y: q1.y + uy * arrow - ny * arrow * 0.4 }], [q2, { x: q2.x - ux * arrow + nx * arrow * 0.4, y: q2.y - uy * arrow + ny * arrow * 0.4 }, { x: q2.x - ux * arrow - nx * arrow * 0.4, y: q2.y - uy * arrow - ny * arrow * 0.4 }]],
    };
  }

  function drawText(context, value, at, textSize, rotation, centered = false) {
    context.save();
    context.translate(at.x, at.y);
    context.rotate(number(rotation));
    context.font = `${textSize}px Arial, "Malgun Gothic", sans-serif`;
    context.textAlign = centered ? "center" : "left";
    context.textBaseline = centered ? "middle" : "alphabetic";
    String(value || "").split(/\r?\n/).forEach((line, index) => context.fillText(line, 0, index * textSize * 1.25));
    context.restore();
  }

  function drawEntity(context, entity, options = {}) {
    if (!context || !entity) return;
    const scale = Math.max(0.000001, Math.abs(number(options.scale, 1)));
    context.save();
    context.strokeStyle = color(options.selected ? "#38bdf8" : (options.color || entity.color));
    context.fillStyle = context.strokeStyle;
    context.lineWidth = Math.max(0.25, number(options.lineWidth, number(entity.lineWidth, 1.5))) / scale;
    context.lineCap = "round";
    context.lineJoin = "round";
    const line = (a, b) => { context.beginPath(); context.moveTo(a.x, a.y); context.lineTo(b.x, b.y); context.stroke(); };
    if (entity.type === "line") line(point(entity.a), point(entity.b));
    if (entity.type === "polyline" || entity.type === "rect") {
      const points = polygonPoints(entity);
      if (points.length) {
        context.beginPath(); context.moveTo(points[0].x, points[0].y);
        points.slice(1).forEach((at) => context.lineTo(at.x, at.y));
        if (entity.closed || entity.type === "rect") context.closePath();
        context.stroke();
      }
    }
    if (entity.type === "circle" || entity.type === "arc") {
      const center = point(entity.center);
      const radius = Math.abs(number(entity.radius));
      if (radius > 0) {
        context.beginPath();
        context.arc(center.x, center.y, radius, entity.type === "circle" ? 0 : number(entity.startAngle), entity.type === "circle" ? TAU : number(entity.startAngle) + arcSweep(entity), entity.type === "arc" && !entity.clockwise);
        context.stroke();
      }
    }
    if (entity.type === "text") drawText(context, entity.text, point(entity.point), Math.max(0.1, number(entity.textSize, 12)), entity.rotation);
    if (entity.type === "dimension") {
      const dimension = dimensionGeometry(entity, options.unit);
      dimension.lines.forEach(([a, b]) => line(a, b));
      dimension.arrows.forEach((points) => {
        context.beginPath(); context.moveTo(points[0].x, points[0].y); points.slice(1).forEach((at) => context.lineTo(at.x, at.y)); context.closePath(); context.fill();
      });
      drawText(context, dimension.label, dimension.textPoint, dimension.textSize, dimension.rotation, true);
    }
    context.restore();
  }

  function textBounds(at, value, textSize, rotation, centered = false) {
    const lines = String(value || "").split(/\r?\n/);
    if (!measurementAttempted && typeof document !== "undefined") {
      measurementAttempted = true;
      try { textMeasureContext = document.createElement("canvas").getContext("2d"); } catch (_) { textMeasureContext = null; }
    }
    if (textMeasureContext) textMeasureContext.font = `${textSize}px Arial, "Malgun Gothic", sans-serif`;
    const width = Math.max(textSize, ...lines.map((line) => {
      const measurement = textMeasureContext && textMeasureContext.measureText(line);
      // A conservative cell width also keeps Korean text inside nonbrowser exports.
      return measurement && Number.isFinite(measurement.width) ? measurement.width + textSize * 0.1 : Math.max(1, Array.from(line).length) * textSize * 1.15;
    }));
    const left = centered ? -width / 2 : 0, top = centered ? -textSize / 2 : -textSize;
    const height = textSize * Math.max(1, lines.length) * 1.25;
    const cosine = Math.cos(number(rotation)), sine = Math.sin(number(rotation));
    return [[left, top], [left + width, top], [left + width, top + height], [left, top + height]].map(([x, y]) => ({ x: at.x + x * cosine - y * sine, y: at.y + x * sine + y * cosine }));
  }

  function boundsOf(snapshot, visibleOnly = true) {
    const points = [];
    entitiesOf(snapshot, visibleOnly).forEach((entity) => {
      if (entity.type === "line") points.push(point(entity.a), point(entity.b));
      if (entity.type === "polyline" || entity.type === "rect") points.push(...polygonPoints(entity));
      if (entity.type === "circle" || entity.type === "arc") {
        const center = point(entity.center), radius = Math.abs(number(entity.radius));
        points.push({ x: center.x - radius, y: center.y - radius }, { x: center.x + radius, y: center.y + radius });
      }
      if (entity.type === "text") points.push(...textBounds(point(entity.point), entity.text, Math.max(0.1, number(entity.textSize, 12)), entity.rotation));
      if (entity.type === "dimension") {
        const dimension = dimensionGeometry(entity, snapshot.settings && snapshot.settings.unit);
        points.push(dimension.a, dimension.b, dimension.q1, dimension.q2, ...dimension.arrows.flat(), ...textBounds(dimension.textPoint, dimension.label, dimension.textSize, dimension.rotation, true));
      }
    });
    if (!points.length) return { minX: 0, minY: 0, maxX: 100, maxY: 100, width: 100, height: 100 };
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    points.forEach((at) => { minX = Math.min(minX, at.x); minY = Math.min(minY, at.y); maxX = Math.max(maxX, at.x); maxY = Math.max(maxY, at.y); });
    return { minX, minY, maxX, maxY, width: Math.max(1, maxX - minX), height: Math.max(1, maxY - minY) };
  }

  function toSvg(snapshot = {}) {
    const bounds = boundsOf(snapshot), margin = Math.max(10, Math.max(bounds.width, bounds.height) * 0.04);
    const width = bounds.width + margin * 2, height = bounds.height + margin * 2;
    const lines = [`<?xml version="1.0" encoding="UTF-8"?>`, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${cleanNumber(bounds.minX - margin)} ${cleanNumber(bounds.minY - margin)} ${cleanNumber(width)} ${cleanNumber(height)}" width="${cleanNumber(width)}" height="${cleanNumber(height)}">`, `<title>${escapeXml(snapshot.name || "CAD drawing")}</title>`, `<rect x="${cleanNumber(bounds.minX - margin)}" y="${cleanNumber(bounds.minY - margin)}" width="${cleanNumber(width)}" height="${cleanNumber(height)}" fill="#ffffff"/>`];
    const xy = (at) => `${cleanNumber(at.x)},${cleanNumber(at.y)}`;
    const text = (value, at, size, rotation, fill, centered = false) => {
      const content = String(value || "").split(/\r?\n/).map((line, index) => `<tspan x="0" dy="${index ? cleanNumber(size * 1.25) : "0"}">${escapeXml(line)}</tspan>`).join("");
      return `<text transform="translate(${cleanNumber(at.x)} ${cleanNumber(at.y)}) rotate(${cleanNumber(number(rotation) * 180 / Math.PI)})" fill="${fill}" stroke="none" font-family="Arial, Malgun Gothic, sans-serif" font-size="${cleanNumber(size)}"${centered ? ' text-anchor="middle" dominant-baseline="central"' : ""}>${content}</text>`;
    };
    entitiesOf(snapshot, true).forEach((entity) => {
      const stroke = entityColor(snapshot, entity, true);
      lines.push(`<g data-layer="${escapeXml(layerName(entity))}" stroke="${stroke}" stroke-width="${cleanNumber(Math.max(0.25, number(entity.lineWidth, 1.5)))}" stroke-linecap="round" stroke-linejoin="round" fill="none">`);
      const line = (a, b) => `<line x1="${cleanNumber(a.x)}" y1="${cleanNumber(a.y)}" x2="${cleanNumber(b.x)}" y2="${cleanNumber(b.y)}"/>`;
      if (entity.type === "line") lines.push(line(point(entity.a), point(entity.b)));
      if (entity.type === "polyline" || entity.type === "rect") lines.push(`<${entity.closed || entity.type === "rect" ? "polygon" : "polyline"} points="${polygonPoints(entity).map(xy).join(" ")}"/>`);
      if (entity.type === "circle") lines.push(`<circle cx="${cleanNumber(point(entity.center).x)}" cy="${cleanNumber(point(entity.center).y)}" r="${cleanNumber(Math.abs(number(entity.radius)))}"/>`);
      if (entity.type === "arc") {
        const center = point(entity.center), radius = Math.abs(number(entity.radius)), start = number(entity.startAngle), sweep = arcSweep(entity);
        const at = (angle) => ({ x: center.x + radius * Math.cos(angle), y: center.y + radius * Math.sin(angle) });
        if (Math.abs(sweep) >= TAU - 1e-9) lines.push(`<circle cx="${cleanNumber(center.x)}" cy="${cleanNumber(center.y)}" r="${cleanNumber(radius)}"/>`);
        else lines.push(`<path d="M ${xy(at(start))} A ${cleanNumber(radius)} ${cleanNumber(radius)} 0 ${Math.abs(sweep) > Math.PI ? 1 : 0} ${entity.clockwise ? 1 : 0} ${xy(at(start + sweep))}"/>`);
      }
      if (entity.type === "text") lines.push(text(entity.text, point(entity.point), Math.max(0.1, number(entity.textSize, 12)), entity.rotation, stroke));
      if (entity.type === "dimension") {
        const dimension = dimensionGeometry(entity, snapshot.settings && snapshot.settings.unit);
        dimension.lines.forEach(([a, b]) => lines.push(line(a, b)));
        dimension.arrows.forEach((points) => lines.push(`<polygon points="${points.map(xy).join(" ")}" fill="${stroke}" stroke="none"/>`));
        lines.push(text(dimension.label, dimension.textPoint, dimension.textSize, dimension.rotation, stroke, true));
      }
      lines.push("</g>");
    });
    lines.push("</svg>");
    return lines.join("\n");
  }

  function toDxf(snapshot = {}) {
    const output = [], push = (code, value) => output.push(String(code), String(value));
    const safeString = (value) => String(value == null ? "" : value).replace(/[\r\n\u0000-\u001f]/g, " ");
    const layers = new Map([["0", { name: "0", color: "#26364c", visible: true }]]);
    (Array.isArray(snapshot.layers) ? snapshot.layers : []).forEach((layer) => layers.set(String(layer.name == null ? layer.id : layer.name), layer));
    entitiesOf(snapshot).forEach((entity) => { if (!layers.has(layerName(entity))) layers.set(layerName(entity), { name: layerName(entity) }); });
    const layerNames = new Map(), usedNames = new Set();
    layers.forEach((layer, name) => {
      const base = safeString(name).replace(/[<>/\\":;?*|=]/g, "_") || "0";
      let candidate = base, suffix = 2;
      while (usedNames.has(candidate.toUpperCase())) candidate = `${base}_${suffix++}`;
      layerNames.set(name, candidate); usedNames.add(candidate.toUpperCase());
    });
    const dxfLayer = (value) => layerNames.get(String(value)) || "0";
    const bounds = boundsOf(snapshot, false), unit = snapshot.settings && snapshot.settings.unit;
    push(0, "SECTION"); push(2, "HEADER"); push(9, "$ACADVER"); push(1, "AC1021"); push(9, "$INSUNITS"); push(70, ({ mm: 4, cm: 5, m: 6, in: 1, ft: 2 })[unit] || 0);
    push(9, "$EXTMIN"); push(10, cleanNumber(bounds.minX)); push(20, cleanNumber(-bounds.maxY)); push(30, 0);
    push(9, "$EXTMAX"); push(10, cleanNumber(bounds.maxX)); push(20, cleanNumber(-bounds.minY)); push(30, 0); push(0, "ENDSEC");
    push(0, "SECTION"); push(2, "TABLES");
    push(0, "TABLE"); push(2, "LTYPE"); push(100, "AcDbSymbolTable"); push(70, 1); push(0, "LTYPE"); push(100, "AcDbSymbolTableRecord"); push(100, "AcDbLinetypeTableRecord"); push(2, "CONTINUOUS"); push(70, 0); push(3, "Solid line"); push(72, 65); push(73, 0); push(40, 0); push(0, "ENDTAB");
    push(0, "TABLE"); push(2, "LAYER"); push(100, "AcDbSymbolTable"); push(70, layers.size);
    layers.forEach((layer, name) => { push(0, "LAYER"); push(100, "AcDbSymbolTableRecord"); push(100, "AcDbLayerTableRecord"); push(2, dxfLayer(name)); push(70, layer.locked ? 4 : 0); push(62, layer.visible === false ? -7 : 7); push(420, parseInt(color(layer.color).slice(1), 16)); push(6, "CONTINUOUS"); });
    push(0, "ENDTAB"); push(0, "TABLE"); push(2, "STYLE"); push(100, "AcDbSymbolTable"); push(70, 1); push(0, "STYLE"); push(100, "AcDbSymbolTableRecord"); push(100, "AcDbTextStyleTableRecord"); push(2, "STANDARD"); push(70, 0); push(40, 0); push(41, 1); push(50, 0); push(71, 0); push(42, 12); push(3, "arial.ttf"); push(4, ""); push(0, "ENDTAB"); push(0, "ENDSEC");
    push(0, "SECTION"); push(2, "ENTITIES");
    const position = (at, code = 10) => { push(code, cleanNumber(at.x)); push(code + 10, cleanNumber(-at.y)); push(code + 20, 0); };
    const start = (type, entity) => { push(0, type); push(100, "AcDbEntity"); push(8, dxfLayer(layerName(entity))); if (entity.color) { push(62, 7); push(420, parseInt(color(entity.color).slice(1), 16)); } };
    const line = (entity, a, b) => { start("LINE", entity); push(100, "AcDbLine"); position(a); position(b, 11); };
    const polyline = (entity, points, closed) => {
      start("POLYLINE", entity); push(100, "AcDb2dPolyline"); push(66, 1); position({ x: 0, y: 0 }); push(70, closed ? 1 : 0);
      points.forEach((at) => { start("VERTEX", entity); push(100, "AcDbVertex"); push(100, "AcDb2dVertex"); position(at); push(70, 0); }); start("SEQEND", entity);
    };
    const text = (entity, value, at, size, rotation, centered = false) => {
      start("TEXT", entity); push(100, "AcDbText"); position(at); push(40, cleanNumber(size)); push(1, safeString(value)); push(50, cleanNumber(normalAngle(-number(rotation)) * 180 / Math.PI)); push(7, "STANDARD");
      if (centered) { push(72, 1); position(at, 11); }
      push(100, "AcDbText"); if (centered) push(73, 2);
    };
    entitiesOf(snapshot).forEach((entity) => {
      if (entity.type === "line") line(entity, point(entity.a), point(entity.b));
      if (entity.type === "polyline" || entity.type === "rect") polyline(entity, polygonPoints(entity), entity.closed || entity.type === "rect");
      if (entity.type === "circle" || entity.type === "arc") {
        const full = entity.type === "circle" || Math.abs(arcSweep(entity)) >= TAU - 1e-9;
        start(full ? "CIRCLE" : "ARC", entity); push(100, "AcDbCircle"); position(point(entity.center)); push(40, cleanNumber(Math.abs(number(entity.radius))));
        if (!full) {
          // Reflection into CAD's upward Y axis reverses a clockwise canvas arc.
          const startAngle = entity.clockwise ? -number(entity.endAngle) : -number(entity.startAngle);
          const endAngle = entity.clockwise ? -number(entity.startAngle) : -number(entity.endAngle);
          push(100, "AcDbArc"); push(50, cleanNumber(normalAngle(startAngle) * 180 / Math.PI)); push(51, cleanNumber(normalAngle(endAngle) * 180 / Math.PI));
        }
      }
      if (entity.type === "text") text(entity, entity.text, point(entity.point), Math.max(0.1, number(entity.textSize, 12)), entity.rotation);
      if (entity.type === "dimension") {
        const dimension = dimensionGeometry(entity, unit);
        dimension.lines.forEach(([a, b]) => line(entity, a, b));
        dimension.arrows.forEach((points) => polyline(entity, points, true));
        text(entity, dimension.label, dimension.textPoint, dimension.textSize, dimension.rotation, true);
      }
    });
    push(0, "ENDSEC"); push(0, "EOF");
    return `${output.join("\r\n")}\r\n`;
  }

  async function download(snapshot = {}, format = "json") {
    const exporter = Tool.core.drawingExporters;
    if (!exporter || typeof exporter.downloadBlob !== "function") throw new Error("파일 다운로드 기능을 불러오지 못했습니다.");
    const name = exporter.baseName(snapshot.name || "cad-drawing");
    if (format === "dxf") return exporter.downloadBlob(new Blob([toDxf(snapshot)], { type: "application/dxf;charset=utf-8" }), `${name}.dxf`);
    if (format === "svg") return exporter.downloadBlob(new Blob([toSvg(snapshot)], { type: "image/svg+xml;charset=utf-8" }), `${name}.svg`);
    if (format === "json") return exporter.downloadBlob(new Blob([JSON.stringify({ ...snapshot, format: "heechang-cad", version: 1 }, null, 2)], { type: "application/json;charset=utf-8" }), `${name}.json`);
    if (format !== "png") throw new Error(`지원하지 않는 도면 형식입니다: ${format}`);
    const bounds = boundsOf(snapshot), margin = 32;
    const scale = Math.min(4, 2400 / Math.max(bounds.width, bounds.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(128, Math.ceil(bounds.width * scale + margin * 2));
    canvas.height = Math.max(128, Math.ceil(bounds.height * scale + margin * 2));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("PNG 이미지를 만들 수 없습니다.");
    context.fillStyle = "#ffffff"; context.fillRect(0, 0, canvas.width, canvas.height);
    context.translate(margin - bounds.minX * scale, margin - bounds.minY * scale); context.scale(scale, scale);
    entitiesOf(snapshot, true).forEach((entity) => drawEntity(context, entity, { color: entityColor(snapshot, entity, true), lineWidth: Math.max(1, number(entity.lineWidth, 1.5) * scale), scale, unit: snapshot.settings && snapshot.settings.unit }));
    const blob = await new Promise((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("PNG 이미지를 만들지 못했습니다.")), "image/png"));
    return exporter.downloadBlob(blob, `${name}.png`);
  }

  Tool.core.cadExporters = Object.freeze({ drawEntity, toDxf, toSvg, download });
})(window.HeechangTool);
