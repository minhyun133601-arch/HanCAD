(function createDrawingWorkspaceModule(Tool) {
  "use strict";

  const SNAP_LABELS = Object.freeze({ vertex: "꼭지점", refined: "꼭지점(보정)", edge: "선 위", free: "-" });

  function markup(documentState) {
    const settings = documentState.settings;
    const detection = documentState.detection;
    return `
      <div class="drawing-tool-toolbar" data-role="toolbar">
        <div class="drawing-tool-identity" aria-label="도면 치수 도구">
          <span aria-hidden="true">⌖</span>
          <strong>도면 치수</strong>
        </div>
        <div class="drawing-tool-cluster drawing-tool-file-actions">
          <button type="button" data-action="open-image">이미지 열기</button>
          <button type="button" class="is-positive" data-action="fit-view" title="단축키 F">화면 맞춤</button>
        </div>
        <div class="drawing-tool-divider" aria-hidden="true"></div>
        <div class="drawing-tool-cluster drawing-tool-detection-controls">
          <button type="button" class="is-positive" data-action="detect">꼭지점 인식</button>
          <label>감도
            <input type="range" min="1" max="120" value="${detection.quality}" data-setting="quality">
            <output data-role="quality-value">${detection.quality}</output>
          </label>
          <label>간격
            <input type="range" min="4" max="40" value="${detection.minDistance}" data-setting="min-distance">
            <output data-role="distance-value">${detection.minDistance}</output>
          </label>
          <span class="drawing-tool-corner-count" data-role="corner-count">-</span>
        </div>
        <div class="drawing-tool-divider" aria-hidden="true"></div>
        <div class="drawing-tool-cluster drawing-tool-style-controls">
          <button type="button" data-action="toggle-split" title="단축키 X 또는 Alt+클릭">분할</button>
          <span class="drawing-tool-field-label">색</span>
          <button type="button" class="drawing-color-swatch" data-color="#e01b24" aria-label="빨강" title="빨강"></button>
          <button type="button" class="drawing-color-swatch blue" data-color="#1a56d6" aria-label="파랑" title="파랑"></button>
          <button type="button" class="drawing-color-swatch black" data-color="#111111" aria-label="검정" title="검정"></button>
          <label>크기 <input type="number" min="4" max="128" step="1" value="${settings.textSize}" data-setting="text-size"></label>
          <label>단위
            <select data-setting="unit">
              <option value=""${settings.unit === "" ? " selected" : ""}>없음</option>
              <option value="mm"${settings.unit === "mm" ? " selected" : ""}>mm</option>
              <option value="cm"${settings.unit === "cm" ? " selected" : ""}>cm</option>
              <option value="m"${settings.unit === "m" ? " selected" : ""}>m</option>
            </select>
          </label>
        </div>
        <div class="drawing-tool-divider" aria-hidden="true"></div>
        <div class="drawing-tool-cluster drawing-tool-edit-actions">
          <button type="button" data-action="toggle-ask" title="치수를 그린 뒤 값을 직접 입력">값 직접입력</button>
          <button type="button" data-action="delete-selected" title="Delete">선택삭제</button>
          <button type="button" data-action="undo" title="Ctrl+Z">되돌리기</button>
          <button type="button" data-action="clear">전체삭제</button>
        </div>
        <div class="drawing-tool-divider" aria-hidden="true"></div>
        <div class="drawing-tool-cluster drawing-tool-export-actions" data-role="exports"></div>
      </div>
      <div class="drawing-tool-stage" data-role="drawing-stage">
        <canvas data-role="canvas" tabindex="0" aria-label="도면 치수 편집 캔버스"></canvas>
        <div class="drawing-tool-drop" data-role="drop-message">이미지를 끌어다 놓거나 붙여넣으세요</div>
        <div class="drawing-tool-busy" data-role="busy" hidden><span></span><strong data-role="busy-text">도면을 준비하는 중</strong></div>
      </div>
      <div class="drawing-tool-status" aria-live="polite">
        <span>스냅 <b data-role="snap-status">-</b></span>
        <span>측정 <b data-role="measure-status">-</b></span>
        <span>치수 <b data-role="dimension-count">${documentState.dimensions.length}</b></span>
        <span class="drawing-tool-help" data-role="help-status"></span>
      </div>
      <input type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/bmp" data-role="file-input" hidden>`;
  }

  function mount({ context, root }) {
    const { documentState, ui } = context;
    root.innerHTML = markup(documentState);

    const query = (selector) => root.querySelector(selector);
    const canvas = query('[data-role="canvas"]');
    const canvasContext = canvas.getContext("2d");
    const drawingStage = query('[data-role="drawing-stage"]');
    const fileInput = query('[data-role="file-input"]');
    const dropMessage = query('[data-role="drop-message"]');
    const busy = query('[data-role="busy"]');
    const busyText = query('[data-role="busy-text"]');
    const cornerCount = query('[data-role="corner-count"]');
    const snapStatus = query('[data-role="snap-status"]');
    const measureStatus = query('[data-role="measure-status"]');
    const dimensionCount = query('[data-role="dimension-count"]');
    const helpStatus = query('[data-role="help-status"]');
    const qualityInput = query('[data-setting="quality"]');
    const qualityValue = query('[data-role="quality-value"]');
    const distanceInput = query('[data-setting="min-distance"]');
    const distanceValue = query('[data-role="distance-value"]');
    const textSizeInput = query('[data-setting="text-size"]');
    const unitSelect = query('[data-setting="unit"]');
    const splitButton = query('[data-action="toggle-split"]');
    const askButton = query('[data-action="toggle-ask"]');
    let disposed = false;
    let animationFrame = 0;
    let detectionTimer = 0;
    let imageLoadToken = 0;
    let uploadInProgress = false;
    let activeObjectUrl = "";
    let firstPoint = null;
    let drag = null;
    let pan = null;
    let splitMode = false;
    let askForValue = documentState.settings.askForValue;
    const listeners = [];

    const engine = Tool.core.drawingEngine.create({
      initialState: documentState,
      onDimensionsChange(dimensions) {
        if (disposed) return;
        context.updateDocument((state) => { state.dimensions = dimensions; });
        updateStatus();
      },
    });
    const detector = Tool.core.drawingDetection.create(engine);
    Tool.core.drawingExporters.register(engine);

    function listen(target, type, handler, options) {
      target.addEventListener(type, handler, options);
      listeners.push(() => target.removeEventListener(type, handler, options));
    }

    function setBusy(message) {
      busy.hidden = !message;
      if (message) busyText.textContent = message;
    }

    function persistSettings() {
      context.updateDocument((state) => {
        state.settings = {
          color: engine.style.color,
          textSize: engine.style.textSize,
          unit: engine.style.unit,
          askForValue,
        };
      });
    }

    function persistDetection() {
      context.updateDocument((state) => {
        state.detection = {
          quality: Number(qualityInput.value),
          minDistance: Number(distanceInput.value),
        };
      });
    }

    function setActiveControls() {
      splitButton.classList.toggle("is-active", splitMode);
      askButton.classList.toggle("is-active", askForValue);
      root.querySelectorAll("[data-color]").forEach((button) => {
        button.classList.toggle("is-active", button.dataset.color === engine.style.color);
      });
      canvas.style.cursor = splitMode ? "cell" : "crosshair";
    }

    function updateStatus() {
      const state = engine.state;
      snapStatus.textContent = state.snap ? SNAP_LABELS[state.snap.type] || "-" : "-";
      dimensionCount.textContent = String(state.dimensions.length);
      if (firstPoint) {
        const point = state.snap?.point || state.mouse;
        measureStatus.textContent = `${engine.format(engine.vector.dst(firstPoint, point) * state.unitsPerPixel)} px`;
      } else if (state.selected) measureStatus.textContent = engine.model.label(state.selected);
      else measureStatus.textContent = "-";
      helpStatus.textContent = splitMode
        ? "분할 모드 · 치수가 걸린 변 위의 꼭지점을 클릭하세요."
        : "꼭지점 2회 클릭 = 치수 · 더블클릭 = 값 수정 · 가운데 드래그 = 이동 · 휠 = 확대";
    }

    function fitView() {
      const state = engine.state;
      if (!state.image) return;
      const bounds = canvas.getBoundingClientRect();
      const scale = Math.min(bounds.width / state.width, bounds.height / state.height) * 0.93;
      state.view.scale = Math.max(0.03, scale);
      state.view.tx = (bounds.width - state.width * state.view.scale) / 2;
      state.view.ty = (bounds.height - state.height * state.view.scale) / 2;
      engine.invalidate();
    }

    function revokeActiveObjectUrl() {
      if (!activeObjectUrl) return;
      URL.revokeObjectURL(activeObjectUrl);
      activeObjectUrl = "";
    }

    function loadImageUrl(url, name, options = {}) {
      const token = ++imageLoadToken;
      return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => {
          if (disposed || token !== imageLoadToken) {
            reject(new Error("도면 이미지 로드가 취소되었습니다."));
            return;
          }
          try {
            detector.prepare(image);
            engine.state.name = name || "도면 이미지";
            engine.style.offset = Math.max(12, Math.round(Math.max(engine.state.width, engine.state.height) / 40));
            if (options.resetDimensions) engine.model.resetForImage();
            dropMessage.hidden = true;
            fitView();
            updateStatus();
            resolve(image);
          } catch (error) {
            reject(error);
          }
        };
        image.onerror = () => reject(new Error("이미지를 불러오지 못했습니다."));
        image.src = url;
      });
    }

    function scheduleDetection() {
      if (!engine.state.image) return;
      if (detectionTimer) window.clearTimeout(detectionTimer);
      setBusy("꼭지점을 분석하는 중");
      detectionTimer = window.setTimeout(() => {
        detectionTimer = 0;
        if (disposed) return;
        try {
          const corners = detector.run(Number(qualityInput.value), Number(distanceInput.value));
          if (disposed) return;
          cornerCount.textContent = `${corners.length}개`;
        } catch (error) {
          console.error(error);
          ui.showToast("꼭지점 인식 중 오류가 발생했습니다.");
        } finally {
          if (!disposed) setBusy("");
        }
      }, 40);
    }

    async function useUploadedFile(file) {
      if (!file || uploadInProgress) return;
      if (!Tool.core.drawingMedia.validImageBlob(file)) {
        ui.showToast("PNG, JPG, WebP, GIF, BMP 이미지만 열 수 있습니다.");
        return;
      }
      if (engine.state.dimensions.length && !window.confirm("새 이미지를 열면 현재 치수가 모두 지워집니다. 계속할까요?")) return;
      uploadInProgress = true;
      imageLoadToken += 1;
      setBusy("도면 이미지를 저장하는 중");
      let metadata;
      let objectUrl = "";
      try {
        objectUrl = URL.createObjectURL(file);
        await new Promise((resolve, reject) => {
          const image = new Image();
          image.onload = resolve;
          image.onerror = () => reject(new Error("이미지를 불러오지 못했습니다."));
          image.src = objectUrl;
        });
        if (disposed) return;
        metadata = await Tool.core.drawingMedia.saveImage(file);
        context.updateDocument((state) => { state.image = metadata; state.dimensions = []; });
        if (disposed) return;
        await loadImageUrl(objectUrl, metadata.name, { resetDimensions: true });
        revokeActiveObjectUrl();
        activeObjectUrl = objectUrl;
        objectUrl = "";
        context.updateDocument((state) => { state.image = metadata; });
        scheduleDetection();
        ui.showToast(`${metadata.name} 도면을 열었습니다.`);
      } catch (error) {
        if (disposed) return;
        console.error(error);
        ui.showToast(error.message || "도면 이미지를 열지 못했습니다.");
      } finally {
        uploadInProgress = false;
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        if (!detectionTimer) setBusy("");
        fileInput.value = "";
      }
    }

    async function loadInitialImage() {
      const restoreToken = imageLoadToken;
      if (documentState.image?.source === "stored") {
        setBusy("저장한 도면을 불러오는 중");
        try {
          const record = await Tool.core.drawingMedia.loadImage(documentState.image.recordId);
          if (disposed || restoreToken !== imageLoadToken) return;
          if (record) {
            const objectUrl = URL.createObjectURL(record.blob);
            try {
              await loadImageUrl(objectUrl, record.name || documentState.image.name);
              revokeActiveObjectUrl();
              activeObjectUrl = objectUrl;
              scheduleDetection();
              return;
            } catch (error) {
              URL.revokeObjectURL(objectUrl);
              throw error;
            }
          }
          context.updateDocument((state) => {
            state.image = null;
            state.dimensions = [];
          });
          engine.model.resetForImage();
          ui.showToast("저장한 도면을 찾지 못했습니다. 새 이미지를 열어 주세요.");
        } catch (error) {
          if (disposed || error.message === "도면 이미지 로드가 취소되었습니다.") return;
          console.error(error);
          context.updateDocument((state) => {
            state.image = null;
            state.dimensions = [];
          });
          engine.model.resetForImage();
          ui.showToast("저장한 도면을 읽지 못했습니다. 새 이미지를 열어 주세요.");
        }
      }
      cornerCount.textContent = "-";
      dropMessage.hidden = false;
      setBusy("");
      updateStatus();
      engine.invalidate();
    }

    function editDimension(dimension, title = "치수 값을 입력하세요") {
      if (!dimension) return false;
      const value = window.prompt(title, engine.model.rawLabel(dimension));
      if (value === null) return false;
      engine.model.setText(dimension, value);
      return true;
    }

    function canvasPosition(event) {
      const bounds = canvas.getBoundingClientRect();
      return { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    }

    function handlePointerDown(event) {
      if (!engine.state.image) return;
      canvas.focus({ preventScroll: true });
      try { canvas.setPointerCapture(event.pointerId); } catch (error) { /* 일부 브라우저는 보조 버튼 캡처를 거부합니다. */ }
      const screenPoint = canvasPosition(event);
      const worldPoint = engine.screenToWorld(screenPoint);
      if (event.button === 1) {
        event.preventDefault();
        pan = { screenPoint, tx: engine.state.view.tx, ty: engine.state.view.ty };
        return;
      }
      if (event.button === 2) {
        event.preventDefault();
        if (firstPoint) firstPoint = null;
        else {
          const dimension = engine.model.hitTest(worldPoint);
          if (dimension) engine.model.remove(dimension);
        }
        updateStatus();
        engine.invalidate();
        return;
      }
      if (event.button !== 0) return;
      const snapped = detector.snapAt(worldPoint).point;
      if ((splitMode || event.altKey) && !firstPoint) {
        const parts = engine.model.splitAt(snapped);
        if (!parts) ui.showToast("분할할 치수의 기준 변 가까이를 클릭하세요.");
        else if (askForValue) {
          editDimension(parts[0], "앞쪽 치수 값");
          editDimension(parts[1], "뒤쪽 치수 값");
        }
        updateStatus();
        return;
      }

      const selected = engine.model.hitTest(worldPoint);
      if (selected && !firstPoint) {
        engine.state.selected = selected;
        drag = { dimension: selected, screenPoint, moved: false };
        updateStatus();
        engine.invalidate();
        return;
      }

      if (!firstPoint) firstPoint = { x: snapped.x, y: snapped.y };
      else {
        if (engine.vector.dst(firstPoint, snapped) > 2) {
          const dimension = engine.model.createLinear(firstPoint, snapped);
          if (askForValue) {
            const value = window.prompt("치수 값을 입력하세요", engine.model.rawLabel(dimension));
            if (value !== null) dimension.txt = value.trim();
          }
          engine.model.add(dimension);
        }
        firstPoint = null;
      }
      updateStatus();
      engine.invalidate();
    }

    function handlePointerMove(event) {
      const screenPoint = canvasPosition(event);
      const worldPoint = engine.screenToWorld(screenPoint);
      engine.state.mouse = worldPoint;
      if (pan) {
        engine.state.view.tx = pan.tx + screenPoint.x - pan.screenPoint.x;
        engine.state.view.ty = pan.ty + screenPoint.y - pan.screenPoint.y;
        engine.invalidate();
        return;
      }
      if (!engine.state.image) return;
      if (drag) {
        if (!drag.moved && Math.hypot(screenPoint.x - drag.screenPoint.x, screenPoint.y - drag.screenPoint.y) < 4) return;
        drag.moved = true;
        engine.model.typeOf(drag.dimension)?.dragTo?.(drag.dimension, worldPoint);
        engine.invalidate();
        updateStatus();
        return;
      }
      engine.state.snap = detector.snapAt(worldPoint);
      engine.invalidate();
      updateStatus();
    }

    function handlePointerUp() {
      if (drag?.moved) engine.model.commitDrag();
      drag = null;
      pan = null;
    }

    function handleDoubleClick(event) {
      if (!engine.state.image) return;
      const position = canvasPosition(event);
      const dimension = engine.model.hitTest(engine.screenToWorld(position));
      if (!dimension) return;
      engine.state.selected = dimension;
      editDimension(dimension);
    }

    function handleWheel(event) {
      if (!engine.state.image) return;
      event.preventDefault();
      const screenPoint = canvasPosition(event);
      const worldPoint = engine.screenToWorld(screenPoint);
      const factor = event.deltaY < 0 ? 1.15 : 1 / 1.15;
      engine.state.view.scale = Math.max(0.03, Math.min(60, engine.state.view.scale * factor));
      engine.state.view.tx = screenPoint.x - worldPoint.x * engine.state.view.scale;
      engine.state.view.ty = screenPoint.y - worldPoint.y * engine.state.view.scale;
      engine.invalidate();
    }

    function handleKeyDown(event) {
      if (/INPUT|SELECT|TEXTAREA/.test(event.target.tagName)) return;
      const key = event.key.toLowerCase();
      if ((event.ctrlKey || event.metaKey) && key === "z") {
        event.preventDefault();
        engine.model.undo();
      } else if (key === "f") {
        event.preventDefault();
        fitView();
      } else if (key === "x") {
        event.preventDefault();
        splitMode = !splitMode;
        firstPoint = null;
        setActiveControls();
        updateStatus();
      } else if (key === "escape") {
        firstPoint = null;
        engine.state.selected = null;
        engine.invalidate();
        updateStatus();
      } else if (key === "delete" || key === "backspace") {
        if (engine.state.selected) {
          event.preventDefault();
          engine.model.remove(engine.state.selected);
        }
      } else if (key === "enter" && engine.state.selected) {
        event.preventDefault();
        editDimension(engine.state.selected);
      }
    }

    function handlePaste(event) {
      const item = Array.from(event.clipboardData?.items || []).find((candidate) => candidate.type.startsWith("image/"));
      if (!item) return;
      event.preventDefault();
      useUploadedFile(item.getAsFile());
    }

    function draw() {
      const state = engine.state;
      const deviceScale = window.devicePixelRatio || 1;
      const bounds = canvas.getBoundingClientRect();
      const width = Math.max(1, Math.floor(bounds.width * deviceScale));
      const height = Math.max(1, Math.floor(bounds.height * deviceScale));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      canvasContext.setTransform(deviceScale, 0, 0, deviceScale, 0, 0);
      canvasContext.fillStyle = "#4a5058";
      canvasContext.fillRect(0, 0, bounds.width, bounds.height);
      if (!state.image) return;

      canvasContext.save();
      canvasContext.translate(state.view.tx, state.view.ty);
      canvasContext.scale(state.view.scale, state.view.scale);
      canvasContext.imageSmoothingEnabled = state.view.scale < 2.5;
      canvasContext.drawImage(state.image, 0, 0);
      const scale = state.view.scale;
      const cornerRadius = 3.5 / scale;
      canvasContext.strokeStyle = "rgba(0, 190, 255, .8)";
      canvasContext.lineWidth = 1 / scale;
      canvasContext.beginPath();
      state.corners.forEach((point) => {
        canvasContext.moveTo(point.x - cornerRadius, point.y);
        canvasContext.lineTo(point.x + cornerRadius, point.y);
        canvasContext.moveTo(point.x, point.y - cornerRadius);
        canvasContext.lineTo(point.x, point.y + cornerRadius);
      });
      canvasContext.stroke();

      const sink = engine.sinks.canvas(canvasContext);
      state.dimensions.forEach((dimension) => {
        sink.forceColor = dimension === state.selected ? "#1e90ff" : null;
        engine.model.typeOf(dimension)?.emit?.(dimension, sink);
      });
      sink.forceColor = null;

      if (state.selected) {
        const edge = engine.model.typeOf(state.selected)?.edge?.(state.selected);
        if (edge) {
          canvasContext.strokeStyle = "rgba(30, 144, 255, .55)";
          canvasContext.lineWidth = 3 / scale;
          canvasContext.beginPath();
          canvasContext.moveTo(edge[0].x, edge[0].y);
          canvasContext.lineTo(edge[1].x, edge[1].y);
          canvasContext.stroke();
        }
      }

      if (firstPoint) {
        const current = state.snap?.point || state.mouse;
        canvasContext.setLineDash([6 / scale, 4 / scale]);
        canvasContext.strokeStyle = "#ff9800";
        canvasContext.lineWidth = 1.4 / scale;
        canvasContext.beginPath();
        canvasContext.moveTo(firstPoint.x, firstPoint.y);
        canvasContext.lineTo(current.x, current.y);
        canvasContext.stroke();
        canvasContext.setLineDash([]);
        canvasContext.beginPath();
        canvasContext.arc(firstPoint.x, firstPoint.y, 5 / scale, 0, Math.PI * 2);
        canvasContext.stroke();
      }

      if (state.snap && state.snap.type !== "free") {
        const point = state.snap.point;
        const markerSize = 7 / scale;
        canvasContext.lineWidth = 1.8 / scale;
        if (state.snap.type === "edge") {
          canvasContext.strokeStyle = "#ffd400";
          canvasContext.beginPath();
          canvasContext.arc(point.x, point.y, markerSize * 0.8, 0, Math.PI * 2);
          canvasContext.stroke();
        } else {
          canvasContext.strokeStyle = state.snap.type === "vertex" ? "#22e06a" : "#7dff9b";
          canvasContext.strokeRect(point.x - markerSize, point.y - markerSize, markerSize * 2, markerSize * 2);
        }
      }
      canvasContext.restore();
    }

    function renderLoop() {
      if (disposed) return;
      if (engine.consumeDirty()) draw();
      animationFrame = window.requestAnimationFrame(renderLoop);
    }

    listen(canvas, "pointerdown", handlePointerDown);
    listen(canvas, "pointermove", handlePointerMove);
    listen(window, "pointerup", handlePointerUp);
    listen(canvas, "dblclick", handleDoubleClick);
    listen(canvas, "contextmenu", (event) => event.preventDefault());
    listen(canvas, "wheel", handleWheel, { passive: false });
    listen(window, "keydown", handleKeyDown);
    listen(window, "paste", handlePaste);
    listen(window, "resize", engine.invalidate);
    ["dragenter", "dragover"].forEach((type) => listen(drawingStage, type, (event) => event.preventDefault()));
    listen(drawingStage, "drop", (event) => {
      event.preventDefault();
      useUploadedFile(event.dataTransfer?.files?.[0]);
    });
    listen(fileInput, "change", (event) => useUploadedFile(event.target.files?.[0]));
    listen(query('[data-action="open-image"]'), "click", () => fileInput.click());
    listen(query('[data-action="fit-view"]'), "click", fitView);
    listen(query('[data-action="detect"]'), "click", scheduleDetection);
    listen(splitButton, "click", () => {
      splitMode = !splitMode;
      firstPoint = null;
      setActiveControls();
      updateStatus();
      engine.invalidate();
    });
    listen(askButton, "click", () => {
      askForValue = !askForValue;
      setActiveControls();
      persistSettings();
    });
    listen(query('[data-action="delete-selected"]'), "click", () => {
      if (!engine.state.selected) ui.showToast("삭제할 치수를 먼저 선택하세요.");
      else engine.model.remove(engine.state.selected);
    });
    listen(query('[data-action="undo"]'), "click", () => {
      if (!engine.model.undo()) ui.showToast("되돌릴 치수 변경이 없습니다.");
    });
    listen(query('[data-action="clear"]'), "click", () => {
      if (!engine.state.dimensions.length) return;
      if (window.confirm("치수를 모두 지울까요?")) engine.model.clear();
    });
    root.querySelectorAll("[data-color]").forEach((button) => listen(button, "click", () => {
      engine.style.color = button.dataset.color;
      if (engine.state.selected) engine.model.updateSelected({ color: engine.style.color });
      setActiveControls();
      persistSettings();
      engine.invalidate();
    }));
    listen(textSizeInput, "input", () => {
      engine.style.textSize = Math.max(4, Math.min(128, Number(textSizeInput.value) || 16));
      if (engine.state.selected) engine.state.selected.th = engine.style.textSize;
      engine.invalidate();
    });
    listen(textSizeInput, "change", () => {
      textSizeInput.value = String(engine.style.textSize);
      if (engine.state.selected) engine.model.updateSelected({ textSize: engine.style.textSize });
      persistSettings();
    });
    listen(unitSelect, "change", () => {
      engine.style.unit = unitSelect.value;
      if (engine.state.selected) engine.model.updateSelected({ unit: engine.style.unit });
      persistSettings();
      updateStatus();
      engine.invalidate();
    });
    listen(qualityInput, "input", () => { qualityValue.textContent = qualityInput.value; });
    listen(distanceInput, "input", () => { distanceValue.textContent = distanceInput.value; });
    listen(qualityInput, "change", () => { persistDetection(); scheduleDetection(); });
    listen(distanceInput, "change", () => { persistDetection(); scheduleDetection(); });

    const exportBox = query('[data-role="exports"]');
    engine.exporters.list().forEach((exporter) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = exporter.label || exporter.name;
      if (exporter.primary) button.classList.add("is-positive");
      listen(button, "click", async () => {
        try {
          await exporter.run();
        } catch (error) {
          console.error(error);
          ui.showToast(error.message || "도면 파일을 저장하지 못했습니다.");
        }
      });
      exportBox.appendChild(button);
    });

    setActiveControls();
    updateStatus();
    animationFrame = window.requestAnimationFrame(renderLoop);
    loadInitialImage().catch((error) => {
      console.error(error);
      if (!disposed) {
        setBusy("");
        ui.showToast("도면 이미지를 불러오지 못했습니다.");
      }
    });

    return () => {
      disposed = true;
      imageLoadToken += 1;
      if (detectionTimer) window.clearTimeout(detectionTimer);
      if (animationFrame) window.cancelAnimationFrame(animationFrame);
      listeners.splice(0).reverse().forEach((remove) => remove());
      revokeActiveObjectUrl();
      detector.releaseAnalysis();
      engine.state.image = null;
      engine.state.dimensions = [];
      firstPoint = null;
      drag = null;
      pan = null;
      root.replaceChildren();
    };
  }

  Tool.core.drawingWorkspace = Object.freeze({ mount });
})(window.HeechangTool);
