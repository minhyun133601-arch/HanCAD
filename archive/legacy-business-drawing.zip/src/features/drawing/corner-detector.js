(function createDrawingDetectionModule(Tool) {
  "use strict";

  function blur(source, width, height, sigma) {
    const radius = Math.max(1, Math.ceil(sigma * 3));
    const kernel = new Float32Array(radius * 2 + 1);
    let total = 0;
    for (let index = -radius; index <= radius; index += 1) {
      const value = Math.exp(-(index * index) / (2 * sigma * sigma));
      kernel[index + radius] = value;
      total += value;
    }
    for (let index = 0; index < kernel.length; index += 1) kernel[index] /= total;

    const temporary = new Float32Array(width * height);
    const output = new Float32Array(width * height);
    for (let y = 0; y < height; y += 1) {
      const rowOffset = y * width;
      for (let x = 0; x < width; x += 1) {
        let value = 0;
        for (let index = -radius; index <= radius; index += 1) {
          const sourceX = Math.max(0, Math.min(width - 1, x + index));
          value += source[rowOffset + sourceX] * kernel[index + radius];
        }
        temporary[rowOffset + x] = value;
      }
    }
    for (let x = 0; x < width; x += 1) {
      for (let y = 0; y < height; y += 1) {
        let value = 0;
        for (let index = -radius; index <= radius; index += 1) {
          const sourceY = Math.max(0, Math.min(height - 1, y + index));
          value += temporary[sourceY * width + x] * kernel[index + radius];
        }
        output[y * width + x] = value;
      }
    }
    return output;
  }

  function create(engine) {
    const state = engine.state;
    const distance = engine.vector.dst;

    function releaseAnalysis() {
      state.gray = null;
      state.mask = null;
      state.response = null;
      state.responseMax = 0;
      state.corners = [];
      state.grid = null;
      state.gridWidth = 0;
      state.gridHeight = 0;
    }

    function prepare(image) {
      releaseAnalysis();
      state.image = image;
      state.width = image.naturalWidth;
      state.height = image.naturalHeight;
      const canvas = document.createElement("canvas");
      canvas.width = state.width;
      canvas.height = state.height;
      const context = canvas.getContext("2d", { willReadFrequently: true });
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, state.width, state.height);
      context.drawImage(image, 0, 0);
      const rgba = context.getImageData(0, 0, state.width, state.height).data;
      const gray = new Float32Array(state.width * state.height);
      const mask = new Uint8Array(state.width * state.height);
      for (let index = 0; index < gray.length; index += 1) {
        const rgbaIndex = index * 4;
        const value = 0.299 * rgba[rgbaIndex] + 0.587 * rgba[rgbaIndex + 1] + 0.114 * rgba[rgbaIndex + 2];
        gray[index] = value;
        mask[index] = value < 190 ? 1 : 0;
      }
      state.gray = gray;
      state.mask = mask;
      engine.invalidate();
    }

    function buildResponse() {
      const width = state.width;
      const height = state.height;
      const length = width * height;
      const softened = blur(state.gray, width, height, 1.2);
      const aValues = new Float32Array(length);
      const bValues = new Float32Array(length);
      const cValues = new Float32Array(length);
      for (let y = 1; y < height - 1; y += 1) {
        for (let x = 1; x < width - 1; x += 1) {
          const index = y * width + x;
          const gradientX = (softened[index - width + 1] + 2 * softened[index + 1] + softened[index + width + 1])
            - (softened[index - width - 1] + 2 * softened[index - 1] + softened[index + width - 1]);
          const gradientY = (softened[index + width - 1] + 2 * softened[index + width] + softened[index + width + 1])
            - (softened[index - width - 1] + 2 * softened[index - width] + softened[index - width + 1]);
          aValues[index] = gradientX * gradientX;
          bValues[index] = gradientX * gradientY;
          cValues[index] = gradientY * gradientY;
        }
      }
      const blurredA = blur(aValues, width, height, 1.6);
      const blurredB = blur(bValues, width, height, 1.6);
      const blurredC = blur(cValues, width, height, 1.6);
      let maximum = 0;
      for (let index = 0; index < length; index += 1) {
        const a = blurredA[index];
        const b = blurredB[index];
        const c = blurredC[index];
        const trace = (a + c) * 0.5;
        const value = trace - Math.sqrt(Math.max(0, ((a - c) * 0.5) ** 2 + b * b));
        aValues[index] = value;
        if (value > maximum) maximum = value;
      }
      state.response = aValues;
      state.responseMax = maximum;
    }

    function buildGrid() {
      state.gridWidth = Math.max(1, Math.ceil(state.width / state.gridCell));
      state.gridHeight = Math.max(1, Math.ceil(state.height / state.gridCell));
      state.grid = new Array(state.gridWidth * state.gridHeight);
      state.corners.forEach((point) => {
        const gridX = Math.max(0, Math.min(state.gridWidth - 1, Math.floor(point.x / state.gridCell)));
        const gridY = Math.max(0, Math.min(state.gridHeight - 1, Math.floor(point.y / state.gridCell)));
        const key = gridY * state.gridWidth + gridX;
        (state.grid[key] || (state.grid[key] = [])).push(point);
      });
    }

    function run(qualityValue = 15, minDistance = 10) {
      if (!state.gray) return [];
      if (!state.response) buildResponse();
      const quality = Number(qualityValue) / 1000;
      const width = state.width;
      const height = state.height;
      const response = state.response;
      const threshold = state.responseMax * quality;
      const candidates = [];
      for (let y = 3; y < height - 3; y += 1) {
        for (let x = 3; x < width - 3; x += 1) {
          const index = y * width + x;
          const value = response[index];
          if (value < threshold) continue;
          if (value < response[index - 1] || value < response[index + 1]
            || value < response[index - width] || value < response[index + width]
            || value < response[index - width - 1] || value < response[index - width + 1]
            || value < response[index + width - 1] || value < response[index + width + 1]) continue;
          candidates.push({ x, y, value });
        }
      }
      candidates.sort((left, right) => right.value - left.value);
      const cellSize = Math.max(4, minDistance);
      const gridWidth = Math.ceil(width / cellSize);
      const gridHeight = Math.ceil(height / cellSize);
      const occupied = new Array(gridWidth * gridHeight);
      const output = [];
      for (const point of candidates) {
        if (output.length >= 6000) break;
        const gridX = Math.min(gridWidth - 1, Math.floor(point.x / cellSize));
        const gridY = Math.min(gridHeight - 1, Math.floor(point.y / cellSize));
        let accepted = true;
        for (let y = Math.max(0, gridY - 1); y <= Math.min(gridHeight - 1, gridY + 1) && accepted; y += 1) {
          for (let x = Math.max(0, gridX - 1); x <= Math.min(gridWidth - 1, gridX + 1) && accepted; x += 1) {
            const nearby = occupied[y * gridWidth + x];
            if (nearby?.some((candidate) => distance(point, candidate) < minDistance)) accepted = false;
          }
        }
        if (!accepted) continue;
        const key = gridY * gridWidth + gridX;
        (occupied[key] || (occupied[key] = [])).push(point);
        output.push({ x: point.x, y: point.y });
      }
      state.corners = output;
      buildGrid();
      engine.emit("corners:change", output);
      engine.invalidate();
      return output;
    }

    function nearCorner(point, radius) {
      if (!state.grid) return null;
      const cell = state.gridCell;
      const x0 = Math.max(0, Math.floor((point.x - radius) / cell));
      const x1 = Math.min(state.gridWidth - 1, Math.floor((point.x + radius) / cell));
      const y0 = Math.max(0, Math.floor((point.y - radius) / cell));
      const y1 = Math.min(state.gridHeight - 1, Math.floor((point.y + radius) / cell));
      let closest = null;
      let closestDistance = radius;
      for (let y = y0; y <= y1; y += 1) {
        for (let x = x0; x <= x1; x += 1) {
          const points = state.grid[y * state.gridWidth + x] || [];
          points.forEach((candidate) => {
            const candidateDistance = distance(point, candidate);
            if (candidateDistance < closestDistance) {
              closestDistance = candidateDistance;
              closest = candidate;
            }
          });
        }
      }
      return closest;
    }

    function refineCorner(point, radius) {
      const response = state.response;
      if (!response) return null;
      const width = state.width;
      const height = state.height;
      const x0 = Math.max(3, Math.round(point.x - radius));
      const x1 = Math.min(width - 4, Math.round(point.x + radius));
      const y0 = Math.max(3, Math.round(point.y - radius));
      const y1 = Math.min(height - 4, Math.round(point.y + radius));
      let bestX = -1;
      let bestY = -1;
      let bestValue = state.responseMax * 1e-3;
      for (let y = y0; y <= y1; y += 1) {
        for (let x = x0; x <= x1; x += 1) {
          const index = y * width + x;
          const value = response[index];
          if (value <= bestValue) continue;
          if (value < response[index - 1] || value < response[index + 1]
            || value < response[index - width] || value < response[index + width]) continue;
          bestValue = value;
          bestX = x;
          bestY = y;
        }
      }
      if (bestX < 0) return null;
      const index = bestY * width + bestX;
      const dx = 0.5 * (response[index - 1] - response[index + 1])
        / ((response[index - 1] - 2 * response[index] + response[index + 1]) || 1);
      const dy = 0.5 * (response[index - width] - response[index + width])
        / ((response[index - width] - 2 * response[index] + response[index + width]) || 1);
      return {
        x: bestX + (Math.abs(dx) < 1 ? dx : 0),
        y: bestY + (Math.abs(dy) < 1 ? dy : 0),
      };
    }

    function nearEdge(point, radius) {
      if (!state.mask) return null;
      const width = state.width;
      const height = state.height;
      const searchRadius = Math.ceil(radius);
      const x0 = Math.max(0, Math.round(point.x) - searchRadius);
      const x1 = Math.min(width - 1, Math.round(point.x) + searchRadius);
      const y0 = Math.max(0, Math.round(point.y) - searchRadius);
      const y1 = Math.min(height - 1, Math.round(point.y) + searchRadius);
      let closest = null;
      let bestDistance = radius * radius;
      for (let y = y0; y <= y1; y += 1) {
        const rowOffset = y * width;
        const dy = y - point.y;
        for (let x = x0; x <= x1; x += 1) {
          if (!state.mask[rowOffset + x]) continue;
          const dx = x - point.x;
          const candidateDistance = dx * dx + dy * dy;
          if (candidateDistance < bestDistance) {
            bestDistance = candidateDistance;
            closest = { x, y };
          }
        }
      }
      return closest;
    }

    function snapAt(worldPoint) {
      const radius = 16 / state.view.scale;
      const corner = nearCorner(worldPoint, radius);
      if (corner) return { point: { x: corner.x, y: corner.y }, type: "vertex" };
      const refined = refineCorner(worldPoint, Math.max(6, radius * 0.8));
      if (refined) return { point: refined, type: "refined" };
      const edge = nearEdge(worldPoint, radius);
      if (edge) return { point: edge, type: "edge" };
      return { point: worldPoint, type: "free" };
    }

    return Object.freeze({ prepare, releaseAnalysis, run, snapAt });
  }

  Tool.core.drawingDetection = Object.freeze({ create });
})(window.HeechangTool);
