(function registerDrawingDocuments(Tool) {
  "use strict";

  Tool.core.documents.register({
    id: "drawing-dimension",
    groupId: "drawing-tools",
    order: 10,
    renderer: "drawing-dimension",
    nav: { label: "도면", subLabel: "간이 CAD · 이미지 치수" },
    header: { title: "도면 · 간이 CAD", eyebrow: "DRAWING / SIMPLE CAD" },
    capabilities: { formulaBar: false, print: false, reset: false },
    page: { width: 1440, height: 900, paper: "workspace" },
    help: [
      { key: "L / REC / C", text: "선 · 사각형 · 원" },
      { key: "Wheel", text: "확대 · 축소" },
      { key: "F8 / F3", text: "직교 · 객체 스냅" },
      { key: "Ctrl + Z", text: "되돌리기" },
    ],
  });
})(window.HeechangTool);
