(function registerDocumentGroups(Tool) {
  "use strict";

  Tool.core.documents.registerGroup({ id: "inspection-log", label: "업무관리", description: "점검 양식 6종", order: 10 });
  Tool.core.documents.registerGroup({ id: "prompt-tools", label: "프롬프트", description: "목차별 프롬프트 관리", order: 40 });
  Tool.core.documents.registerGroup({ id: "drawing-tools", label: "도면", description: "간이 CAD · 이미지 치수", order: 50 });
  Tool.core.documents.registerGroup({ id: "file-tools", label: "파일 변환", description: "이미지 · PDF · DWG 변환", order: 30 });
  Tool.core.documents.registerGroup({ id: "overtime-tools", label: "잔업관리", description: "잔업 · 대체휴무 · 영수증", order: 20 });
  Tool.core.documents.registerGroup({ id: "personnel-tools", label: "인원·작업복", description: "조직도 · 하절기 작업복 규격", order: 60 });
})(window.HeechangTool);
