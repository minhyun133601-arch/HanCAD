(function createStateStore(Tool) {
  "use strict";

  const SCHEMA_VERSION = 2;
  const RETIRED_DOCUMENT_IDS = new Set(["workwear-register"]);
  const storage = Tool.core.storage;
  const { clamp } = Tool.core.utils;

  function createDefaultState() {
    const documents = {};
    const definitions = Tool.core.documents.list();
    definitions.forEach((documentDefinition) => {
      documents[documentDefinition.id] = Tool.core.renderers.get(documentDefinition.renderer).createDefaultState(documentDefinition);
    });
    return {
      schemaVersion: SCHEMA_VERSION,
      ui: { activeDocumentId: definitions[0].id, zoom: 0.82, sidebarCollapsed: false },
      documents,
    };
  }

  function hydrateCurrentState(rawState) {
    if (!rawState || typeof rawState !== "object") throw new Error("저장 상태가 객체가 아닙니다.");
    const defaults = createDefaultState();
    const validIds = new Set(Tool.core.documents.list().map((documentDefinition) => documentDefinition.id));
    const rawDocuments = rawState.documents && typeof rawState.documents === "object" ? rawState.documents : {};
    const preservedDocuments = Object.fromEntries(
      Object.entries(rawDocuments).filter(([documentId, documentState]) => (
        !validIds.has(documentId)
        && !RETIRED_DOCUMENT_IDS.has(documentId)
        && documentState
        && typeof documentState === "object"
      )),
    );
    const state = {
      schemaVersion: SCHEMA_VERSION,
      ui: {
        activeDocumentId: validIds.has(rawState.ui?.activeDocumentId) ? rawState.ui.activeDocumentId : defaults.ui.activeDocumentId,
        zoom: clamp(Number.isFinite(Number(rawState.ui?.zoom)) ? rawState.ui.zoom : defaults.ui.zoom, 0.62, 1.08),
        sidebarCollapsed: rawState.ui?.sidebarCollapsed === true,
      },
      documents: preservedDocuments,
    };
    Tool.core.documents.list().forEach((documentDefinition) => {
      const renderer = Tool.core.renderers.get(documentDefinition.renderer);
      state.documents[documentDefinition.id] = typeof renderer.hydrate === "function"
        ? renderer.hydrate(documentDefinition, rawDocuments[documentDefinition.id])
        : renderer.createDefaultState(documentDefinition);
    });
    return state;
  }

  function migrateLegacyState(legacyState) {
    const state = createDefaultState();
    const validIds = new Set(Tool.core.documents.list().map((documentDefinition) => documentDefinition.id));
    state.ui.activeDocumentId = validIds.has(legacyState?.activeDocument) ? legacyState.activeDocument : state.ui.activeDocumentId;
    state.ui.zoom = clamp(Number.isFinite(Number(legacyState?.zoom)) ? legacyState.zoom : state.ui.zoom, 0.62, 1.08);
    state.ui.sidebarCollapsed = legacyState?.sidebarCollapsed === true;
    Tool.core.documents.list().forEach((documentDefinition) => {
      const renderer = Tool.core.renderers.get(documentDefinition.renderer);
      if (typeof renderer.migrateLegacy === "function") {
        state.documents[documentDefinition.id] = renderer.migrateLegacy(documentDefinition, legacyState);
      }
    });
    return state;
  }

  function load() {
    const current = storage.readJson(storage.CURRENT_KEY);
    if (current.found && !current.error) {
      try {
        return { state: hydrateCurrentState(current.value), storageAvailable: current.available, migrated: false };
      } catch (error) {
        storage.remove(storage.CURRENT_KEY);
      }
    } else if (current.error) {
      storage.remove(storage.CURRENT_KEY);
    }

    const legacy = storage.readJson(storage.LEGACY_KEY);
    if (legacy.found && !legacy.error) {
      try {
        const state = migrateLegacyState(legacy.value);
        const saved = storage.writeJson(storage.CURRENT_KEY, state);
        return { state, storageAvailable: saved, migrated: true };
      } catch (error) {
        // 손상된 구버전 데이터는 보존하고 기본 상태로 계속 실행합니다.
      }
    }

    return {
      state: createDefaultState(),
      storageAvailable: current.available && legacy.available,
      migrated: false,
    };
  }

  function save(state) {
    return storage.writeJson(storage.CURRENT_KEY, hydrateCurrentState(state));
  }

  Tool.core.stateStore = Object.freeze({
    SCHEMA_VERSION,
    createDefaultState,
    hydrateCurrentState,
    load,
    migrateLegacyState,
    save,
  });
})(window.HeechangTool);
