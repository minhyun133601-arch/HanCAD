import path from "node:path";

const root = path.resolve(import.meta.dirname);
const sourceDirectory = path.join(root, "src");
const assets = path.join(sourceDirectory, "assets");

const styleFiles = Object.freeze([
  "./app/styles/design-tokens.css",
  "./app/styles/base.css",
  "./app/shell/styles.css",
  "./features/work-management/workbook/styles.css",
  "./features/work-management/checklist/styles.css",
  "./features/work-management/monthly-form/styles.css",
  "./features/prompt/styles.css",
  "./features/drawing/styles.css",
  "./features/drawing/cad-styles.css",
  "./features/file-converter/styles.css",
  "./features/overtime/styles.css",
  "./app/styles/print.css",
  "./features/organization/styles.css",
]);

const scriptFiles = Object.freeze([
  "./app/namespace.js",
  "./shared/utilities.js",
  "./app/registries/renderers.js",
  "./app/registries/documents.js",
  "./features/file-converter/mode-registry.js",
  "./features/work-management/workbook/data.js",
  "./features/work-management/checklist/data.js",
  "./features/work-management/monthly-form/data.js",
  "./shared/asset-catalog.js",
  "./features/overtime/seed-data.js",
  "./features/file-converter/shared.js",
  "./features/file-converter/image-codec.js",
  "./features/file-converter/pdf-writer.js",
  "./features/file-converter/zip-writer.js",
  "./features/file-converter/pdf-reader.js",
  "./features/file-converter/dwg-engine.js",
  "./features/file-converter/modes/image-to-pdf.js",
  "./features/file-converter/modes/pdf-to-image.js",
  "./features/file-converter/modes/image-format.js",
  "./features/file-converter/modes/dwg-export.js",
  "./features/file-converter/public-api.js",
  "./features/overtime/domain.js",
  "./features/drawing/engine.js",
  "./features/drawing/corner-detector.js",
  "./features/drawing/image-store.js",
  "./features/drawing/exporters.js",
  "./features/drawing/workspace.js",
  "./features/drawing/cad-engine.js",
  "./features/drawing/cad-exporters.js",
  "./features/drawing/cad-workspace.js",
  "./app/document-groups.js",
  "./features/work-management/workbook/documents.js",
  "./features/work-management/checklist/documents.js",
  "./features/work-management/monthly-form/documents.js",
  "./features/file-converter/document.js",
  "./features/prompt/document.js",
  "./features/drawing/document.js",
  "./features/overtime/document.js",
  "./app/persistence/browser-storage.js",
  "./features/work-management/responsible-name.js",
  "./features/work-management/workbook/renderer.js",
  "./features/work-management/checklist/renderer.js",
  "./features/work-management/monthly-form/renderer.js",
  "./features/prompt/renderer.js",
  "./features/file-converter/renderer.js",
  "./features/drawing/renderer.js",
  "./features/overtime/view-model.js",
  "./features/overtime/receipt-store.js",
  "./features/overtime/image-export.js",
  "./features/overtime/entry-controller.js",
  "./features/overtime/receipt-controller.js",
  "./features/overtime/print-controller.js",
  "./features/overtime/renderer.js",
  "./features/organization/seed-data.js",
  "./features/organization/domain.js",
  "./features/organization/view.js",
  "./features/organization/controller.js",
  "./features/organization/exporters.js",
  "./features/organization/renderer.js",
  "./features/organization/document.js",
  "./app/persistence/state-store.js",
  "./app/shell/renderer.js",
  "./app/controller.js",
  "./app/startup.js",
]);

const browserOnlyFiles = Object.freeze([
  "./app/shell/renderer.js",
  "./app/controller.js",
  "./app/startup.js",
]);

function resolveSourceFile(reference) {
  const absolutePath = path.resolve(sourceDirectory, reference);
  if (absolutePath !== sourceDirectory && !absolutePath.startsWith(`${sourceDirectory}${path.sep}`)) {
    throw new Error(`소스 디렉터리 밖의 경로는 사용할 수 없습니다: ${reference}`);
  }
  return absolutePath;
}

export const projectConfig = Object.freeze({
  root,
  sourceDirectory,
  sourceHtml: path.join(sourceDirectory, "application.html"),
  assets,
  output: path.join(root, "희창유업_업무관리.html"),
  buildScript: path.join(root, "scripts", "build-application.mjs"),
  styleFiles,
  scriptFiles,
  browserOnlyFiles,
  resolveSourceFile,
});

export default projectConfig;
